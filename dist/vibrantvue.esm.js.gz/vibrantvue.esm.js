import { defineComponent as D, ref as C, unref as p, onMounted as de, nextTick as sa, watch as U, h as ra, computed as f, inject as R, createBlock as B, createElementBlock as c, openBlock as r, Transition as ia, withCtx as w, renderSlot as T, normalizeClass as N, createCommentVNode as O, createVNode as F, toDisplayString as x, mergeProps as Y, toValue as ie, createElementVNode as A, Fragment as z, renderList as j, resolveDynamicComponent as he, createTextVNode as G, withDirectives as le, vModelText as mt, vShow as oe, normalizeProps as me, resolveComponent as gt, useSlots as ce, readonly as fe, normalizeStyle as Ae, guardReactiveProps as _e, reactive as ua, createSlots as Te, withAsyncContext as da, onUnmounted as ca, useId as pa, provide as Re, markRaw as ma } from "vue";
const Pe = (e) => new Promise((l) => {
  let t = [], a = document.head || document.getElementsByTagName("head")[0];
  (Array.isArray(e) ? e : [e]).forEach((n, s) => {
    if (n.toLowerCase().endsWith(".css") || (n += ".css"), document.querySelectorAll('link[server_path="' + n + '"]').length == 0) {
      let i = document.createElement("link"), d = new Promise((u) => {
        i.onload = function() {
          u(n);
        };
      });
      t[s] = d, a.appendChild(i), i.setAttribute("rel", "stylesheet"), i.setAttribute("type", "text/css"), i.setAttribute("server_path", n), i.setAttribute("href", n);
    } else
      t[s] = Promise.resolve(n);
  }), Promise.all(t).then((n) => {
    l(n);
  });
}), ve = [], Ue = (e, l) => new Promise((t) => {
  let a = ve.find((n) => n.path === e);
  if (a != null)
    if (a.result === void 0 && l !== void 0 || a.result === null && l === void 0) {
      let n = setTimeout(() => {
        let s = ve.find((o) => o.path === e);
        s == null ? (clearTimeout(n), t(void 0)) : (s.result !== void 0 && l !== void 0 || s.result === void 0 && l === void 0) && (clearTimeout(n), t(s.result));
      }, 500);
    } else
      t(a.result);
  else {
    ve.push({
      path: e,
      result: l === void 0 ? null : void 0
    });
    let n = document.createElement("script");
    n.onload = () => {
      let o = ve.findIndex((i) => i.path === e);
      if (l === void 0)
        ve[o].result = void 0;
      else {
        let i = {};
        l.forEach((d) => {
          i[d] = window[d];
        }), ve[o].result = i;
      }
      t(ve[o].result);
    }, n.setAttribute("src", e), (document.head || document.getElementsByTagName("head")[0]).appendChild(n);
  }
}), bt = () => {
  let e, l = "";
  return typeof self.crypto < "u" && (e = self.crypto, l = e.randomUUID?.()), l || "";
}, ga = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  css: Pe,
  generateUUID: bt,
  loadNonEs6Module: Ue
}, Symbol.toStringTag, { value: "Module" }));
var Z = /* @__PURE__ */ ((e) => (e.white = "white", e.black = "black", e.light = "light", e.dark = "dark", e.primary = "primary", e.link = "link", e.info = "info", e.success = "success", e.warning = "warning", e.danger = "danger", e))(Z || {}), ue = /* @__PURE__ */ ((e) => (e.info = "info", e.success = "success", e.warning = "warning", e.danger = "danger", e))(ue || {}), H = /* @__PURE__ */ ((e) => (e.small = "small", e.normal = "normal", e.medium = "medium", e.large = "large", e))(H || {}), ye = /* @__PURE__ */ ((e) => (e.slower = "slower", e.slow = "slow", e.fast = "fast", e.faster = "faster", e))(ye || {}), we = /* @__PURE__ */ ((e) => (e.bounce = "bounce", e.flash = "flash", e.pulse = "pulse", e.rubberBand = "rubberBand", e.shakeX = "shakeX", e.shakeY = "shakeY", e.headShake = "headShake", e.swing = "swing", e.tada = "tada", e.wobble = "wobble", e.jello = "jello", e.heartBeat = "heartBeat", e.backOutDown = "backOutDown", e.backOutLeft = "backOutLeft", e.backOutRight = "backOutRight", e.backOutUp = "backOutUp", e.bounceIn = "bounceIn", e.bounceInDown = "bounceInDown", e.bounceInLeft = "bounceInLeft", e.bounceInRight = "bounceInRight", e.bounceInUp = "bounceInUp", e.bounceOut = "bounceOut", e.boundOutDown = "boundOutDown", e.bounceOutLeft = "bounceOutLeft", e.boundOutRight = "boundOutRight", e.bounceOutUp = "bounceOutUp", e.fadeIn = "fadeIn", e.fadeInDown = "fadeInDown", e.fadeInDownBig = "fadeInDownBig", e.fadeInLeft = "fadeInLeft", e.fadeInLeftBig = "fadeInLeftBig", e.fadeInRight = "fadeInRight", e.fadeInRightBig = "fadeInRightBig", e.fadeInUp = "fadeInUp", e.fadeInUpBig = "fadeInUpBig", e.fadeInTopLeft = "fadeInTopLeft", e.fadeInTopRight = "fadeInTopRight", e.fadeInBottomLeft = "fadeInBottomLeft", e.fadeInBottomRight = "fadeInBottomRight", e.fadeOut = "fadeOut", e.fadeOutDown = "fadeOutDown", e.fadeOutDownBig = "fadeOutDownBig", e.fadeOutLeft = "fadeOutLeft", e.fadeOutLeftBig = "fadeOutLeftBig", e.fadeOutRight = "fadeOutRight", e.fadeOutRightBig = "fadeOutRightBig", e.fadeOutUp = "fadeOutUp", e.fadeOutUpBig = "fadeOutUpBig", e.fadeOutTopLeft = "fadeOutTopLeft", e.fadeOutTopRight = "fadeOutTopRight", e.fadeOutBottomRight = "fadeOutBottomRight", e.fadeOutBottomLeft = "fadeOutBottomLeft", e.flip = "flip", e.flipInX = "flipInX", e.flipInY = "flipInY", e.flipOutX = "flipOutX", e.flipOutY = "flipOutY", e.lightSpeedInRight = "lightSpeedInRight", e.lightSpeedInLeft = "lightSpeedInLeft", e.lightSpeedOutRight = "lightSpeedOutRight", e.lightSpeedOutLeft = "lightSpeedOutLeft", e.rotateIn = "rotateIn", e.rotateInDownLeft = "rotateInDownLeft", e.rotateInDownRight = "rotateInDownRight", e.rotateInUpLeft = "rotateInUpLeft", e.rotateInUpRight = "rotateInUpRight", e.rotateOut = "rotateOut", e.rotateOutDownLeft = "rotateOutDownLeft", e.rotateOutDownRight = "rotateOutDownRight", e.rotateOutUpLeft = "rotateOutUpLeft", e.rotateOutUpRight = "rotateOutUpRight", e.hinge = "hinge", e.jackInTheBox = "jackInTheBox", e.rollIn = "rollIn", e.rollOut = "rollOut", e.zoomIn = "zoomIn", e.zoomInDown = "zoomInDown", e.zoomInLeft = "zoomInLeft", e.zoomInRight = "zoomInRight", e.zoomInUp = "zoomInUp", e.zoomOut = "zoomOut", e.zoomOutDown = "zoomOutDown", e.zoomOutLeft = "zoomOutLeft", e.zoomOutRight = "zoomOutRight", e.zoomOutUp = "zoomOutUp", e.slideInDown = "slideInDown", e.slideInLeft = "slideInLeft", e.slideInRight = "slideInRight", e.slideInUp = "slideInUp", e.slideOutDown = "slideOutDown", e.slideOutLeft = "slideOutLeft", e.slideOutRight = "slideOutRight", e.slideOutUp = "slideOutUp", e))(we || {}), ht = /* @__PURE__ */ ((e) => (e.area = "area", e.bar = "bar", e.bubble = "bubble", e.doughnut = "doughnut", e.pie = "pie", e.line = "line", e.polarArea = "polarArea", e.radar = "radar", e.scatter = "scatter", e))(ht || {}), Ge = /* @__PURE__ */ ((e) => (e.top = "top", e.left = "left", e.bottom = "bottom", e.right = "right", e.chartArea = "chartArea", e))(Ge || {}), se = /* @__PURE__ */ ((e) => (e.xxsmall = "2xs", e.xsmall = "xs", e.small = "sm", e.normal = "", e.large = "lg", e.xlarge = "xl", e.xxlarge = "2xl", e))(se || {}), ne = /* @__PURE__ */ ((e) => (e.center = "center", e.topLeft = "topLeft", e.bottomLeft = "bottomLeft", e.topRight = "topRight", e.bottomRight = "bottomRight", e.top = "top", e.bottom = "bottom", e))(ne || {}), Fe = /* @__PURE__ */ ((e) => (e.centered = "centered", e.right = "right", e.left = "left", e))(Fe || {}), vt = /* @__PURE__ */ ((e) => (e.arrow = "arrow", e.button = "button", e.dot = "dot", e.succeeds = "succeeds", e))(vt || {}), He = /* @__PURE__ */ ((e) => (e.mobile = "mobile", e.desktop = "desktop", e.gapless = "gapless", e.multiline = "multiline", e.centered = "centered", e.borderleft = "borderleft", e.borderright = "borderright", e.borderbottom = "borderbottom", e.bordertop = "bordertop", e.fullWidth = "fullwidth", e.fullHeight = "fullheight", e))(He || {}), ae = /* @__PURE__ */ ((e) => (e.three_quarters = "three-quarters", e.two_thirds = "two-thirds", e.half = "half", e.one_third = "one-third", e.one_quarter = "one-quarter", e.full = "full", e.one_fifth = "one-fifth", e.two_fifths = "two-fifths", e.three_fifths = "three-fifths", e.four_fifths = "four-fifths", e.one = "1", e.two = "2", e.three = "3", e.four = "4", e.five = "5", e.six = "6", e.seven = "7", e.eight = "8", e.nine = "9", e.ten = "10", e.eleven = "11", e.twelve = "12", e.narrow = "narrow", e.wide = "wide", e))(ae || {}), yt = /* @__PURE__ */ ((e) => (e.three_quarters = "three-quarters", e.two_thirds = "two-thirds", e.half = "half", e.one_third = "one-third", e.one_quarter = "one-quarter", e.one_fifth = "one-fifth", e.two_fifths = "two-fifths", e.three_fifths = "three-fifths", e.four_fifths = "four-fifths", e.one = "1", e.two = "2", e.three = "3", e.four = "4", e.five = "5", e.six = "6", e.seven = "7", e.eight = "8", e.nine = "9", e.ten = "10", e.eleven = "11", e))(yt || {}), Ke = /* @__PURE__ */ ((e) => (e.left = "left", e.right = "right", e.bottom = "bottom", e.top = "top", e.all = "all", e))(Ke || {}), Ye = /* @__PURE__ */ ((e) => (e.centered = "centered", e.right = "right", e.left = "left", e))(Ye || {}), ft = /* @__PURE__ */ ((e) => (e.boxed = "boxed", e.toggled = "toggled", e.roundToggle = "roundToggle", e))(ft || {}), _t = /* @__PURE__ */ ((e) => (e.one = "1", e.two = "2", e.three = "3", e.four = "4", e.five = "5", e.six = "6", e.seven = "7", e.eight = "8", e.nine = "9", e.ten = "10", e.eleven = "11", e.twelve = "12", e))(_t || {}), kt = /* @__PURE__ */ ((e) => (e.parent = "parent", e.child = "child", e.ancestor = "ancestor", e))(kt || {}), Be = /* @__PURE__ */ ((e) => (e.top = "is-fixed-top", e.bottom = "is-fixed-bottom", e))(Be || {}), St = /* @__PURE__ */ ((e) => (e.left = "left", e.right = "right", e))(St || {}), qe = /* @__PURE__ */ ((e) => (e.topLeft = "top-left", e.top = "top", e.topRight = "top-right", e.right = "right", e.bottomRight = "bottom-right", e.bottom = "bottom", e.bottomLeft = "bottom-left", e.left = "left", e))(qe || {}), Ce = /* @__PURE__ */ ((e) => (e.left = "left", e.right = "right", e.bottom = "bottom", e.top = "top", e))(Ce || {}), Ze = /* @__PURE__ */ ((e) => (e.left = "left", e.centered = "centered", e.right = "right", e))(Ze || {}), Mt = /* @__PURE__ */ ((e) => (e.centered = "centered", e.right = "right", e.left = "left", e))(Mt || {}), Qe = /* @__PURE__ */ ((e) => (e.cerulean = "cerulean", e.cosmo = "cosmo", e.cyborg = "cyborg", e.dark = "dark", e.darkly = "darkly", e.default = "default", e.flatly = "flatly", e.journal = "journal", e.light = "light", e.litera = "litera", e.lumen = "lumen", e.lux = "lux", e.materia = "materia", e.minty = "minty", e.morph = "morph", e.pulse = "pulse", e.quartz = "quartz", e.sandstone = "sandstone", e.simplex = "simplex", e.sketchy = "sketchy", e.slate = "slate", e.solar = "solar", e.spacelab = "spacelab", e.superhero = "superhero", e.united = "united", e.vapor = "vapor", e.yeti = "yeti", e.zephyr = "zephyr", e))(Qe || {}), Dt = /* @__PURE__ */ ((e) => (e.medium = "medium", e.large = "large", e))(Dt || {}), xe = /* @__PURE__ */ ((e) => (e.default = "default", e.verticalRight = "is-vertical-right", e.verticalLeft = "is-vertical-left", e))(xe || {}), Xe = /* @__PURE__ */ ((e) => (e.xsmall = "is-16x16", e.small = "is-24x24", e.medium = "is-32x32", e.normal = "is-48x48", e.large = "is-64x64", e.xlarge = "is-96x96", e.xxlarge = "is-128x128", e))(Xe || {});
const ba = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  AnimationSpeeds: ye,
  AnimationTypes: we,
  BadgePositions: qe,
  BorderTypes: Ke,
  BreadCrumbAlignments: Fe,
  BreadCrumbSeperators: vt,
  ButtonAlignments: Mt,
  ChartLegendPositions: Ge,
  ChartTypes: ht,
  ColorTypes: Z,
  ColumnContainerModifiers: He,
  ColumnOffsetSizes: yt,
  ColumnSizes: ae,
  DropZoneQuadrants: ne,
  FixedMenuPositions: St,
  FixedNavBarPositions: Be,
  IconSizes: se,
  ImageSizes: Xe,
  NoticeTypes: ue,
  SectionSizes: Dt,
  Sizes: H,
  SkinTypes: Qe,
  StepWizardOrientations: xe,
  TabAlignments: Ye,
  TabStyles: ft,
  TileSizes: _t,
  TileTypes: kt,
  ToolTipPositions: Ce,
  ToolTipTextAlignments: Ze
}, Symbol.toStringTag, { value: "Module" })), $t = "Language", os = (e, l) => l($t, e), Q = (e) => {
  const l = e($t, "en");
  return f(() => l);
}, At = "IconSet", ss = (e, l) => l(At, e), ha = (e) => {
  const l = e(At, "solid");
  return f(() => l);
}, Ot = "SummerNoteCDN", rs = (e, l) => l(Ot, e), va = (e) => e(Ot, "https://cdnjs.cloudflare.com/ajax/libs/summernote/0.9.0/"), Jt = "FontAwesomeCDN", is = (e, l) => l(Jt, e), ya = (e) => e(Jt, "https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.2/css/"), Nt = "AnimateCDN", us = (e, l) => l(Nt, e), fa = (e) => e(Nt, "https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/"), wt = "ChartJSCDN", ds = (e, l) => l(wt, e), _a = (e) => e(wt, "https://cdnjs.cloudflare.com/ajax/libs/Chart.js/4.4.7/"), Ft = "AceJSCDN", cs = (e, l) => l(Ft, e), ka = (e) => e(Ft, "https://cdn.jsdelivr.net/npm/ace-builds@1.37.3/"), W = D({
  name: "skeleton",
  props: {
    tag: {
      type: String,
      default: "div"
    },
    is_loading: {
      type: [Boolean, Object],
      default: void 0
    }
  },
  setup(e, { slots: l }) {
    const t = C(e.is_loading === void 0 ? !0 : p(e.is_loading));
    return de(() => {
      sa(() => {
        (e.is_loading === void 0 || !p(e.is_loading)) && (t.value = !1);
      });
    }), e.is_loading !== void 0 && U(
      () => p(e.is_loading),
      (a) => {
        a ? t.value = !0 : t.value = !1;
      }
    ), () => ra(
      e.tag,
      { class: t.value ? l.default === null || l.default === void 0 ? "skeleton-block" : "is-skeleton" : "" },
      l.default ? l.default() : null
    );
  }
}), Bt = /* @__PURE__ */ D({
  __name: "animation",
  props: {
    incoming: {},
    outgoing: {},
    inout: {},
    speed: { default: ye.slow },
    speedIn: {},
    speedOut: {},
    repeating: {}
  },
  setup(e) {
    const l = fa(R);
    Pe(`${l}animate.min.css`);
    const t = e, a = (m) => {
      switch (m) {
        case ye.slower:
          return 3e3;
        case ye.fast:
          return 800;
        case ye.faster:
          return 500;
        default:
          return 2e3;
      }
    }, n = (m) => m === void 0 ? "" : `animate__${m}`, s = (m) => m === void 0 ? "animate__slow" : `animate__${m}`, o = f(() => ({
      enter: a(t.speedIn ?? t.speed),
      leave: a(t.speedOut ?? t.speed)
    })), i = f(() => [
      "animate__animated",
      n(t.incoming ?? t.inout),
      s(t.speedIn ?? t.speed)
    ].join(" ")), d = f(() => [
      "animate__animated",
      n(t.outgoing ?? t.inout),
      s(t.speedOut ?? t.speed)
    ].join(" ")), u = f(() => [
      "animate__animated",
      "animate__infinite",
      n(t.repeating),
      s(t.speed)
    ].join(" "));
    return (m, b) => t.repeating ? (r(), c("div", {
      key: 1,
      class: N(u.value)
    }, [
      T(m.$slots, "default")
    ], 2)) : (r(), B(ia, {
      key: 0,
      "enter-active-class": i.value,
      "leave-active-class": d.value,
      duration: o.value
    }, {
      default: w(() => [
        T(m.$slots, "default")
      ]),
      _: 3
    }, 8, ["enter-active-class", "leave-active-class", "duration"]));
  }
}), Sa = "brands.min.css", Ma = "all.min.css", rt = "icon_styles", Da = /\.fa-([^: ]+):before/g, $a = /url\(([^)]+)\)/g, De = C([]), Ie = C(!1), it = async (e, l) => {
  if (!Ie.value) {
    Ie.value = !0;
    let t;
    De.value.length === 0 ? (t = document.createElement("style"), t.setAttribute("id", rt), document.head.appendChild(t), t.setAttribute("type", "text/css")) : t = document.getElementById(rt), De.value = [" "];
    let a = await Promise.all([
      fetch(`${e}${Sa}`),
      fetch(`${e}${Ma}`),
      fetch(`${e}${l}.min.css`)
    ]), n = await a[0].text();
    [...n.matchAll(Da)].forEach((s) => {
      De.value.push(s[1]);
    }), n = `${await a[1].text()}
    ${await a[2].text()}
    ${n}`, [...n.matchAll($a)].forEach((s) => {
      n = n.replace(s[0], `url(${new URL(s[1], e)})`);
    }), t.innerText = n, De.value.splice(0, 1), Ie.value = !1;
  }
}, K = /* @__PURE__ */ D({
  __name: "icon",
  props: {
    icon: {},
    size: {},
    is_loading: { type: [Object, Boolean] }
  },
  setup(e) {
    const l = ya(R), t = ha(R);
    De.value.length === 0 ? it(l, t.value) : U(t, () => it(l, t.value));
    const a = e, n = f(() => {
      let s = [];
      return a.icon !== void 0 && a.icon !== null && (De.value.indexOf(a.icon) >= 0 ? s.push("fa-brands") : (s.push("fa-ico"), s.push(`fa-${t.value}`)), s.push((a.icon.indexOf("fa-") == -1 ? " fa-" : " ") + a.icon)), a.size !== void 0 && a.size !== null && a.size !== se.normal && s.push(`fa-${a.size}`), s;
    });
    return (s, o) => (r(), B(p(W), {
      tag: "i",
      is_loading: a.is_loading,
      class: N(n.value)
    }, null, 8, ["is_loading", "class"]));
  }
}), Aa = { key: 1 }, te = /* @__PURE__ */ D({
  __name: "button",
  props: {
    icon: {},
    type: { default: Z.primary },
    title: {},
    disabled: { type: Boolean, default: !1 },
    size: { default: H.normal },
    hide_mobile: { type: Boolean, default: !1 },
    hide_tablet: { type: Boolean, default: !1 },
    hide_desktop: { type: Boolean, default: !1 },
    is_rounded: { type: Boolean, default: !1 },
    is_outlined: { type: Boolean, default: !1 },
    is_loading: { type: [Object, Boolean], default: void 0 }
  },
  emits: ["click"],
  setup(e, { emit: l }) {
    const t = e, a = l, n = f(() => [
      "button",
      `is-${t.size ?? H.normal}`,
      `is-${t.type ?? Z.primary}`,
      t.disabled ? "disabled" : "",
      t.is_rounded ? "is-rounded" : "",
      t.hide_mobile ? "is-hidden-mobile" : "",
      t.hide_tablet ? "is-hidden-tablet-only" : "",
      t.hide_desktop ? "is-hidden-desktop is-hidden-widescreen" : "",
      t.is_outlined ? "is-outlined" : ""
    ]);
    return (s, o) => (r(), B(p(W), {
      tag: "button",
      is_loading: t.is_loading,
      class: N(n.value),
      disabled: t.disabled,
      onClick: o[0] || (o[0] = (i) => a("click"))
    }, {
      default: w(() => [
        t.icon ? (r(), c("span", {
          key: 0,
          class: N([
            "icon",
            t.size === p(H).small ? "is-small" : "",
            t.size === p(H).large ? "is-medium" : ""
          ])
        }, [
          F(K, {
            icon: t.icon
          }, null, 8, ["icon"])
        ], 2)) : O("", !0),
        t.title ? (r(), c("span", Aa, x(t.title), 1)) : O("", !0)
      ]),
      _: 1
    }, 8, ["is_loading", "class", "disabled"]));
  }
}), Oa = '{"en":{"Add":"Add","Cancel":"Cancel","Delete":"Delete","Disable":"Disable","Download":"Download","Edit":"Edit","Enable":"Enable","Okay":"Okay","Print":"Print","Refresh":"Refresh","Save":"Save","Submit":"Submit","Upload":"Upload"},"ar":{"Add":"مضافا","Cancel":"إلغاء","Delete":"تحذف","Disable":"العجز","Download":"تحميل","Edit":"Edit","Enable":"التمكين","Okay":"حسناً","Print":"الطباعة","Refresh":"التجديد","Save":"أنقذ","Submit":"Submit","Upload":"تحميل"},"az":{"Add":"Axtarış","Cancel":"Tarix","Delete":"Delete","Disable":"Qeydiyyat","Download":"Qeydiyyat","Edit":"Tarix","Enable":"Qeydiyyat","Okay":" Okay","Print":"Çap","Refresh":"Axtarış","Save":"Yadda","Submit":"Qeydiyyat","Upload":"Tarix"},"bg":{"Add":"Добавяне","Cancel":"Отмяна","Delete":"Изтриване","Disable":"Изключване","Download":"Изтегляне","Edit":"Редактиране","Enable":"Включване","Okay":"Добре","Print":"Печат","Refresh":"Обновяване","Save":"Запис","Submit":"Подаване","Upload":"Качване"},"bn":{"Add":"যোগ","Cancel":"বাতিল","Delete":"মুছে","Disable":"নিষ্ক্রিয়","Download":"ডাউনলোড","Edit":"সম্পাদনা","Enable":"সক্রিয়","Okay":"ঠিক","Print":"প্রিন্ট","Refresh":"নতুন","Save":"সংরক্ষণ","Submit":"জমা","Upload":"আপলোড"},"ca":{"Add":"Afegeix","Cancel":"Cancel·","Delete":"Esborra","Disable":"Deshabilita","Download":"Descarrega","Edit":"Edita","Enable":"Habilita","Okay":"Bé","Print":"Imprimeix","Refresh":"Refresca","Save":"Desa","Submit":"Envia","Upload":"Puja"},"cs":{"Add":"Přidat","Cancel":"Zrušit","Delete":"Smazat","Disable":"Zakázat","Download":"Stáhnout","Edit":"Upravit","Enable":"Povolit","Okay":"Dobře","Print":"Tisk","Refresh":"Obnovit","Save":"Uložit","Submit":"Odeslat","Upload":"Načíst"},"da":{"Add":"Tilføj","Cancel":"Annullér","Delete":"Slet","Disable":"Deaktivér","Download":"Download","Edit":"Redigér","Enable":"Aktivér","Okay":"Okay","Print":"Udskriv","Refresh":"Genopfrisk","Save":"Gem","Submit":"Indsend","Upload":"Upload"},"de":{"Add":"Hinzufügen","Cancel":"Abbrechen","Delete":"Löschen","Disable":"Deaktivieren","Download":"Herunterladen","Edit":"Bearbeiten","Enable":"Aktivieren","Okay":"Okay","Print":"Drucken","Refresh":"Aktualisieren","Save":"Speichern","Submit":"Senden","Upload":"Hochladen"},"el":{"Add":"Προσθήκη","Cancel":"Ακύρωση","Delete":"Διαγραφή","Disable":"Απενεργοποίηση","Download":"Λήψη","Edit":"Επεξεργασία","Enable":"Ενεργοποίηση","Okay":"Εντάξει","Print":"Εκτύπωση","Refresh":"Ανανέωση","Save":"Αποθήκευση","Submit":"Υποβολή","Upload":"Αποστολή"},"eo":{"Add":"Aldonu","Cancel":"Cancel","Delete":"Delete","Disable":"Distingebla","Download":"Elŝutu","Edit":"Edit","Enable":"Enable","Okay":"Bone","Print":"Presaĵo","Refresh":"Refresh","Save":"Savi","Submit":"Submit","Upload":"Ĝis"},"es":{"Add":"Añadir","Cancel":"Cancelar","Delete":"Suprimir","Disable":"Inhabilitación","Download":"Descargar","Edit":"Editar","Enable":"Habilitación","Okay":"Está","Print":"Imprimir","Refresh":"Refresh","Save":"Guardar","Submit":"Submit","Upload":"Subir"},"et":{"Add":"Lisa","Cancel":"Tühistage","Delete":"Kustuta","Disable":"Keela","Download":"Laadi","Edit":"Edit","Enable":"Luba","Okay":"Olgu","Print":"Printi","Refresh":"Värskenda","Save":"Päästa","Submit":"Esita","Upload":"Laadi"},"eu":{"Add":"Gehitu","Cancel":"Utzi","Delete":"Ezabatu","Disable":"Desgaitu","Download":"Deskargatu","Edit":"Editatu","Enable":"Gaitu","Okay":"Ados","Print":"Inprimatu","Refresh":"Freskatu","Save":"Gorde","Submit":"Bidali","Upload":"Igo"},"fa":{"Add":"Add","Cancel":"لغو","Delete":"حذف","Disable":"Disable","Download":"Download","Edit":"ویرایش","Enable":"گزینه","Okay":"خوب","Print":"Print","Refresh":"بازسازی","Save":"Save","Submit":"ارسال","Upload":"آپلود"},"fi":{"Add":"Lisää","Cancel":"Peruuta","Delete":"Poista","Disable":"Poista","Download":"Lataa","Edit":"Muuta","Enable":"Käytä","Okay":"Selvä","Print":"Tulosta","Refresh":"Päivitä","Save":"Tallenna","Submit":"Lähetä","Upload":"Lähetä"},"fr":{"Add":"Ajouter","Cancel":"Annuler","Delete":"Supprimer","Disable":"Désactiver","Download":"Télécharger","Edit":"Modifier","Enable":"Activer","Okay":"Très","Print":"Imprimer","Refresh":"Actualiser","Save":"Enregistrer","Submit":"Soumettre","Upload":"Envoi"},"ga":{"Add":"Déan","Cancel":"Cealaigh","Delete":"Scriosta","Disable":"Díroghnaigh","Download":"Íoslódáil","Edit":"Toir","Enable":"Cumasaigh","Okay":"Riachtanais","Print":"Priontáil","Refresh":"Athraigh","Save":"Sábháil","Submit":"Cuir","Upload":"Uaslódáil"},"gl":{"Add":"Add","Cancel":"Cancelar","Delete":"Eliminar","Disable":"Disable","Download":"Baixar","Edit":"Edit","Enable":"Habilitar","Okay":"Ok","Print":"Imprimir","Refresh":"Refresco","Save":"Save","Submit":"Presentación","Upload":"Upload"},"he":{"Add":"הוסף","Cancel":"ביטול","Delete":"Delete","Disable":"אכזבה","Download":"הורד","Edit":"Editעריכה","Enable":"אפשרות","Okay":"בסדר","Print":"הדפסה","Refresh":"מרעננים","Save":"להציל","Submit":"הגשת","Upload":"Upload"},"hi":{"Add":"जोड़ें","Cancel":"रद्द","Delete":"डिलीट","Disable":"अक्षम","Download":"डाउनलोड","Edit":"संपादित","Enable":"सक्षम","Okay":"ओके","Print":"छाप","Refresh":"रिफ्रेश","Save":"सहेजें","Submit":"जमा","Upload":"अपलोड"},"hu":{"Add":"Hozzáadás","Cancel":"Törlés","Delete":"Törlés","Disable":"Kikapcsolás","Download":"Letöltés","Edit":"Szerkesztés","Enable":"Beállítás","Okay":"Oké","Print":"Nyomtatás","Refresh":"Frissítés","Save":"Mentés","Submit":"Küldés","Upload":"Feltöltés"},"id":{"Add":"Tambah","Cancel":"Batal","Delete":"Hapus","Disable":"Matikan","Download":"Unduh","Edit":"Sunting","Enable":"Aktifkan","Okay":"Oke","Print":"Cetak","Refresh":"Segarkan","Save":"Simpan","Submit":"Kirim","Upload":"Unggah"},"it":{"Add":"Aggiungi","Cancel":"Annulla","Delete":"Cancella","Disable":"Disattivare","Download":"Scarica","Edit":"Modifica","Enable":"Abilitare","Okay":"Ok","Print":"Stampa","Refresh":"Rifiuti","Save":"Salva","Submit":"Inviare","Upload":"Caricamento"},"ja":{"Add":"追加する","Cancel":"キャンセル","Delete":"削除","Disable":"免責事項","Download":"ダウンロード","Edit":"編集","Enable":"アクセス","Okay":"お問い合わせ","Print":"プリント","Refresh":"リフレッシュ","Save":"保存する","Submit":"送信する","Upload":"アップロード"},"ko":{"Add":"기타","Cancel":"이름","Delete":"기타","Disable":"기타","Download":"다운로드","Edit":"제품정보","Enable":"이름","Okay":"이름","Print":"제품정보","Refresh":"지원하다","Save":"제품","Submit":"제출하기","Upload":"제품정보"},"lt":{"Add":"Pridėti","Cancel":"Atsisakyti","Delete":"Trinti","Disable":"Išjungti","Download":"Atsisiųsti","Edit":"Keisti","Enable":"Įjungti","Okay":"Gerai","Print":"Spausdinti","Refresh":"Atnaujinti","Save":"Įrašyti","Submit":"Siųsti","Upload":"Siųsti"},"lv":{"Add":"Pievienot","Cancel":"Atcelt","Delete":"Dzēst","Disable":"Atslēgt","Download":"Lejupielādēt","Edit":"Rediģēt","Enable":"Ieslēgt","Okay":"Labi","Print":"Drukāt","Refresh":"Atsvaidzināt","Save":"Saglabāt","Submit":"Nosūtīt","Upload":"Augšupielāde"},"ms":{"Add":"Tambah","Cancel":"Batal","Delete":"Dihapus","Disable":"Matikan","Download":"Muaturun","Edit":"Edit","Enable":"Hidupkan","Okay":"Oke","Print":"Cetakan","Refresh":"Segarkan","Save":"Simpan","Submit":"Diserahkan","Upload":"Unggah"},"nb":{"Add":"Legg","Cancel":"Avbryt","Delete":"Slett","Disable":"Slå","Download":"Last","Edit":"Rediger","Enable":"Slå","Okay":"Ok","Print":"Skriv","Refresh":"Oppdater","Save":"Lagre","Submit":"Send","Upload":"Last"},"nl":{"Add":"Voeg","Cancel":"Annuleren","Delete":"Verwijderen","Disable":"Uitschakelen","Download":"Downloaden","Edit":"Bewerken","Enable":"Inschakelen","Okay":"Oké","Print":"Afdrukken","Refresh":"Verversen","Save":"Opslaan","Submit":"Verzenden","Upload":"Uploaden"},"pl":{"Add":"Dodaj","Cancel":"Anuluj","Delete":"Usuń","Disable":"Wyłącz","Download":"Pobierz","Edit":"Edycja","Enable":"Włącz","Okay":"Dobrze","Print":"Drukuj","Refresh":"Odśwież","Save":"Zapisz","Submit":"Prześlij","Upload":"Wyślij"},"pt":{"Add":"Adicionar","Cancel":"Cancelar","Delete":"Excluir","Disable":"Deficiência","Download":"Baixar","Edit":"Editar","Enable":"Habilitar","Okay":"Está","Print":"Impressão","Refresh":"Atualizar","Save":"Salvar","Submit":"Submeter-me","Upload":"Carregar"},"ro":{"Add":"Adaugă","Cancel":"Renunță","Delete":"Șterge","Disable":"Dezactivează","Download":"Descărcare","Edit":"Editare","Enable":"Activează","Okay":"Bine","Print":"Tipărește","Refresh":"Reîmprospătează","Save":"Salvează","Submit":"Trimite","Upload":"Încarcă"},"ru":{"Add":"Добавить","Cancel":"Отменить","Delete":"Исключить","Disable":"Инвалид","Download":"Скачать","Edit":"Редактировать","Enable":"Допускать","Okay":"Хорошо","Print":"Печать","Refresh":"Освежить","Save":"Спасти","Submit":"Представить","Upload":"Загрузить"},"sk":{"Add":"Pridať","Cancel":"Zrušiť","Delete":"Odstrániť","Disable":"Zakázať","Download":"Stiahnuť","Edit":"Upraviť","Enable":"Povoliť","Okay":"Dobre","Print":"Tlač","Refresh":"Obnoviť","Save":"Uložiť","Submit":"Predložiť","Upload":"Odoslať"},"sl":{"Add":"Dodaj","Cancel":"Prekliči","Delete":"Zbriši","Disable":"Onemogoči","Download":"Prenesi","Edit":"Uredi","Enable":"Omogoči","Okay":"V","Print":"Natisni","Refresh":"Osveži","Save":"Shrani","Submit":"Pošlji","Upload":"Pošlji"},"sq":{"Add":"_Shto","Cancel":"Anullo","Delete":"Elemino","Disable":"Jo","Download":"Shkarkimi","Edit":"Ndrysho","Enable":"Aktivo","Okay":"Mirë","Print":"Printo","Refresh":"Rifresko","Save":"Ruaj","Submit":"Dërgo","Upload":"Ngarko"},"sv":{"Add":"Lägg","Cancel":"Avbokning","Delete":"Delete","Disable":"Inaktivera","Download":"Ladda","Edit":"Edit","Enable":"Aktivera","Okay":"Okej","Print":"Print","Refresh":"Refresh","Save":"Spara","Submit":"Inlämning","Upload":"Upload"},"th":{"Add":"เพิ่ม","Cancel":"ยกเลิก","Delete":"ลบ","Disable":"ปิดการใช้งาน","Download":"ดาวน์โหลด","Edit":"แก้ไข","Enable":"เปิด","Okay":"โอเค","Print":"พิมพ์","Refresh":"ปรับปรุงใหม่","Save":"บันทึก","Submit":"ส่ง","Upload":"อัปโหลด"},"tl":{"Add":"Magdagdag","Cancel":"Huwag","Delete":"Ibagsak","Disable":"Hindi","Download":"Ibaba","Edit":"Baguhin","Enable":"Kaibig","Okay":"Okay","Print":"Nakalimbag","Refresh":"Nakapagpapasigla","Save":"Mag","Submit":"Pagpapasakop","Upload":"Itaas"},"tr":{"Add":"Add","Cancel":"Cancel","Delete":"Delete","Disable":"Engelliler","Download":"Download","Edit":"Edit","Enable":"Enable","Okay":"Tamam","Print":"Baskı","Refresh":"Yenileme","Save":"Kaydet","Submit":"Gönder","Upload":"Download"},"uk":{"Add":"Додати","Cancel":"Зареєструватися","Delete":"Делет","Disable":"Вимкнути","Download":"Завантажити","Edit":"Редагування","Enable":"Увімкнути","Okay":"Проксимус","Print":"Друк","Refresh":"Реверс","Save":"Зберегти","Submit":"Подати","Upload":"Завантажити"},"ur":{"Add":"_شامل","Cancel":"منسوخ","Delete":"حذف","Disable":"منسوخ","Download":"اوپر","Edit":"مرتب","Enable":"فعال","Okay":"ٹھیک","Print":"پرنٹ","Refresh":"خوشی","Save":"محفوظ","Submit":"غیر","Upload":"اپ"},"zh":{"Add":"添加","Cancel":"取消","Delete":"删除","Disable":"禁用","Download":"下载","Edit":"编辑","Enable":"启用","Okay":"还好","Print":"打印","Refresh":"刷新","Save":"保存","Submit":"提交","Upload":"上传"},"zt":{"Add":"添加","Cancel":"取消","Delete":"刪除","Disable":"禁用","Download":"下載","Edit":"編輯","Enable":"開啟","Okay":"好吧","Print":"打印","Refresh":"刷新","Save":"保存","Submit":"提交","Upload":"上傳"}}', Ja = '{"en":{"Filter":"Filter"},"ar":{"Filter":"فيلم"},"az":{"Filter":" Filter"},"bg":{"Filter":"Филтър"},"bn":{"Filter":"ফিল্টার"},"ca":{"Filter":"Filtre"},"cs":{"Filter":"Filtr"},"da":{"Filter":"Filter"},"de":{"Filter":"Filter"},"el":{"Filter":"Φίλτρο"},"eo":{"Filter":"Filtero"},"es":{"Filter":"Filtro"},"et":{"Filter":"Filter"},"eu":{"Filter":"Iragazkia"},"fa":{"Filter":"فیلتر"},"fi":{"Filter":"Suodatin"},"fr":{"Filter":"Filtre"},"ga":{"Filter":"Scagaire"},"gl":{"Filter":"Filtrar"},"he":{"Filter":"Filter"},"hi":{"Filter":"फिल्टर"},"hu":{"Filter":"Szűrő"},"id":{"Filter":"Filter"},"it":{"Filter":"Filtro"},"ja":{"Filter":"フィルター"},"ko":{"Filter":"제품정보"},"lt":{"Filter":"Filtras"},"lv":{"Filter":"Filtrs"},"ms":{"Filter":"Penapis"},"nb":{"Filter":"Filtrer"},"nl":{"Filter":"Filter"},"pl":{"Filter":"Filtr"},"pt":{"Filter":"Filtro"},"ro":{"Filter":"Filtru"},"ru":{"Filter":"Фильтр"},"sk":{"Filter":"Filter"},"sl":{"Filter":"Filter"},"sq":{"Filter":"Filtra"},"sv":{"Filter":"Filter"},"th":{"Filter":"กรอง"},"tl":{"Filter":"Pansala"},"tr":{"Filter":"Filtre"},"uk":{"Filter":"Фільтри"},"ur":{"Filter":"فائلز"},"zh":{"Filter":"过滤器"},"zt":{"Filter":"分頁"}}', Na = '{"en":{"Previous":"Previous","Next":"Next","Older":"Older","Newer":"Newer","GoToPage":"Go To Page"},"ar":{"Previous":"سابقا","Next":"التالي","Older":"كبار","Newer":"Newer","GoToPage":"الذهاب إلى الصفحة"},"az":{"Previous":" Previous","Next":" Next","Older":"Yaşlı","Newer":"Yeniyetmə","GoToPage":"Qeydiyyat"},"bg":{"Previous":"Предишен","Next":"Следващият","Older":"По-","Newer":"По-","GoToPage":"Отиване на страница"},"bn":{"Previous":"পূর্ববর্তী","Next":"পরবর্তী","Older":"বয়স্ক","Newer":"নিউকার","GoToPage":"চিহ্নিত স্থানে চলুন"},"ca":{"Previous":"Anterior","Next":"Següent","Older":"Vella","Newer":"Més","GoToPage":"Vés a la pàgina"},"cs":{"Previous":"Předchozí","Next":"Další","Older":"Starší","Newer":"Novější","GoToPage":"Přejít na stránku"},"da":{"Previous":"Forrige","Next":"Næste","Older":"Ældre","Newer":"Nyere","GoToPage":"Gå til side"},"de":{"Previous":"Vorherige","Next":"Nach","Older":"Ältere","Newer":"Neuer","GoToPage":"Zur Seite gehen"},"el":{"Previous":"Προηγούμενο","Next":"Επόμενο","Older":"Μεγαλύτερος","Newer":"Νεότερα","GoToPage":"Μετάβαση στη σελίδα"},"eo":{"Previous":"Antaŭa","Next":"La","Older":"Pli","Newer":"Pli","GoToPage":"Iru al paĝo"},"es":{"Previous":"Anterior","Next":"Siguiente","Older":"Older","Newer":"Newer","GoToPage":"Ir a la página"},"et":{"Previous":"Eelmine","Next":"Järgmine","Older":"Vanem","Newer":"Uuem","GoToPage":"Mine lehele"},"eu":{"Previous":"Aurrekoa","Next":"Hurrengoa","Older":"Zaharragoa","Newer":"Newer","GoToPage":"Joan orrira"},"fa":{"Previous":"Previous","Next":"بعدی","Older":"مسن","Newer":"Newer","GoToPage":"به صفحه بروید"},"fi":{"Previous":"Edellinen","Next":"Seuraava","Older":"Vanhempi","Newer":"Uusi","GoToPage":"Siirry sivulle"},"fr":{"Previous":"Précédent","Next":"Suivant","Older":"Plus","Newer":"Plus","GoToPage":"Aller à la page"},"ga":{"Previous":"Roimhe","Next":"Ar","Older":"Sean","Newer":"Nuashonraigh","GoToPage":"Téigh go Leathanach"},"gl":{"Previous":"Anterior","Next":"Seguinte","Older":"Idade","Newer":"Newer","GoToPage":"Ir á páxina"},"he":{"Previous":"הקודם","Next":"הבא","Older":"מבוגר","Newer":"חדש","GoToPage":"ללכת לדף"},"hi":{"Previous":"पिछला","Next":"अगला","Older":"पुराना","Newer":"नया","GoToPage":"पृष्ठ पर जाएं"},"hu":{"Previous":"Előző","Next":"Következő","Older":"Idősebb","Newer":"Újabb","GoToPage":"Ugrás az oldalra"},"id":{"Previous":"Sebelumnya","Next":"Berikutnya","Older":"Lebih","Newer":"Baru","GoToPage":"Ke Halaman"},"it":{"Previous":"Precedente","Next":"Il","Older":"Vecchio","Newer":"Nuovo","GoToPage":"Vai alla pagina"},"ja":{"Previous":"新着情報","Next":"次へ","Older":"古い投稿","Newer":"ニュース","GoToPage":"サイトマップ"},"ko":{"Previous":"이름","Next":"이름","Older":"인기있는","Newer":"더","GoToPage":"본문 바로가기"},"lt":{"Previous":"Ankstesnis","Next":"Sekantis","Older":"Senesni","Newer":"Naujokas","GoToPage":"Pereiti į puslapį"},"lv":{"Previous":"Iepriekšējais","Next":"Nākamais","Older":"Vecāki","Newer":"Jaunāks","GoToPage":"Iet uz lapu"},"ms":{"Previous":"Sebelumnya","Next":"Next","Older":"♪","Newer":"Perancis","GoToPage":"Pergi Ke Halaman"},"nb":{"Previous":"Forrige","Next":"Neste","Older":"Eldre","Newer":"Nyere","GoToPage":"Gå til siden"},"nl":{"Previous":"Vorige","Next":"Volgende","Older":"Ouder","Newer":"Nieuwer","GoToPage":"Ga naar pagina"},"pl":{"Previous":"Poprzedni","Next":"Następny","Older":"Starszy","Newer":"Nowsza","GoToPage":"Przejdź do strony"},"pt":{"Previous":"Anterior","Next":"Próximo","Older":"O","Newer":"Mais","GoToPage":"Ir para a página"},"ro":{"Previous":"Precedent","Next":"Înainte","Older":"Mai","Newer":"Mai","GoToPage":"Du-te la pagina"},"ru":{"Previous":"Предыдущий","Next":"Следующий","Older":"Старше","Newer":"Новый","GoToPage":"Перейти на страницу"},"sk":{"Previous":"Predchádzajúca","Next":"Nasledujúci","Older":"Staršie","Newer":"Novšie","GoToPage":"Prejsť na stránku"},"sl":{"Previous":"Prejšnja","Next":"Naprej","Older":"Starejši","Newer":"Novejši","GoToPage":"Pojdi na stran"},"sq":{"Previous":"Paraardhëse","Next":"Në","Older":"Më","Newer":"Ri","GoToPage":"Shko tek faqja"},"sv":{"Previous":"Föregående","Next":"Nästa","Older":"Äldre","Newer":"Nyare","GoToPage":"Gå till Page"},"th":{"Previous":"ก่อนหน้า","Next":"ต่อไป","Older":"อายุ","Newer":"สร้างใหม่","GoToPage":"ไปยังหน้า"},"tl":{"Previous":"Bago","Next":"Susunod","Older":"Mas","Newer":"Mas","GoToPage":"Pumunta sa Pahina"},"tr":{"Previous":"Önceki","Next":"Sonraki","Older":"Yaşlı","Newer":"Newer","GoToPage":"Go To Page"},"uk":{"Previous":"Попереднє","Next":"Про","Older":"Старші","Newer":"Нова","GoToPage":"Перейти на сторінку"},"ur":{"Previous":"پہلے","Next":"اگلا","Older":"عمررسیدہ","Newer":"نیا","GoToPage":"صفحہ ۲۴ پر جائیں"},"zh":{"Previous":"上一个","Next":"下一个","Older":"老年人","Newer":"更新","GoToPage":"转到页面"},"zt":{"Previous":"前一個","Next":"下一頁","Older":"老了","Newer":"更新","GoToPage":"跳至頁面"}}', wa = `{"en":{"Weekdays":{"Sun":"Sun","Mon":"Mon","Tue":"Tue","Wed":"Wed","Thu":"Thu","Fri":"Fri","Sat":"Sat","Sunday":"Sunday","Monday":"Monday","Tuesday":"Tuesday","Wednesday":"Wednesday","Thursday":"Thursday","Friday":"Friday","Saturday":"Saturday"},"Months":{"Jan":"Jan","Feb":"Feb","Mar":"Mar","Apr":"Apr","May":"May","Jun":"Jun","Jul":"Jul","Aug":"Aug","Sep":"Sep","Oct":"Oct","Nov":"Nov","Dec":"Dec","January":"January","February":"February","March":"March","April":"April","June":"June","July":"July","August":"August","September":"September","October":"October","November":"November","December":"December"},"Today":"Today"},"ar":{"Weekdays":{"Sun":"الشمس","Mon":"مون","Tue":"Tue","Wed":"Wed","Thu":"Thu","Fri":"فري","Sat":"Sat","Sunday":"الأحد","Monday":"الاثنين","Tuesday":"الثلاثاء","Wednesday":"الأربعاء","Thursday":"الخميس","Friday":"الجمعة","Saturday":"السبت"},"Months":{"Jan":"يان","Feb":"شباط/فبراير","Mar":"Mar","Apr":"Apr","May":"أيار/مايو","Jun":"جون","Jul":"(جول)","Aug":"آب/أغسطس","Sep":"Sep","Oct":"Oct","Nov":"Nov","Dec":"Dec","January":"كانون","February":"شباط/فبراير","March":"آذار/مارس","April":"نيسان/أبريل","June":"حزيران/يونيه","July":"تموز/يوليه","August":"آب/أغسطس","September":"أيلول/سبتمبر","October":"تشرين","November":"تشرين","December":"كانون"},"Today":"اليوم"},"az":{"Weekdays":{"Sun":"Qalereya","Mon":"Bakı","Tue":"Qalereya","Wed":"Biznes","Thu":"Qalereya","Fri":"Bakı","Sat":"Bakı","Sunday":"Bakı","Monday":"Bakı","Tuesday":"Bakı","Wednesday":"Bakı","Thursday":"Bakı","Friday":"Bakı","Saturday":"Bakı"},"Months":{"Jan":"Axtarış","Feb":"Bakı","Mar":"Bakı","Apr":"Bakı","May":"İyul","Jun":"Bakı","Jul":"Bakı","Aug":"Axtarış","Sep":"Bakı","Oct":"Axtarış","Nov":"Bakı","Dec":"Elan","January":"Yanvar","February":"Fevral","March":"Bakı","April":"Bakı","June":"İyun","July":"İyul","August":"Avqust","September":"Bakı","October":"Bakı","November":"Bakı","December":"Bakı"},"Today":"Bu"},"bg":{"Weekdays":{"Sun":"Слънце","Mon":"Мон","Tue":"Туе","Wed":"Сватба","Thu":"Thu","Fri":"Fri","Sat":"Сат","Sunday":"Неделя","Monday":"Понеделник","Tuesday":"Вторник","Wednesday":"Сряда","Thursday":"Четвъртък","Friday":"Петък","Saturday":"Събота"},"Months":{"Jan":"Ян","Feb":"Февруари","Mar":"Мар","Apr":"Apr","May":"Май","Jun":"Джун","Jul":"Юли","Aug":"Aug","Sep":"Сеп","Oct":"Окт","Nov":"Nov","Dec":"Дек","January":"Януари","February":"Февруари","March":"Март","April":"Април","June":"Юни","July":"Юли","August":"Август","September":"Септември","October":"Октомври","November":"Ноември","December":"Декември"},"Today":"Днес"},"bn":{"Weekdays":{"Sun":"রবি","Mon":"মন","Tue":"মঙ্গল","Wed":"অস্বীকৃত","Thu":"বৃহঃ","Fri":"ফ্রিসেল","Sat":"শনি","Sunday":"রবিবার","Monday":"সোমবার","Tuesday":"মঙ্গলবার","Wednesday":"বুধবার","Thursday":"বৃহস্পতিবার","Friday":"শুক্রবার","Saturday":"শনিবার"},"Months":{"Jan":"জানুয়ারী","Feb":"ফেব্রুয়ারীMarch","Mar":"মার্চApril","Apr":"এপ্রিল","May":"মে","Jun":"জুনিউ","Jul":"জুমি","Aug":"আগস্ট","Sep":"সেপ্টেম্বরOctober","Oct":"অক্টোবর","Nov":"নভেম্বর","Dec":"ডিসেম্বর","January":"জানুয়ারী","February":"ফেব্রুয়ারী","March":"মার্চ","April":"এপ্রিল","June":"জুন","July":"জুলাই","August":"আগস্ট","September":"সেপ্টেম্বর","October":"অক্টোবর","November":"নভেম্বর","December":"সদস্য"},"Today":"আজ"},"ca":{"Weekdays":{"Sun":"Sol","Mon":"Dl","Tue":"Dt","Wed":"Dc","Thu":"Dj","Fri":"DvSaturday","Sat":"DsSunday","Sunday":"Diumenge","Monday":"Dilluns","Tuesday":"Dimarts","Wednesday":"Dimecres","Thursday":"Dijous","Friday":"Divendres","Saturday":"Dissabte"},"Months":{"Jan":"Mare","Feb":"FebMarch","Mar":"Mar","Apr":"AbrMay","May":"Maig","Jun":"JunJuly","Jul":"JulAugust","Aug":"AgoSeptember","Sep":"Set","Oct":"Oct","Nov":"Nov","Dec":"Des","January":"Gener","February":"Febrer","March":"Març","April":"Abril","June":"Juny","July":"Juliol","August":"Agost","September":"Setembre","October":"Octubre","November":"Novembre","December":"Desembre"},"Today":"Avui"},"cs":{"Weekdays":{"Sun":"Slunce","Mon":"Po","Tue":"Tue","Wed":"St","Thu":"Thu","Fri":"Fri","Sat":"Sad","Sunday":"Neděle","Monday":"Pondělí","Tuesday":"Úterý","Wednesday":"Středa","Thursday":"Čtvrtek","Friday":"Pátek","Saturday":"Sobota"},"Months":{"Jan":"Jan","Feb":"Únor","Mar":"Březen","Apr":"Duben","May":"May","Jun":"Jun","Jul":"Jul","Aug":"Srpen","Sep":"Září","Oct":"Říjen","Nov":"Listopad","Dec":"Prosinec","January":"Leden","February":"Únor","March":"Březen","April":"Duben","June":"Červen","July":"Červenec","August":"Srpen","September":"Září","October":"Říjen","November":"Listopad","December":"Prosinec"},"Today":"Dnes"},"da":{"Weekdays":{"Sun":"Sol","Mon":"Mon","Tue":"Tir","Wed":"On","Thu":"Thu","Fri":"Fri","Sat":"Lø","Sunday":"Søndag","Monday":"Mandag","Tuesday":"Tirsdag","Wednesday":"Onsdag","Thursday":"Torsdag","Friday":"Fredag","Saturday":"Lørdag"},"Months":{"Jan":"Jan","Feb":"Feb","Mar":"Mar","Apr":"Apr","May":"Maj","Jun":"Jun","Jul":"Jul","Aug":"Aug","Sep":"Sep","Oct":"Okt","Nov":"Nov","Dec":"Dec","January":"Januar","February":"Februar","March":"Marts","April":"April","June":"Juni","July":"Juli","August":"August","September":"September","October":"Oktober","November":"November","December":"December"},"Today":"I"},"de":{"Weekdays":{"Sun":"Sonne","Mon":"Mo","Tue":"Di","Wed":"Mi","Thu":"Do","Fri":"Fri","Sat":"Sa","Sunday":"Sonntag","Monday":"Montag","Tuesday":"Dienstag","Wednesday":"Mittwoch","Thursday":"Donnerstag","Friday":"Freitag","Saturday":"Samstag"},"Months":{"Jan":"Jan","Feb":"Feb","Mar":"Mär","Apr":"Apr","May":"Mai","Jun":"Jun","Jul":"Juli","Aug":"Aug","Sep":"Sep","Oct":"Okt","Nov":"Nov","Dec":"Dez","January":"Januar","February":"Februar","March":"März","April":"April","June":"Juni","July":"Juli","August":"August","September":"September","October":"Oktober","November":"November","December":"Dezember"},"Today":"Heute"},"el":{"Weekdays":{"Sun":"Ήλιος","Mon":"Δευ","Tue":"Τεύχος","Wed":"Τετ","Thu":"Θου","Fri":"Παρ","Sat":"Σάβ","Sunday":"Κυριακή","Monday":"Δευτέρα","Tuesday":"Τρίτη","Wednesday":"Τετάρτη","Thursday":"Πέμπτη","Friday":"Παρασκευή","Saturday":"Σάββατο"},"Months":{"Jan":"Ιαν","Feb":"Φεβ","Mar":"Μαρ","Apr":"Απρ","May":"Μάιος","Jun":"Ιουν","Jul":"Ιουλ","Aug":"Αυγ","Sep":"Σεπ","Oct":"Οκτ","Nov":"Νοε","Dec":"Δεκ","January":"Ιανουάριος","February":"Φεβρουάριος","March":"Μάρτιος","April":"Απρίλιος","June":"Ιούνιος","July":"Ιούλιος","August":"Αύγουστος","September":"Σεπτέμβριος","October":"Οκτώβριος","November":"Νοέμβριος","December":"Δεκέμβριος"},"Today":"Σήμερα"},"eo":{"Weekdays":{"Sun":"Suno","Mon":"Mon","Tue":"Tue","Wed":"Ni","Thu":"Tumulto","Fri":"Frio","Sat":"Sidanta","Sunday":"Dimanĉo","Monday":"Lundo","Tuesday":"Marŝi","Wednesday":"Merkredo","Thursday":"Ĵaŭdon","Friday":"Vendrede","Saturday":"Sabato"},"Months":{"Jan":"Jan","Feb":"Feb","Mar":"Marŝa","Apr":"Apr","May":"Majo","Jun":"Jun","Jul":"Jul","Aug":"Aŭgusto","Sep":"Sep","Oct":"Oktobro","Nov":"Nov-Zelando","Dec":"Dec","January":"Januaro","February":"Februaro","March":"Marto","April":"April","June":"Junio","July":"Julio","August":"Aŭgusto","September":"Septembro","October":"Oktobro","November":"Novembro","December":"Decembro"},"Today":"Hodiaŭ"},"es":{"Weekdays":{"Sun":"Sol","Mon":"Mon","Tue":"Tue","Wed":"Wed","Thu":"Thu","Fri":"Fri","Sat":"Sat","Sunday":"Domingo","Monday":"Lunes","Tuesday":"Martes","Wednesday":"Miércoles","Thursday":"Jueves","Friday":"Viernes","Saturday":"Sábado"},"Months":{"Jan":"Jan","Feb":"Feb","Mar":"Mar","Apr":"Apr","May":"Mayo","Jun":"Jun","Jul":"Jul","Aug":"Aug","Sep":"Sep","Oct":"Oct","Nov":"Nov","Dec":"Dec","January":"Enero","February":"Febrero","March":"Marzo","April":"Abril","June":"Junio","July":"Julio","August":"Agosto","September":"Septiembre","October":"Octubre","November":"Noviembre","December":"Diciembre"},"Today":"Hoy"},"et":{"Weekdays":{"Sun":"Päike","Mon":"Mon","Tue":"Tue","Wed":"Wed","Thu":"Thu","Fri":"Fri","Sat":"Sattus","Sunday":"Pühapäev","Monday":"Esmaspäev","Tuesday":"Teisipäev","Wednesday":"Kolmapäev","Thursday":"Neljapäeval","Friday":"Reede","Saturday":"Laupäev"},"Months":{"Jan":"Jan","Feb":"Veebruar","Mar":"Mar","Apr":"Apr","May":"May","Jun":"Jun","Jul":"Jul","Aug":"Aug","Sep":"Sep","Oct":"Oktoober","Nov":"Nov","Dec":"Dec","January":"Jaanuar","February":"Veebruar","March":"Märts","April":"Aprill","June":"Juuni","July":"Juuli","August":"August","September":"September","October":"Oktoober","November":"November","December":"Detsember"},"Today":"Täna"},"eu":{"Weekdays":{"Sun":"Sun","Mon":"Mon","Tue":"Tue","Wed":"Apustua","Thu":"Og","Fri":"Fri","Sat":"Sat","Sunday":"Igandea","Monday":"Astelehena","Tuesday":"Asteartea","Wednesday":"Asteazkena","Thursday":"Osteguna","Friday":"Ostirala","Saturday":"Larunbata"},"Months":{"Jan":"Jan","Feb":"Ots","Mar":"Marmar","Apr":"Apr","May":"Maiatza","Jun":"Jun","Jul":"Jul","Aug":"Abusua","Sep":"Ira","Oct":"Oct","Nov":"Aza","Dec":"Abendua","January":"Urtarrila","February":"Otsaila","March":"Martxoa","April":"Apirila","June":"Ekaina","July":"Uztaila","August":"Abuztua","September":"Iraila","October":"Urria","November":"Azaroa","December":"Abendua"},"Today":"Gaur"},"fa":{"Weekdays":{"Sun":"خورشید","Mon":"مون","Tue":"Tue","Wed":"Wed","Thu":"تو","Fri":"Fri","Sat":"Sat","Sunday":"یکشنبه","Monday":"دوشنبه","Tuesday":"سه","Wednesday":"چهارشنبه","Thursday":"پنجشنبه","Friday":"جمعه","Saturday":"شنبه"},"Months":{"Jan":"ژانویه","Feb":"فوریه","Mar":"Mar","Apr":"آوریل","May":"ممکن","Jun":"Jun","Jul":"جول","Aug":"آگوست","Sep":"سپتامبر","Oct":"اکتبر","Nov":"نوامبر","Dec":"دسامبر","January":"ژانویه","February":"فوریه","March":"مارس","April":"آوریل","June":"ژوئن","July":"جولای","August":"آگوست","September":"سپتامبر","October":"اکتبر","November":"نوامبر","December":"دسامبر"},"Today":"امروز"},"fi":{"Weekdays":{"Sun":"Su","Mon":"Ma","Tue":"Ti","Wed":"Ke","Thu":"To","Fri":"Pe","Sat":"La","Sunday":"Sunnuntai","Monday":"Maanantai","Tuesday":"Tiistai","Wednesday":"Keskiviikko","Thursday":"Torstai","Friday":"Perjantai","Saturday":"Lauantai"},"Months":{"Jan":"Tammi","Feb":"Helmi","Mar":"Maalis","Apr":"Huhti","May":"Toukokuu","Jun":"Kesä","Jul":"Heinä","Aug":"Elo","Sep":"Syys","Oct":"Loka","Nov":"Marras","Dec":"Joulu","January":"Tammikuu","February":"Helmikuu","March":"Maaliskuu","April":"Huhtikuu","June":"Kesäkuu","July":"Heinäkuu","August":"Elokuu","September":"Syyskuu","October":"Lokakuu","November":"Marraskuu","December":"Joulukuu"},"Today":"Tänään"},"fr":{"Weekdays":{"Sun":"Soleil","Mon":"Mon","Tue":"Tu","Wed":"Mariage","Thu":"Jeu","Fri":"Ven","Sat":"Sat","Sunday":"Dimanche","Monday":"Lundi","Tuesday":"Mardi","Wednesday":"Mercredi","Thursday":"Jeudi","Friday":"Vendredi","Saturday":"Samedi"},"Months":{"Jan":"Janvier","Feb":"Fév","Mar":"Mars","Apr":"Avr","May":"Mai","Jun":"Juin","Jul":"Juillet","Aug":"Août","Sep":"Sep","Oct":"Oct","Nov":"Nov","Dec":"Déc","January":"Janvier","February":"Février","March":"Mars","April":"Avril","June":"Juin","July":"Juillet","August":"Août","September":"Septembre","October":"Octobre","November":"Novembre","December":"Décembre"},"Today":"Aujourd'hui"},"ga":{"Weekdays":{"Sun":"Ghrian","Mon":"Uisce","Tue":"Déan","Wed":"Táimid","Thu":"Thuama","Fri":"Múirín","Sat":"Sábháil","Sunday":"Domhnach","Monday":"Dé","Tuesday":"Dé","Wednesday":"Dé","Thursday":"Déardaoin","Friday":"Dé","Saturday":"Dé"},"Months":{"Jan":"An","Feb":"Is","Mar":"Mar","Apr":"Aibreán","May":"Bealtaine","Jun":"Amharc","Jul":"Jul","Aug":"Lúnasa","Sep":"Meán","Oct":"Deireadh","Nov":"Cineál","Dec":"Déan","January":"Irl","February":"Amharc","March":"Márta","April":"Amharc","June":"Meitheamh","July":"Irl","August":"Amharc","September":"Meán","October":"Deireadh","November":"Samhain","December":"Nollaig"},"Today":"Sa"},"gl":{"Weekdays":{"Sun":"Sol","Mon":"Mon","Tue":"Tue","Wed":"Apostamos","Thu":"Tu","Fri":"Frio","Sat":"Sat","Sunday":"Domingo","Monday":"Luns","Tuesday":"Martes","Wednesday":"Miércoles","Thursday":"Xoves","Friday":"Venres","Saturday":"Sábado"},"Months":{"Jan":"Jan","Feb":"Febreiro","Mar":"Mar","Apr":"Abril","May":"Maio","Jun":"Jun","Jul":"Xullo","Aug":"Aug","Sep":"Sep","Oct":"Oct","Nov":"Novidade","Dec":"Dec","January":"Xaneiro","February":"Febreiro","March":"Marzo","April":"Abril","June":"Xuño","July":"Xullo","August":"Agosto","September":"Setembro","October":"Outubro","November":"Novembro","December":"Decembro"},"Today":"Hoxe"},"he":{"Weekdays":{"Sun":"השמש","Mon":"מונמון","Tue":"Tue","Wed":"Wed","Thu":"תור","Fri":"פרי","Sat":"Sat","Sunday":"יום","Monday":"יום","Tuesday":"יום","Wednesday":"יום","Thursday":"יום","Friday":"יום","Saturday":"יום"},"Months":{"Jan":"יאן","Feb":"פברואר","Mar":"Mar","Apr":"אנגלית","May":"במאי","Jun":"ג'ון","Jul":"יולי","Aug":"אוגוסט","Sep":"ספרד","Oct":"באוקטובר","Nov":"נובמבר","Dec":"דצמבר","January":"ינואר","February":"פברואר","March":"מרץ","April":"אפריל","June":"יוני","July":"יולי","August":"אוגוסט","September":"ספטמבר","October":"אוקטובר","November":"נובמבר","December":"דצמבר"},"Today":"היום"},"hi":{"Weekdays":{"Sun":"सूर्य","Mon":"सोम","Tue":"मंगल","Wed":"Wed","Thu":"गुरु","Fri":"शुक्र","Sat":"सत","Sunday":"रविवार","Monday":"सोमवार","Tuesday":"मंगलवार","Wednesday":"बुधवार","Thursday":"गुरुवार","Friday":"शुक्रवार","Saturday":"शनिवार"},"Months":{"Jan":"जनवरी","Feb":"फ़रवरी","Mar":"मार्च","Apr":"अप्रैल","May":"मई","Jun":"जून","Jul":"जुलाई","Aug":"अगस्त","Sep":"सितंबर","Oct":"अक्टूबर","Nov":"नवम्बर","Dec":"दिसम्बर","January":"जनवरी","February":"फ़रवरी","March":"मार्च","April":"अप्रैल","June":"जून","July":"जुलाई","August":"अगस्त","September":"सितंबर","October":"अक्टूबर","November":"नवंबर","December":"दिसम्बर"},"Today":"आज"},"hu":{"Weekdays":{"Sun":"Nap","Mon":"H","Tue":"Sze","Wed":"Wed","Thu":"Thu","Fri":"Fri","Sat":"Sat","Sunday":"Vasárnap","Monday":"Hétfő","Tuesday":"Kedd","Wednesday":"Szerda","Thursday":"Csütörtök","Friday":"Péntek","Saturday":"Szombat"},"Months":{"Jan":"Jan","Feb":"Feb","Mar":"Mar","Apr":"Apr","May":"Május","Jun":"Jun","Jul":"Jul","Aug":"Aug","Sep":"Sz","Oct":"Okt","Nov":"Nov","Dec":"Dec","January":"Január","February":"Február","March":"Március","April":"Április","June":"Június","July":"Július","August":"Augusztus","September":"Szeptember","October":"Október","November":"November","December":"December"},"Today":"Ma"},"id":{"Weekdays":{"Sun":"Matahari","Mon":"Mon","Tue":"Tue","Wed":"Busana","Thu":"Thu","Fri":"Fri","Sat":"Sab","Sunday":"Minggu","Monday":"Senin","Tuesday":"Selasa","Wednesday":"Rabu","Thursday":"Kamis","Friday":"Jumat","Saturday":"Sabtu"},"Months":{"Jan":"Jan","Feb":"Feb","Mar":"Mar","Apr":"Apr","May":"Mei","Jun":"Jun","Jul":"Jul","Aug":"Aug","Sep":"Sep","Oct":"Okt","Nov":"Nov","Dec":"Dec","January":"Januari","February":"Februari","March":"Maret","April":"April","June":"Juni","July":"Juli","August":"Agustus","September":"September","October":"Oktober","November":"November","December":"Desember"},"Today":"Hari"},"it":{"Weekdays":{"Sun":"Sole","Mon":"Mon","Tue":"Tue","Wed":"Wed","Thu":"Gio","Fri":"Fri","Sat":"Rasoio","Sunday":"Domenica","Monday":"Lunedì","Tuesday":"Martedì","Wednesday":"Mercoledì","Thursday":"Giovedì","Friday":"Venerdì","Saturday":"Sabato"},"Months":{"Jan":"Jan","Feb":"Febbraio","Mar":"Mar","Apr":"Aprile","May":"Maggio","Jun":"Jun","Jul":"Jul","Aug":"Agosto","Sep":"Articolo","Oct":"Ottobre","Nov":"No","Dec":"Dec","January":"Gennaio","February":"Febbraio","March":"Marzo","April":"Aprile","June":"Giugno","July":"Luglio","August":"Agosto","September":"Settembre","October":"Ottobre","November":"Novembre","December":"Dicembre"},"Today":"Oggi"},"ja":{"Weekdays":{"Sun":"日曜日","Mon":"モンド","Tue":"火曜日","Wed":"お問い合わせ","Thu":"日","Fri":"フリガナ","Sat":"スタッフ","Sunday":"日曜日","Monday":"月曜日～金曜日","Tuesday":"火曜日","Wednesday":"水曜日","Thursday":"木曜日","Friday":"金曜日","Saturday":"土曜日"},"Months":{"Jan":"1月1日","Feb":"1月2日","Mar":"マーキー","Apr":"4月4日","May":"5月5日","Jun":"ジュンジュン","Jul":"7月7日","Aug":"8月8日","Sep":"9月9日","Oct":"10月10日","Nov":"11月11日","Dec":"12月12日","January":"1月1日","February":"2月2日","March":"3月3日","April":"4月4日","June":"6月6日","July":"7月7日","August":"8月8日","September":"9月9日","October":"10月10日","November":"11月11日","December":"12月12日"},"Today":"今日更新"},"ko":{"Weekdays":{"Sun":"(주)","Mon":"담당자","Tue":" ","Wed":"사이트맵","Thu":"₢","Fri":"₢","Sat":"·","Sunday":"주","Monday":"월요일,","Tuesday":"*","Wednesday":"-","Thursday":"주","Friday":"월~금","Saturday":"·"},"Months":{"Jan":"1","Feb":"2월","Mar":"3","Apr":"4","May":"5","Jun":"주","Jul":"7","Aug":"8","Sep":"9월","Oct":"10월","Nov":"11월","Dec":"12월","January":"1월","February":"2","March":"3","April":"4","June":"6월","July":"7","August":"8","September":"9","October":"10월","November":"11","December":"12"},"Today":"으로"},"lt":{"Weekdays":{"Sun":"Saulė","Mon":"Mon","Tue":"Tue","Wed":"WEd","Thu":"Thu","Fri":"FrNAME","Sat":"Sat","Sunday":"Sekmadienis","Monday":"Pirmadienis","Tuesday":"Antradienis","Wednesday":"Trečiadienis","Thursday":"Ketvirtadienis","Friday":"Penktadienis","Saturday":"Šeštadienis"},"Months":{"Jan":"Sau","Feb":"Vas","Mar":"Mar","Apr":"Bal","May":"Gegužės","Jun":"Bir","Jul":"Lie","Aug":"Rgp","Sep":"Rp","Oct":"Spalis","Nov":"Nr","Dec":"Gruodis","January":"Sausis","February":"Vasaris","March":"Kovas","April":"Balandis","June":"Birželis","July":"Liepa","August":"Rugpjūtis","September":"Rugsėjis","October":"Spalis","November":"Lapkritis","December":"Gruodis"},"Today":"Šiandien"},"lv":{"Weekdays":{"Sun":"Saule","Mon":"N","Tue":"Otr","Wed":"Tre","Thu":"Cet","Fri":"Pie","Sat":"Ses","Sunday":"Svētdiena","Monday":"Pirmdiena","Tuesday":"Otrdiena","Wednesday":"Trešdiena","Thursday":"Ceturtdiena","Friday":"Piektdiena","Saturday":"Sestdiena"},"Months":{"Jan":"Janvāris","Feb":"Febr","Mar":"Mar","Apr":"Apr","May":"Maijs","Jun":"Jūn","Jul":"Jūl","Aug":"Aug","Sep":"Sept","Oct":"Okt","Nov":"Nov","Dec":"Dec","January":"Janvāris","February":"Februāris","March":"Marts","April":"Aprīlis","June":"Jūnijs","July":"Jūlijs","August":"Augusts","September":"Septembris","October":"Oktobris","November":"Novembris","December":"Decembris"},"Today":"Šodien"},"ms":{"Weekdays":{"Sun":"Sun","Mon":"Mon","Tue":"Perancis","Wed":"♪","Thu":"Khaw","Fri":"Perancis","Sat":"♪","Sunday":"Ahad","Monday":"Isnin","Tuesday":"Selasa","Wednesday":"Rabu","Thursday":"Khamis","Friday":"Jumat","Saturday":"Sabtu"},"Months":{"Jan":"Jan","Feb":"Perancis","Mar":"Perancis","Apr":"Apr","May":"Mei","Jun":"Juni","Jul":"♪","Aug":"Aug","Sep":"Perancis","Oct":"Takh","Nov":"Nov","Dec":"Amerika","January":"Januari","February":"2010,","March":"2010,","April":"April","June":"Juni","July":"Juli","August":"Ogos","September":"Perancis","October":"Oktober","November":"November","December":"Amerika"},"Today":"Hari"},"nb":{"Weekdays":{"Sun":"Sun","Mon":"Mon","Tue":"Tue","Wed":"Wed","Thu":"Thu","Fri":"Fri","Sat":"Sat","Sunday":"Søndag","Monday":"Mandag","Tuesday":"Tirsdag","Wednesday":"Onsdag","Thursday":"Torsdag","Friday":"Fredag","Saturday":"Lørdag"},"Months":{"Jan":"Jan","Feb":"Feb","Mar":"Mar","Apr":"Apr","May":"Mai","Jun":"Jun","Jul":"Jul","Aug":"Aug","Sep":"Sep","Oct":"Okt","Nov":"Nov","Dec":"Dec","January":"Januar","February":"Februar","March":"Mars","April":"April","June":"Juni","July":"Juli","August":"August","September":"September","October":"Oktober","November":"November","December":"Desember"},"Today":"I"},"nl":{"Weekdays":{"Sun":"Zon","Mon":"Ma","Tue":"Di","Wed":"Wo","Thu":"Do","Fri":"Vr","Sat":"Zat","Sunday":"Zondag","Monday":"Maandag","Tuesday":"Dinsdag","Wednesday":"Woensdag","Thursday":"Donderdag","Friday":"Vrijdag","Saturday":"Zaterdag"},"Months":{"Jan":"Jan","Feb":"Feb","Mar":"Mar","Apr":"Apr","May":"Mei","Jun":"Juni","Jul":"Jul","Aug":"Aug","Sep":"Sep","Oct":"Okt","Nov":"Nov","Dec":"Dec","January":"Januari","February":"Februari","March":"Maart","April":"April","June":"Juni","July":"Juli","August":"Augustus","September":"September","October":"Oktober","November":"November","December":"December"},"Today":"Vandaag"},"pl":{"Weekdays":{"Sun":"Słońce","Mon":"Mon","Tue":"Wtyczka","Wed":"Środ","Thu":"Thu","Fri":"Fri","Sat":"Sat","Sunday":"Niedziela","Monday":"Poniedziałek","Tuesday":"Wtorek","Wednesday":"Środa","Thursday":"Czwartek","Friday":"Piątek","Saturday":"Sobota"},"Months":{"Jan":"Jan","Feb":"Luty","Mar":"Mar","Apr":"Kwiecień","May":"Maj","Jun":"Czerwiec","Jul":"Lipiec","Aug":"Sierpień","Sep":"Wrzesień","Oct":"Październik","Nov":"Nov","Dec":"Grudzień","January":"Styczeń","February":"Luty","March":"Marzec","April":"Kwiecień","June":"Czerwiec","July":"Lipiec","August":"Sierpień","September":"Wrzesień","October":"Październik","November":"Listopad","December":"Grudzień"},"Today":"Dzisiaj"},"pt":{"Weekdays":{"Sun":"Sol","Mon":"Monsenhor","Tue":"Tue","Wed":"Wed","Thu":"Tu","Fri":"Frio","Sat":"Satisfeito","Sunday":"Domingo","Monday":"Segunda-feira","Tuesday":"Terça-feira","Wednesday":"Quarta-feira","Thursday":"Quinta-feira","Friday":"Sexta-feira","Saturday":"Sábado"},"Months":{"Jan":"Jan","Feb":"Fev","Mar":"Mar","Apr":"Abr","May":"Maio","Jun":"Jun","Jul":"Jul","Aug":"A","Sep":"Sep","Oct":"O","Nov":"Não","Dec":"Dez","January":"Janeiro","February":"Fevereiro","March":"Março","April":"Abril","June":"Junho","July":"Julho","August":"Agosto","September":"Setembro","October":"Outubro","November":"Novembro","December":"Dezembro"},"Today":"Hoje"},"ro":{"Weekdays":{"Sun":"Soare","Mon":"Luni","Tue":"Tue","Wed":"Căsătorie","Thu":"Thu","Fri":"Vine","Sat":"Sat","Sunday":"Duminică","Monday":"Luni","Tuesday":"Marţi","Wednesday":"Miercuri","Thursday":"Joi","Friday":"Vineri","Saturday":"Sâmbătă"},"Months":{"Jan":"Jan","Feb":"Februarie","Mar":"Mar","Apr":"Apr","May":"May","Jun":"Jun","Jul":"Jul","Aug":"Aug","Sep":"Sep","Oct":"Oct","Nov":"Nov","Dec":"Dec","January":"Ianuarie","February":"Februarie","March":"Martie","April":"Aprilie","June":"Iunie","July":"Iulie","August":"August","September":"Septembrie","October":"Octombrie","November":"Noiembrie","December":"Decembrie"},"Today":"Astăzi"},"ru":{"Weekdays":{"Sun":"Солнце","Mon":"Мон","Tue":"Туи","Wed":"Свадьба","Thu":"Ту","Fri":"Фри","Sat":"Сидеть","Sunday":"Воскресенье","Monday":"Понедельник","Tuesday":"Вторник","Wednesday":"Среда","Thursday":"Четверг","Friday":"Пятница","Saturday":"Суббота"},"Months":{"Jan":"Ян","Feb":"Февраль","Mar":"Мар","Apr":"Апр","May":"Май","Jun":"Джун","Jul":"Джул","Aug":"Ауг","Sep":"Сеп","Oct":"Октября","Nov":"Ноябрь","Dec":"Декларация","January":"Январь","February":"Февраль","March":"Март","April":"Апрель","June":"Июнь","July":"Июль","August":"Август","September":"Сентябрь","October":"Октября","November":"Ноябрь","December":"Декабрь"},"Today":"Сегодня"},"sk":{"Weekdays":{"Sun":"Slnko","Mon":"Po","Tue":"Ut","Wed":"Str","Thu":"Št","Fri":"Pi","Sat":"So","Sunday":"Nedeľa","Monday":"Pondelok","Tuesday":"Utorok","Wednesday":"Streda","Thursday":"Štvrtok","Friday":"Piatok","Saturday":"Sobota"},"Months":{"Jan":"Jan","Feb":"Feb","Mar":"Mar","Apr":"Apríl","May":"Máj","Jun":"Jún","Jul":"Júl","Aug":"August","Sep":"Sep","Oct":"Okt","Nov":"Nov","Dec":"Dec","January":"Január","February":"Február","March":"Marec","April":"Apríl","June":"Jún","July":"Júl","August":"August","September":"September","October":"Október","November":"November","December":"December"},"Today":"Dnes"},"sl":{"Weekdays":{"Sun":"Sonce","Mon":"Naslednji","Tue":"Tor","Wed":"Sre","Thu":"Čet","Fri":"Fri","Sat":"Sob","Sunday":"Nedelja","Monday":"Ponedeljek","Tuesday":"Torek","Wednesday":"Sreda","Thursday":"Četrtek","Friday":"Petek","Saturday":"Sobota"},"Months":{"Jan":"Jan","Feb":"Feb","Mar":"Mar","Apr":"Apr","May":"Maj","Jun":"Jun","Jul":"Jul","Aug":"Avg","Sep":"Sep","Oct":"Okt","Nov":"Nov","Dec":"Dec","January":"Januar","February":"Februar","March":"Marec","April":"April","June":"Junij","July":"Julij","August":"Avgust","September":"September","October":"Oktober","November":"November","December":"December"},"Today":"Danes"},"sq":{"Weekdays":{"Sun":"Dielli","Mon":"Mon","Tue":"Tue","Wed":"Mer","Thu":"Tsu","Fri":"Pre","Sat":"Sat","Sunday":"E","Monday":"E","Tuesday":"E","Wednesday":"E","Thursday":"E","Friday":"E","Saturday":"E"},"Months":{"Jan":"Jan","Feb":"Fb","Mar":"Meri","Apr":"Për","May":"Maj","Jun":"Jun","Jul":"Jul","Aug":"Aug","Sep":"Sep","Oct":"Tetor","Nov":"Nov","Dec":"Dhjetor","January":"Janar","February":"Shkurt","March":"Mars","April":"Prill","June":"Qershor","July":"Korrik","August":"Gusht","September":"Shtator","October":"Tetor","November":"Nëntor","December":"Dhjetor"},"Today":"Sot"},"sv":{"Weekdays":{"Sun":"Sol","Mon":"Mon","Tue":"Tue","Wed":"Wed","Thu":"Thu","Fri":"Fri","Sat":"Sattar","Sunday":"Söndag","Monday":"Måndag","Tuesday":"Tisdag","Wednesday":"Onsdag","Thursday":"Torsdag","Friday":"Fredag","Saturday":"Lördag"},"Months":{"Jan":"Jan","Feb":"Feb","Mar":"Mar","Apr":"Apr","May":"Maj","Jun":"Jun","Jul":"Jul","Aug":"Aug","Sep":"Sep","Oct":"Okt","Nov":"Nov","Dec":"Dec","January":"Januari","February":"Februari","March":"Mars","April":"April","June":"Juni","July":"Juli","August":"Augusti","September":"September","October":"Oktober","November":"November","December":"December"},"Today":"Idag"},"th":{"Weekdays":{"Sun":"อาทิตย์","Mon":"นิ้ว","Tue":"Tue","Wed":"เว็บ","Thu":"ทู","Fri":"เนื้อ","Sat":"ที่นั่ง","Sunday":"อาทิตย์","Monday":"จันทร์","Tuesday":"อังคาร","Wednesday":"วันพุธ","Thursday":"พฤหัสบดี","Friday":"ศุกร์","Saturday":"เสาร์"},"Months":{"Jan":"ไม่นะ","Feb":"ก.","Mar":"ขนาด","Apr":"ขนาด","May":"พฤษภาคม","Jun":"จุน","Jul":"ก.","Aug":"อัก","Sep":"เซพ","Oct":"ตลับหมึก","Nov":"นอฟ","Dec":"ธ.","January":"มกราคม","February":"กุมภาพันธ์","March":"มีนาคม","April":"เมษายน","June":"มิถุนายน","July":"กรกฎาคม","August":"สิงหาคม","September":"กันยายน","October":"ตุลาคม","November":"พฤศจิกายน","December":"ธันวาคม"},"Today":"วันนี้"},"tl":{"Weekdays":{"Sun":"Araw","Mon":"Buwan","Tue":"Tue","Wed":"Damo","Thu":"Thu","Fri":"Kaibigan","Sat":"Sat","Sunday":"Linggo","Monday":"Lunes","Tuesday":"Martes","Wednesday":"Miyerkules","Thursday":"Huwebes","Friday":"Biyernes","Saturday":"Sabado"},"Months":{"Jan":"Jan","Feb":"Sanggol","Mar":"Mar","Apr":"Apr","May":"Mayo","Jun":"Jun","Jul":"Juul","Aug":"Ug","Sep":"Sep","Oct":"Oct","Nov":"Nov","Dec":"Pagpapasiya","January":"Enero","February":"Pebrero","March":"Marso","April":"Abril","June":"Hunyo","July":"Hulyo","August":"Agosto","September":"Setyembre","October":"Oktubre","November":"Nobyembre","December":"Disyembre"},"Today":"Ngayon"},"tr":{"Weekdays":{"Sun":"Güneş","Mon":"Mon","Tue":"Tue","Wed":"Wed","Thu":"Thu","Fri":"Fri","Sat":"Sat","Sunday":"Pazar","Monday":"Pazartesi","Tuesday":"Salı","Wednesday":"Çarşamba","Thursday":"Perşembe","Friday":"Cuma","Saturday":"Cumartesi"},"Months":{"Jan":"Jan","Feb":"Şubat","Mar":"Mar","Apr":"Apr","May":"Mayıs","Jun":"Jun","Jul":"Temmuz","Aug":"Ağu","Sep":"Eylül","Oct":"Ekim","Nov":"Kasım","Dec":"Aralık","January":"Ocak","February":"Şubat","March":"Mart","April":"Nisan","June":"Haziran","July":"Temmuz","August":"Ağustos","September":"Eylül","October":"Ekim","November":"Kasım","December":"Aralık"},"Today":"Bugün"},"uk":{"Weekdays":{"Sun":"Сонце","Mon":"Навігація","Tue":"Твитнуть","Wed":"Про","Thu":"Чорти","Fri":"П'ятниця","Sat":"Сонце","Sunday":"Неділя","Monday":"Понеділок","Tuesday":"П'ятниця","Wednesday":"Середа","Thursday":"Четвер","Friday":"П'ятниця","Saturday":"Субота"},"Months":{"Jan":"Мар","Feb":"Мар","Mar":"Мар","Apr":"Мар","May":"Травень","Jun":"Мар","Jul":"Мар","Aug":"Мар","Sep":"Мар","Oct":"Мар","Nov":"Мар","Dec":"Мар","January":"Січень","February":"Лютий","March":"Березень","April":"Квітень","June":"Червень","July":"Липень","August":"Серпень","September":"Вересень","October":"Жовтень","November":"Листопад","December":"Грудень"},"Today":"Сьогодні"},"ur":{"Weekdays":{"Sun":"سورج","Mon":"مون","Tue":"ٹو","Wed":"وے","Thu":"چو","Fri":"فری","Sat":"شطرنج","Sunday":"اتوار","Monday":"منگل","Tuesday":"منگل","Wednesday":"بدھ","Thursday":"جمعرات","Friday":"جمعہ","Saturday":"سبت"},"Months":{"Jan":"یان","Feb":"فیب","Mar":"مار","Apr":"پرنٹ","May":"مئی","Jun":"جون","Jul":"یول","Aug":"آغ","Sep":"سیپ","Oct":"پرنٹ","Nov":"ن","Dec":"سوال","January":"جنوری","February":"فروری","March":"مارچ","April":"اپریل","June":"جون","July":"جولائی","August":"اگست","September":"ستمبر","October":"اکتوبر","November":"نومبر","December":"دسمبر"},"Today":"آج"},"zh":{"Weekdays":{"Sun":"太阳","Mon":"月号","Tue":"图","Wed":"结婚","Thu":"图","Fri":"弗里语Name","Sat":"座位","Sunday":"礼拜","Monday":"星期一","Tuesday":"星期二","Wednesday":"星期三","Thursday":"星期四","Friday":"星期五","Saturday":"星期六(上午)"},"Months":{"Jan":"扬","Feb":"二月","Mar":"马来","Apr":"农历四月","May":"5月","Jun":"军","Jul":"朱尔","Aug":"奥格","Sep":"九月","Oct":"十月(简体)","Nov":"页:1","Dec":"12月(中文)","January":"页:1","February":"2月(半天会议)","March":"3月(半天会议)","April":"4月(半天会议)","June":"6月份","July":"7月(半天会议)","August":"8月(半天)","September":"9月(半天会议)","October":"10月(半天会议)","November":"11月(半天会议)","December":"12月(半天)"},"Today":"现在"},"zt":{"Weekdays":{"Sun":"太阳","Mon":"月","Tue":"二等分","Wed":"有婚","Thu":"三月","Fri":"弗里","Sat":"有","Sunday":"星期天","Monday":"星期一","Tuesday":"星期二","Wednesday":"星期三","Thursday":"星期四","Friday":"星期五","Saturday":"星期六"},"Months":{"Jan":"1月","Feb":"二月","Mar":"三月","Apr":"四月","May":"五月","Jun":"三月","Jul":"二月","Aug":"8月","Sep":"九月","Oct":"十月","Nov":"11月","Dec":"二月","January":"1月","February":"二月","March":"三月","April":"4月","June":"6月","July":"7月","August":"8月","September":"9月","October":"10月","November":"11月","December":"12月"},"Today":"今天"}}`, Fa = '{"en":{"Error":"Error","AutoComplete":{"NoResults":"No Results"}},"ar":{"Error":"الرعب","AutoComplete":{"NoResults":"لا نتائج"}},"az":{"Error":"Qeyd","AutoComplete":{"NoResults":"Qeydlər"}},"bg":{"Error":"Грешка","AutoComplete":{"NoResults":"Няма резултати"}},"bn":{"Error":"ত্রুটি","AutoComplete":{"NoResults":"কোনো ফলাফল পাওয়া যায়নি"}},"ca":{"Error":"Error","AutoComplete":{"NoResults":"Sense resultats"}},"cs":{"Error":"Chyba","AutoComplete":{"NoResults":"Žádné výsledky"}},"da":{"Error":"Fejl","AutoComplete":{"NoResults":"Ingen resultater"}},"de":{"Error":"Fehler","AutoComplete":{"NoResults":"Keine Ergebnisse"}},"el":{"Error":"Σφάλμα","AutoComplete":{"NoResults":"Χωρίς αποτελέσματα"}},"eo":{"Error":"Eraro","AutoComplete":{"NoResults":"Neniuj rezultoj"}},"es":{"Error":"Error","AutoComplete":{"NoResults":"No hay resultados"}},"et":{"Error":"Viga","AutoComplete":{"NoResults":"Tulemused puuduvad"}},"eu":{"Error":"Errorea","AutoComplete":{"NoResults":"Emaitzarik ez"}},"fa":{"Error":"خطای","AutoComplete":{"NoResults":"نتایج"}},"fi":{"Error":"Virhe","AutoComplete":{"NoResults":"Ei tuloksia"}},"fr":{"Error":"Erreur","AutoComplete":{"NoResults":"Aucun résultat"}},"ga":{"Error":"Amharc","AutoComplete":{"NoResults":"Gan a bheith ráite"}},"gl":{"Error":"Erro","AutoComplete":{"NoResults":"Sen resultados"}},"he":{"Error":"טעות","AutoComplete":{"NoResults":"לא תוצאות"}},"hi":{"Error":"त्रुटि","AutoComplete":{"NoResults":"परिणाम"}},"hu":{"Error":"Hiba","AutoComplete":{"NoResults":"Nincs eredmény"}},"id":{"Error":"Galat","AutoComplete":{"NoResults":"Tidak ada hasil"}},"it":{"Error":"Errore","AutoComplete":{"NoResults":"Nessun risultato"}},"ja":{"Error":"エラー","AutoComplete":{"NoResults":"結果なし"}},"ko":{"Error":"계정","AutoComplete":{"NoResults":"결과 없음"}},"lt":{"Error":"Klaida","AutoComplete":{"NoResults":"Nr rezultatai"}},"lv":{"Error":"Kļūda","AutoComplete":{"NoResults":"Nav rezultātu"}},"ms":{"Error":"Error","AutoComplete":{"NoResults":"Hasil No"}},"nb":{"Error":"Feil","AutoComplete":{"NoResults":"Ingen resultater"}},"nl":{"Error":"Fout","AutoComplete":{"NoResults":"Geen resultaten"}},"pl":{"Error":"Błąd","AutoComplete":{"NoResults":"Brak wyników"}},"pt":{"Error":"Erro","AutoComplete":{"NoResults":"Sem resultados"}},"ro":{"Error":"Eroare","AutoComplete":{"NoResults":"Niciun rezultat"}},"ru":{"Error":"Ошибка","AutoComplete":{"NoResults":"Нет результатов"}},"sk":{"Error":"Chyba","AutoComplete":{"NoResults":"Žiadne výsledky"}},"sl":{"Error":"Napaka","AutoComplete":{"NoResults":"Brez rezultatov"}},"sq":{"Error":"Gabim","AutoComplete":{"NoResults":"Asnjë rezultat"}},"sv":{"Error":"Fel","AutoComplete":{"NoResults":"Inga resultat"}},"th":{"Error":"ผิดพลาด","AutoComplete":{"NoResults":"ไม่มีผลลัพธ์"}},"tl":{"Error":"Pagkakamali","AutoComplete":{"NoResults":"Walang Resulta"}},"tr":{"Error":"Hata","AutoComplete":{"NoResults":"Sonuçlar yok"}},"uk":{"Error":"Помилка","AutoComplete":{"NoResults":"Немає результатів"}},"ur":{"Error":"خامی","AutoComplete":{"NoResults":"کوئی نتیجہ"}},"zh":{"Error":"错误","AutoComplete":{"NoResults":"无结果"}},"zt":{"Error":"錯誤","AutoComplete":{"NoResults":"沒有結果"}}}', Ba = '{"en":{"Done":"Done"},"ar":{"Done":"تم"},"az":{"Done":" Don"},"bg":{"Done":"Готово"},"bn":{"Done":"সম্পন্ন"},"ca":{"Done":"Fet"},"cs":{"Done":"Hotovo"},"da":{"Done":"Færdig"},"de":{"Done":"Fertig"},"el":{"Done":"Έγινε"},"eo":{"Done":"Done"},"es":{"Done":"Hecho"},"et":{"Done":"Tehtud"},"eu":{"Done":"Eginda"},"fa":{"Done":"انجام"},"fi":{"Done":"Tehty"},"fr":{"Done":"Fait"},"ga":{"Done":"Arna"},"gl":{"Done":"Feito"},"he":{"Done":"נעשה"},"hi":{"Done":"दान"},"hu":{"Done":"Kész"},"id":{"Done":"Selesai"},"it":{"Done":"Fatto"},"ja":{"Done":"ログイン"},"ko":{"Done":"한국어"},"lt":{"Done":"@"},"lv":{"Done":"Pabeigts"},"ms":{"Done":"Selesai"},"nb":{"Done":"Ferdig"},"nl":{"Done":"Klaar"},"pl":{"Done":"Gotowe"},"pt":{"Done":"Feito"},"ro":{"Done":"Gata"},"ru":{"Done":"Сделано"},"sk":{"Done":"Hotovo"},"sl":{"Done":"Končano"},"sq":{"Done":"U"},"sv":{"Done":"Done"},"th":{"Done":"เสร็จแล้ว"},"tl":{"Done":"Tapos"},"tr":{"Done":"Done"},"uk":{"Done":"Сонце"},"ur":{"Done":"بند"},"zh":{"Done":"完成"},"zt":{"Done":"完成"}}', xa = {
  Button: JSON.parse(Oa),
  Filter: JSON.parse(Ja),
  Pagination: JSON.parse(Na),
  Date: JSON.parse(wa),
  Form: JSON.parse(Fa),
  Wizard: JSON.parse(Ba)
}, V = (e, l) => {
  let t = e.split("."), a = xa[t[0]];
  const n = (l == null || l == null ? null : l.value) ?? "en";
  if (a !== void 0) {
    a[n] === void 0 ? a = a.en : a = a[n];
    let s = 1;
    for (; a !== void 0 && s < t.length; )
      a = a[t[s]], s++;
  }
  if (a === void 0)
    throw `unable to locate message ${e}`;
  return a;
}, Ta = /* @__PURE__ */ D({
  __name: "button-add",
  props: {
    disabled: { type: Boolean },
    size: {},
    hide_mobile: { type: Boolean },
    hide_tablet: { type: Boolean },
    hide_desktop: { type: Boolean },
    is_rounded: { type: Boolean },
    is_outlined: { type: Boolean },
    is_loading: { type: [Object, Boolean] }
  },
  emits: ["click"],
  setup(e, { emit: l }) {
    const t = l, a = e, n = Q(R), s = f(() => Object.assign({}, a, {
      title: V("Button.Add", n),
      icon: "plus",
      type: Z.primary
    }));
    return (o, i) => (r(), B(te, Y(s.value, {
      onClick: i[0] || (i[0] = (d) => t("click"))
    }), null, 16));
  }
}), xt = /* @__PURE__ */ D({
  __name: "button-cancel",
  props: {
    disabled: { type: Boolean },
    size: {},
    hide_mobile: { type: Boolean },
    hide_tablet: { type: Boolean },
    hide_desktop: { type: Boolean },
    is_rounded: { type: Boolean },
    is_outlined: { type: Boolean },
    is_loading: { type: [Object, Boolean] }
  },
  emits: ["click"],
  setup(e, { emit: l }) {
    const t = l, a = e, n = Q(R), s = f(() => Object.assign({}, a, {
      title: V("Button.Cancel", n),
      icon: "window-close",
      type: Z.danger
    }));
    return (o, i) => (r(), B(te, Y(s.value, {
      onClick: i[0] || (i[0] = (d) => t("click"))
    }), null, 16));
  }
}), Pa = /* @__PURE__ */ D({
  __name: "button-delete",
  props: {
    disabled: { type: Boolean },
    size: {},
    hide_mobile: { type: Boolean },
    hide_tablet: { type: Boolean },
    hide_desktop: { type: Boolean },
    is_rounded: { type: Boolean },
    is_outlined: { type: Boolean },
    is_loading: { type: [Object, Boolean] }
  },
  emits: ["click"],
  setup(e, { emit: l }) {
    const t = l, a = e, n = Q(R), s = f(() => Object.assign({}, a, {
      title: V("Button.Delete", n),
      icon: "trash-alt",
      type: Z.danger
    }));
    return (o, i) => (r(), B(te, Y(s.value, {
      onClick: i[0] || (i[0] = (d) => t("click"))
    }), null, 16));
  }
}), Ca = /* @__PURE__ */ D({
  __name: "button-disable",
  props: {
    disabled: { type: Boolean },
    size: {},
    hide_mobile: { type: Boolean },
    hide_tablet: { type: Boolean },
    hide_desktop: { type: Boolean },
    is_rounded: { type: Boolean },
    is_outlined: { type: Boolean },
    is_loading: { type: [Object, Boolean] }
  },
  emits: ["click"],
  setup(e, { emit: l }) {
    const t = l, a = e, n = Q(R), s = f(() => Object.assign({}, a, {
      title: V("Button.Disable", n),
      icon: "times-circle",
      type: Z.danger
    }));
    return (o, i) => (r(), B(te, Y(s.value, {
      onClick: i[0] || (i[0] = (d) => t("click"))
    }), null, 16));
  }
}), Ea = /* @__PURE__ */ D({
  __name: "button-download",
  props: {
    disabled: { type: Boolean },
    size: {},
    hide_mobile: { type: Boolean },
    hide_tablet: { type: Boolean },
    hide_desktop: { type: Boolean },
    is_rounded: { type: Boolean },
    is_outlined: { type: Boolean },
    is_loading: { type: [Object, Boolean] }
  },
  emits: ["click"],
  setup(e, { emit: l }) {
    const t = l, a = e, n = Q(R), s = f(() => Object.assign({}, a, {
      title: V("Button.Download", n),
      icon: "download",
      type: Z.primary
    }));
    return (o, i) => (r(), B(te, Y(s.value, {
      onClick: i[0] || (i[0] = (d) => t("click"))
    }), null, 16));
  }
}), za = /* @__PURE__ */ D({
  __name: "button-edit",
  props: {
    disabled: { type: Boolean },
    size: {},
    hide_mobile: { type: Boolean },
    hide_tablet: { type: Boolean },
    hide_desktop: { type: Boolean },
    is_rounded: { type: Boolean },
    is_outlined: { type: Boolean },
    is_loading: { type: [Object, Boolean] }
  },
  emits: ["click"],
  setup(e, { emit: l }) {
    const t = l, a = e, n = Q(R), s = f(() => Object.assign({}, a, {
      title: V("Button.Edit", n),
      icon: "edit",
      type: Z.primary
    }));
    return (o, i) => (r(), B(te, Y(s.value, {
      onClick: i[0] || (i[0] = (d) => t("click"))
    }), null, 16));
  }
}), Ra = /* @__PURE__ */ D({
  __name: "button-enable",
  props: {
    disabled: { type: Boolean },
    size: {},
    hide_mobile: { type: Boolean },
    hide_tablet: { type: Boolean },
    hide_desktop: { type: Boolean },
    is_rounded: { type: Boolean },
    is_outlined: { type: Boolean },
    is_loading: { type: [Object, Boolean] }
  },
  emits: ["click"],
  setup(e, { emit: l }) {
    const t = l, a = e, n = Q(R), s = f(() => Object.assign({}, a, {
      title: V("Button.Enable", n),
      icon: "check",
      type: Z.primary
    }));
    return (o, i) => (r(), B(te, Y(s.value, {
      onClick: i[0] || (i[0] = (d) => t("click"))
    }), null, 16));
  }
}), Tt = /* @__PURE__ */ D({
  __name: "button-okay",
  props: {
    disabled: { type: Boolean },
    size: {},
    hide_mobile: { type: Boolean },
    hide_tablet: { type: Boolean },
    hide_desktop: { type: Boolean },
    is_rounded: { type: Boolean },
    is_outlined: { type: Boolean },
    is_loading: { type: [Object, Boolean] }
  },
  emits: ["click"],
  setup(e, { emit: l }) {
    const t = l, a = e, n = Q(R), s = f(() => Object.assign({}, a, {
      title: V("Button.Okay", n),
      icon: "check",
      type: Z.primary
    }));
    return (o, i) => (r(), B(te, Y(s.value, {
      onClick: i[0] || (i[0] = (d) => t("click"))
    }), null, 16));
  }
}), Ia = /* @__PURE__ */ D({
  __name: "button-print",
  props: {
    disabled: { type: Boolean },
    size: {},
    hide_mobile: { type: Boolean },
    hide_tablet: { type: Boolean },
    hide_desktop: { type: Boolean },
    is_rounded: { type: Boolean },
    is_outlined: { type: Boolean },
    is_loading: { type: [Object, Boolean] }
  },
  emits: ["click"],
  setup(e, { emit: l }) {
    const t = l, a = e, n = Q(R), s = f(() => Object.assign({}, a, {
      title: V("Button.Print", n),
      icon: "print",
      type: Z.primary
    }));
    return (o, i) => (r(), B(te, Y(s.value, {
      onClick: i[0] || (i[0] = (d) => t("click"))
    }), null, 16));
  }
}), Pt = /* @__PURE__ */ D({
  __name: "button-refresh",
  props: {
    disabled: { type: Boolean },
    size: {},
    hide_mobile: { type: Boolean },
    hide_tablet: { type: Boolean },
    hide_desktop: { type: Boolean },
    is_rounded: { type: Boolean },
    is_outlined: { type: Boolean },
    is_loading: { type: [Object, Boolean] }
  },
  emits: ["click"],
  setup(e, { emit: l }) {
    const t = l, a = e, n = Q(R), s = f(() => Object.assign({}, a, {
      title: V("Button.Refresh", n),
      icon: "sync",
      type: Z.primary
    }));
    return (o, i) => (r(), B(te, Y(s.value, {
      onClick: i[0] || (i[0] = (d) => t("click"))
    }), null, 16));
  }
}), Wa = /* @__PURE__ */ D({
  __name: "button-save",
  props: {
    disabled: { type: Boolean },
    size: {},
    hide_mobile: { type: Boolean },
    hide_tablet: { type: Boolean },
    hide_desktop: { type: Boolean },
    is_rounded: { type: Boolean },
    is_outlined: { type: Boolean },
    is_loading: { type: [Object, Boolean] }
  },
  emits: ["click"],
  setup(e, { emit: l }) {
    const t = l, a = e, n = Q(R), s = f(() => Object.assign({}, a, {
      title: V("Button.Save", n),
      icon: "save",
      type: Z.primary
    }));
    return (o, i) => (r(), B(te, Y(s.value, {
      onClick: i[0] || (i[0] = (d) => t("click"))
    }), null, 16));
  }
}), ja = /* @__PURE__ */ D({
  __name: "button-submit",
  props: {
    disabled: { type: Boolean },
    size: {},
    hide_mobile: { type: Boolean },
    hide_tablet: { type: Boolean },
    hide_desktop: { type: Boolean },
    is_rounded: { type: Boolean },
    is_outlined: { type: Boolean },
    is_loading: { type: [Object, Boolean] }
  },
  emits: ["click"],
  setup(e, { emit: l }) {
    const t = l, a = e, n = Q(R), s = f(() => Object.assign({}, a, {
      title: V("Button.Submit", n),
      icon: "envelope-open-text",
      type: Z.success
    }));
    return (o, i) => (r(), B(te, Y(s.value, {
      onClick: i[0] || (i[0] = (d) => t("click"))
    }), null, 16));
  }
}), Va = /* @__PURE__ */ D({
  __name: "button-upload",
  props: {
    disabled: { type: Boolean },
    size: {},
    hide_mobile: { type: Boolean },
    hide_tablet: { type: Boolean },
    hide_desktop: { type: Boolean },
    is_rounded: { type: Boolean },
    is_outlined: { type: Boolean },
    is_loading: { type: [Object, Boolean] }
  },
  emits: ["click"],
  setup(e, { emit: l }) {
    const t = l, a = e, n = Q(R), s = f(() => Object.assign({}, a, {
      title: V("Button.Upload", n),
      icon: "upload",
      type: Z.primary
    }));
    return (o, i) => (r(), B(te, Y(s.value, {
      onClick: i[0] || (i[0] = (d) => t("click"))
    }), null, 16));
  }
}), La = /* @__PURE__ */ D({
  __name: "buttons-container",
  props: {
    size: {},
    alignment: {}
  },
  setup(e) {
    const l = e;
    return (t, a) => (r(), c("div", {
      class: N(["buttons", l.size ? `are-${l.size}` : "", l.alignment ? `is-${l.alignment}` : ""])
    }, [
      T(t.$slots, "default")
    ], 2));
  }
}), Ua = /* @__PURE__ */ D({
  __name: "check-mark",
  props: {
    checked: { type: Boolean, default: !0 },
    size: { default: se.normal }
  },
  setup(e) {
    const l = e;
    return (t, a) => (r(), B(K, {
      icon: `square-${l.checked ? "check" : "xmark"}`,
      size: l.size
    }, null, 8, ["icon", "size"]));
  }
}), Ga = { class: "dropdown-trigger" }, Ha = ["aria-controls"], Ka = { class: "icon is-small" }, Ya = ["id"], qa = { class: "dropdown-content" }, Za = {
  key: 0,
  class: "dropdown-divider"
}, Qa = { key: 0 }, Xa = /* @__PURE__ */ D({
  __name: "dropdown",
  props: {
    title: {},
    items: {},
    is_hoverable: { type: Boolean },
    is_right_align: { type: Boolean },
    drops_up: { type: Boolean }
  },
  setup(e) {
    const l = bt(), t = e, a = C(!1), n = f(() => {
      let u = ["dropdown"];
      return t.is_hoverable && u.push("is-hoverable"), t.is_right_align && u.push("is-right"), t.drops_up && u.push("is-up"), a.value && u.push("is-active"), u;
    }), s = f(() => {
      let u = ie(t.items);
      return Array.isArray(u) && (u = u.map((m) => Array.isArray(m) ? { children: m } : { children: [m] })), Array.isArray(u) ? u : [u];
    }), o = (u) => {
      let m = ["dropdown-item"];
      return typeof u != "string" && u.active && m.push("is-active"), m;
    }, i = (u) => {
      if (typeof u != "string")
        return u.href;
    }, d = (u) => {
      if (typeof u != "string") {
        a.value = !1;
        let m = u;
        m.onClick && m.onClick();
      }
    };
    return (u, m) => (r(), c("div", {
      class: N(n.value)
    }, [
      A("div", Ga, [
        A("button", {
          class: "button",
          "aria-haspopup": "true",
          "aria-controls": p(l),
          onClick: m[0] || (m[0] = (b) => a.value = !a.value)
        }, [
          A("span", null, x(t.title), 1),
          A("span", Ka, [
            F(K, {
              icon: "angle-down",
              "aria-hidden": "true"
            })
          ])
        ], 8, Ha)
      ]),
      A("div", {
        class: "dropdown-menu",
        id: p(l),
        role: "menu"
      }, [
        (r(!0), c(z, null, j(s.value, (b, _) => (r(), c("div", qa, [
          _ > 0 ? (r(), c("hr", Za)) : O("", !0),
          (r(!0), c(z, null, j(b.children, (g) => (r(), B(he(typeof g == "string" ? "div" : "a"), {
            class: N(o(g)),
            href: i(g),
            onClick: (y) => d(g)
          }, {
            default: w(() => [
              typeof g == "string" ? (r(), c("p", Qa, x(g), 1)) : O("", !0),
              G(" " + x(typeof g == "string" ? null : g.title), 1)
            ]),
            _: 2
          }, 1032, ["class", "href", "onClick"]))), 256))
        ]))), 256))
      ], 8, Ya)
    ], 2));
  }
}), ut = async (e, l, t) => {
  let a = await import(e);
  const n = Object.keys(a);
  return l && n.sort(l), n.filter((s) => t === void 0 || t.value === null || t.value.test(s)).map((s) => a[s]);
}, el = /* @__PURE__ */ D({
  __name: "dynamic-slot",
  props: {
    props: {},
    url: {},
    filter: {},
    sortMethod: { type: Function }
  },
  setup(e) {
    const l = C(null), t = e, a = f(() => t.filter == null || t.filter == null ? null : new RegExp("^" + t.filter.replaceAll(".", "\\.").replaceAll("*", ".+") + "$"));
    return U(() => [t.url, t.filter], async () => {
      l.value = await ut(t.url, t.sortMethod, a);
    }), de(async () => {
      l.value = await ut(t.url, t.sortMethod, a);
    }), (n, s) => (r(!0), c(z, null, j(l.value, (o) => (r(), B(he(o), Y({ ref_for: !0 }, t.props), null, 16))), 256));
  }
}), tl = { class: "field" }, al = { class: "control has-icons-left" }, ll = ["placeholder"], nl = { class: "icon is-small is-left" }, Ct = /* @__PURE__ */ D({
  __name: "filter",
  props: {
    default_value: {},
    min_length: {}
  },
  emits: ["filter"],
  setup(e, { emit: l }) {
    const t = e, a = l, n = Q(R), s = f(() => V("Filter.Filter", n)), o = C(null);
    U([o], (d) => {
      d[0] === "" && t.default_value && (o.value = t.default_value, a("filter", o.value == "" ? null : o.value));
    });
    const i = (d) => {
      d.keyCode === 13 ? a("filter", o.value === "" ? null : o.value) : t.min_length !== void 0 && t.min_length !== null && (o.value === "" ? a("filter", null) : o.value !== null && o.value.length >= t.min_length && a("filter", o.value.trimEnd()));
    };
    return de(() => {
      t.default_value && (o.value = t.default_value);
    }), (d, u) => (r(), c("div", tl, [
      A("p", al, [
        le(A("input", {
          role: "searchbox",
          type: "text",
          class: "input is-expanded is-rounded",
          placeholder: s.value,
          "onUpdate:modelValue": u[0] || (u[0] = (m) => o.value = m),
          onKeyup: i
        }, null, 40, ll), [
          [mt, o.value]
        ]),
        A("span", nl, [
          F(K, {
            icon: "filter",
            size: p(se).small
          }, null, 8, ["size"])
        ])
      ])
    ]));
  }
}), ol = ["alt", "src"], sl = /* @__PURE__ */ D({
  __name: "image",
  props: {
    src: {},
    size: { default: Xe.normal },
    alt: { default: "" },
    is_loading: { type: [Object, Boolean], default: void 0 }
  },
  setup(e) {
    const l = e;
    return (t, a) => (r(), B(p(W), {
      tag: "figure",
      class: N(["image", l.size]),
      is_loading: l.is_loading
    }, {
      default: w(() => [
        A("img", {
          alt: l.alt,
          src: p(l.src)
        }, null, 8, ol)
      ]),
      _: 1
    }, 8, ["class", "is_loading"]));
  }
}), rl = {
  key: 0,
  class: "message-header"
}, il = { class: "message-body" }, ul = /* @__PURE__ */ D({
  __name: "message",
  props: {
    type: { default: Z.primary },
    message: { default: null },
    has_delete: { type: Boolean, default: !1 },
    title: { default: null },
    size: { default: H.normal }
  },
  emits: ["close"],
  setup(e, { emit: l }) {
    const t = e, a = l, n = f(() => t.size === H.normal ? null : `is-${t.size}`), s = f(() => `is-${t.type}`);
    return (o, i) => (r(), c("article", {
      class: N(["message", n.value, s.value])
    }, [
      t.title ? (r(), c("div", rl, [
        A("p", null, x(t.title), 1),
        t.has_delete ? (r(), c("button", {
          key: 0,
          class: "delete",
          "aria-label": "delete",
          onClick: i[0] || (i[0] = (d) => a("close"))
        })) : O("", !0)
      ])) : O("", !0),
      A("div", il, [
        T(o.$slots, "default", {}, () => [
          G(x(t.message), 1)
        ])
      ])
    ], 2));
  }
}), ge = /* @__PURE__ */ D({
  __name: "notification",
  props: {
    type: { default: ue.info },
    message: { default: null },
    light: { type: Boolean, default: !1 },
    is_loading: { type: [Object, Boolean], default: void 0 }
  },
  setup(e) {
    const l = e;
    return (t, a) => (r(), B(p(W), {
      tag: "div",
      is_loading: l.is_loading,
      class: N(["notification", "is-" + l.type, l.light ? "is-light" : ""])
    }, {
      default: w(() => [
        T(t.$slots, "default", {}, () => [
          G(x(l.message), 1)
        ])
      ]),
      _: 3
    }, 8, ["is_loading", "class"]));
  }
}), dl = {
  key: 0,
  class: "modal-background"
}, cl = ["aria-label"], pl = {
  key: 0,
  class: "title"
}, ml = { class: "block" }, gl = /* @__PURE__ */ D({
  __name: "page-notification",
  props: {
    visible: { type: Boolean, default: !1 },
    type: { default: ue.info },
    message: {},
    header: {},
    block_user: { type: Boolean },
    has_close: { type: Boolean },
    is_light: { type: Boolean }
  },
  emits: ["close"],
  setup(e, { emit: l }) {
    const t = e, a = l, n = f(() => {
      switch (t.type) {
        case ue.info:
          return "circle-info";
        case ue.success:
          return "circle-check";
        case ue.danger:
          return "bug";
        case ue.warning:
          return "circle-exclamation";
      }
    }), s = f(() => {
      var o = ["is-page-notification-container", `is-${t.type}`];
      return t.is_light && o.push("is-light-mode"), t.has_close === void 0 || t.has_close === null || t.has_close || o.push("has-no-close"), o;
    });
    return (o, i) => (r(), c("div", {
      class: N({ modal: t.block_user && t.visible, "is-active": t.block_user && t.visible })
    }, [
      t.block_user && t.visible ? (r(), c("div", dl)) : O("", !0),
      F(Bt, {
        incoming: p(we).fadeIn,
        outgoing: p(we).fadeOut,
        speed: p(ye).slower
      }, {
        default: w(() => [
          t.visible ? (r(), c("div", {
            key: 0,
            class: N(s.value),
            role: "dialog",
            "aria-label": t.header ?? "Page Notification"
          }, [
            F(K, {
              icon: n.value,
              size: p(se).xxlarge
            }, null, 8, ["icon", "size"]),
            t.header !== null && t.header !== void 0 ? (r(), c("h1", pl, x(t.header), 1)) : O("", !0),
            A("div", ml, x(t.message), 1),
            t.has_close ? (r(), B(K, {
              key: 1,
              icon: "circle-xmark",
              onClick: i[0] || (i[0] = (d) => a("close")),
              size: p(se).large,
              role: "button",
              "aria-label": "close"
            }, null, 8, ["size"])) : O("", !0)
          ], 10, cl)) : O("", !0)
        ]),
        _: 1
      }, 8, ["incoming", "outgoing", "speed"])
    ], 2));
  }
}), bl = ["title", "disabled"], hl = ["title", "disabled"], vl = {
  key: 0,
  class: "pagination-list"
}, yl = {
  key: 0,
  class: "pagination-ellipsis"
}, fl = ["aria-label", "onOnclick"], Et = /* @__PURE__ */ D({
  __name: "pagination",
  props: {
    use_next: { type: Boolean, default: !0 },
    has_more: { type: Boolean, default: void 0 },
    has_previous: { type: Boolean, default: void 0 },
    size: { default: H.small },
    rounded: { type: Boolean, default: !1 },
    button_type: {},
    total_pages: {},
    current_page: {},
    zero_page_index: { type: Boolean, default: !0 }
  },
  emits: ["moveForward", "moveBack", "goToPage"],
  setup(e, { emit: l }) {
    const t = e, a = l, n = Q(R), s = f(() => V(t.use_next ? "Pagination.Previous" : "Pagination.Older", n)), o = f(() => V(t.use_next ? "Pagination.Next" : "Pagination.Newer", n)), i = f(() => t.button_type ? `has-background-${t.button_type}` : ""), d = f(() => V("Pagination.GoToPage", n)), u = f(() => t.current_page === void 0 ? 0 : ie(t.current_page) + (t.zero_page_index ? 1 : 0)), m = f(() => (t.has_previous ?? !1) || u.value > 0), b = f(() => (t.has_more ?? !1) || u.value < (t.total_pages === void 0 ? 0 : ie(t.total_pages))), _ = f(() => {
      if (t.total_pages === void 0 || t.current_page === void 0)
        return [];
      if (ie(t.total_pages) > 5) {
        let v = Math.max(t.current_page === void 0 ? Math.floor(ie(t.total_pages) / 2) : u.value, 3);
        return ie(t.total_pages) - u.value === 0 ? v -= 2 : ie(t.total_pages) - u.value === 1 && v--, [
          1,
          -1,
          v - 1,
          v,
          v + 1,
          -1,
          ie(t.total_pages)
        ];
      } else {
        let v = [];
        for (let J = 1; J <= ie(t.total_pages); J++)
          v.push(J);
        return v;
      }
    }), g = function() {
      m && (t.current_page !== void 0 && t.current_page !== null ? a("goToPage", ie(t.current_page) - 1) : a("moveBack"));
    }, y = function() {
      b && (t.current_page !== void 0 && t.current_page !== null ? a("goToPage", ie(t.current_page) + 1) : a("moveForward"));
    }, h = function(v) {
      a("goToPage", t.zero_page_index ? v - 1 : v);
    };
    return (v, J) => le((r(), c("nav", {
      class: N(["pagination", "is-centered", i.value, `is-${t.size}`, t.rounded ? "is-rounded" : ""]),
      role: "navigation",
      "aria-label": "pagination"
    }, [
      A("a", {
        class: N(["pagination-previous", i.value]),
        title: s.value,
        onClick: g,
        disabled: m.value ? null : "disabled"
      }, [
        F(K, {
          icon: "backward",
          class: "mr-1",
          size: p(se).small
        }, null, 8, ["size"]),
        G(" " + x(s.value), 1)
      ], 10, bl),
      A("a", {
        class: N(["pagination-next", i.value]),
        title: o.value,
        onClick: y,
        disabled: b.value ? null : "disabled"
      }, [
        G(x(o.value) + " ", 1),
        F(K, {
          icon: "forward",
          class: "ml-1",
          size: p(se).small
        }, null, 8, ["size"])
      ], 10, hl),
      t.total_pages !== void 0 ? (r(), c("ul", vl, [
        (r(!0), c(z, null, j(_.value, (M) => (r(), c("li", null, [
          M === -1 ? (r(), c("span", yl, "…")) : (r(), c("a", {
            key: 1,
            class: N(["pagination-link", M === u.value ? "is-current" : ""]),
            "aria-label": `${d.value} ${M}`,
            onOnclick: (E) => h(M)
          }, x(M), 43, fl))
        ]))), 256))
      ])) : O("", !0)
    ], 2)), [
      [oe, m.value || b.value]
    ]);
  }
}), be = /* @__PURE__ */ D({
  __name: "Promised",
  props: {
    promise: {}
  },
  setup(e) {
    const l = e, t = C(null), a = Q(R), n = f(() => `${V("Form.Error", a)}: ${t.value.message ?? t.value.toString()}`), s = C(!1), o = C(!1), i = f(() => !s.value && !o.value), d = C(null);
    async function u(m) {
      if (s.value = !1, o.value = !1, t.value = null, m == null)
        d.value = null;
      else {
        let b = p(m);
        Object.prototype.toString.call(b) !== "[object Promise]" && (b = Promise.resolve(b));
        try {
          d.value = await b, o.value = !0;
        } catch (_) {
          t.value = _, s.value = !0;
        }
      }
    }
    return U(
      () => l.promise,
      () => {
        u(l.promise);
      }
    ), de(() => {
      u(l.promise);
    }), (m, b) => (r(), c(z, null, [
      i.value ? T(m.$slots, "pending", { key: 0 }, () => [
        F(p(ke), {
          size: p(H).small
        }, null, 8, ["size"])
      ]) : O("", !0),
      s.value ? T(m.$slots, "rejected", me(Y({ key: 1 }, t.value)), () => [
        F(p(ge), {
          message: n.value,
          type: p(ue).danger
        }, null, 8, ["message", "type"])
      ]) : O("", !0),
      o.value ? T(m.$slots, "default", {
        key: 2,
        response: d.value
      }) : O("", !0)
    ], 64));
  }
}), _l = ["value", "max"], ke = /* @__PURE__ */ D({
  __name: "progress",
  props: {
    type: { default: Z.primary },
    size: { default: H.normal },
    value: {},
    maximum: {}
  },
  setup(e) {
    const l = e, t = f(() => l.maximum === void 0 ? null : (l.value ?? 0) / l.maximum * 100);
    return (a, n) => (r(), c("progress", {
      class: N(`progress is-${l.size} is-${l.type}`),
      value: l.value,
      max: l.maximum
    }, x(t.value ? `${t.value.toFixed(2)}%` : null), 11, _l));
  }
}), kl = {
  key: 0,
  class: "navbar-link"
}, Sl = {
  key: 0,
  class: "icon-text"
}, Ml = { class: "icon" }, Dl = { key: 1 }, $l = {
  key: 0,
  class: "icon-text"
}, Al = { class: "icon" }, Ol = { key: 1 }, Jl = {
  key: 2,
  class: "navbar-dropdown"
}, dt = /* @__PURE__ */ D({
  __name: "navbar-item",
  props: {
    title: {},
    active: { type: Boolean, default: !1 },
    icon: {},
    href: {},
    onClick: {},
    childItems: {}
  },
  emits: ["itemClicked"],
  setup(e, { emit: l }) {
    const t = e, a = () => {
      n("itemClicked"), t.onClick !== void 0 && t.onClick();
    }, n = l;
    return (s, o) => {
      const i = gt("navbar-item", !0);
      return r(), B(he(t.childItems !== void 0 ? "div" : "a"), {
        class: N(["navbar-item", t.active ? "is-active" : "", t.childItems !== void 0 ? "has-dropdown is-hoverable" : ""]),
        href: t.href,
        onClick: a,
        tabIndex: t.href === void 0 || t.href === "" ? 0 : null
      }, {
        default: w(() => [
          t.childItems !== void 0 ? (r(), c("a", kl, [
            t.icon !== void 0 && t.icon !== null ? (r(), c("span", Sl, [
              A("span", Ml, [
                F(K, {
                  icon: t.icon
                }, null, 8, ["icon"])
              ]),
              A("span", null, x(t.title), 1)
            ])) : (r(), c("span", Dl, x(t.title), 1))
          ])) : (r(), c(z, { key: 1 }, [
            t.icon !== void 0 && t.icon !== null ? (r(), c("span", $l, [
              A("span", Al, [
                F(K, {
                  icon: t.icon
                }, null, 8, ["icon"])
              ]),
              A("span", null, x(t.title), 1)
            ])) : (r(), c("span", Ol, x(t.title), 1))
          ], 64)),
          t.childItems !== void 0 ? (r(), c("div", Jl, [
            (r(!0), c(z, null, j(t.childItems, (d) => (r(), B(i, Y({ ref_for: !0 }, d, {
              onItemClicked: o[0] || (o[0] = (u) => n("itemClicked"))
            }), null, 16))), 256))
          ])) : O("", !0)
        ]),
        _: 1
      }, 8, ["class", "href", "tabIndex"]);
    };
  }
}), Nl = ["aria-label"], wl = { class: "navbar-brand" }, Fl = ["aria-expanded"], Bl = {
  key: 0,
  class: "navbar-start"
}, xl = { style: { width: "100px" } }, Tl = {
  key: 1,
  class: "navbar-end"
}, Pl = { style: { width: "100px" } }, Cl = /* @__PURE__ */ D({
  __name: "navbar",
  props: {
    start_items: {},
    end_items: {},
    fixed_position: { default: null },
    ariaLabel: { default: "navigation" },
    color: {}
  },
  setup(e) {
    const l = e, t = C(!1);
    return de(() => {
      if (l.fixed_position) {
        let a = "";
        switch (l.fixed_position) {
          case Be.top:
            a = "has-navbar-fixed-top";
            break;
          case Be.bottom:
            a = "has-navbar-fixed-bottom";
            break;
        }
        a !== "" && (document.body.classList.contains(a) || document.body.classList.add(a));
      }
    }), (a, n) => (r(), c("nav", {
      class: N(["navbar", l.fixed_position, l.color !== void 0 && l.color !== null ? `is-${l.color}` : ""]),
      role: "navigation",
      "aria-label": l.ariaLabel
    }, [
      A("div", wl, [
        T(a.$slots, "brand"),
        A("a", {
          role: "button",
          class: N(["navbar-burger", t.value ? "is-active" : ""]),
          "aria-label": "menu",
          "aria-expanded": t.value ? "true" : "false",
          onClick: n[0] || (n[0] = (s) => t.value = !t.value)
        }, [...n[3] || (n[3] = [
          A("span", { "aria-hidden": "true" }, null, -1),
          A("span", { "aria-hidden": "true" }, null, -1),
          A("span", { "aria-hidden": "true" }, null, -1)
        ])], 10, Fl)
      ]),
      A("div", {
        class: N(["navbar-menu", t.value ? "is-active" : ""])
      }, [
        l.start_items !== void 0 ? (r(), c("div", Bl, [
          F(be, {
            promise: l.start_items
          }, {
            default: w(({ response: s }) => [
              (r(!0), c(z, null, j(s, (o) => (r(), B(dt, Y({ ref_for: !0 }, o, {
                onItemClicked: n[1] || (n[1] = (i) => t.value = !1)
              }), null, 16))), 256))
            ]),
            pending: w(() => [
              A("div", xl, [
                F(ke, {
                  size: p(H).small
                }, null, 8, ["size"])
              ])
            ]),
            _: 1
          }, 8, ["promise"])
        ])) : O("", !0),
        l.end_items !== void 0 ? (r(), c("div", Tl, [
          F(be, {
            promise: l.end_items
          }, {
            default: w(({ response: s }) => [
              (r(!0), c(z, null, j(s, (o) => (r(), B(dt, Y({ ref_for: !0 }, o, {
                onItemClicked: n[2] || (n[2] = (i) => t.value = !1)
              }), null, 16))), 256))
            ]),
            pending: w(() => [
              A("div", Pl, [
                F(ke, {
                  size: p(H).small
                }, null, 8, ["size"])
              ])
            ]),
            _: 1
          }, 8, ["promise"])
        ])) : O("", !0)
      ], 2)
    ], 10, Nl));
  }
}), El = /* @__PURE__ */ D({
  __name: "menu",
  props: {
    fixedPosition: {}
  },
  setup(e) {
    const l = e;
    return (t, a) => (r(), c("aside", {
      class: N(["menu", l.fixedPosition !== void 0 ? `is-fixed-menu is-fixed-menu-${l.fixedPosition}` : ""])
    }, [
      T(t.$slots, "default")
    ], 2));
  }
}), zl = { class: "menu-label" }, Rl = /* @__PURE__ */ D({
  __name: "menu-label",
  props: {
    message: { default: "" }
  },
  setup(e) {
    const l = e;
    return (t, a) => (r(), c("p", zl, [
      G(x(l.message) + " ", 1),
      T(t.$slots, "default")
    ]));
  }
}), Il = ["href"], Wl = {
  key: 0,
  class: "icon-text"
}, jl = { class: "icon" }, Vl = { key: 1 }, zt = /* @__PURE__ */ D({
  __name: "menu-entry",
  props: {
    title: {},
    active: { type: Boolean },
    icon: {},
    href: {},
    onClick: { type: Function }
  },
  setup(e) {
    const l = e, t = () => {
      l.onClick !== void 0 && l.onClick();
    };
    return (a, n) => (r(), c("li", null, [
      A("a", {
        href: l.href,
        onClick: n[0] || (n[0] = (s) => t()),
        class: N(l.active ? "is-active" : "")
      }, [
        l.icon !== void 0 && l.icon !== null ? (r(), c("span", Wl, [
          A("span", jl, [
            F(K, {
              icon: l.icon
            }, null, 8, ["icon"])
          ]),
          A("span", null, x(l.title), 1)
        ])) : (r(), c("span", Vl, x(l.title), 1)),
        T(a.$slots, "default")
      ], 10, Il),
      T(a.$slots, "children")
    ]));
  }
}), Ll = { class: "menu-list" }, Ul = /* @__PURE__ */ D({
  __name: "menu-list",
  props: {
    items: {}
  },
  setup(e) {
    const l = e;
    return (t, a) => {
      const n = gt("menu-list", !0);
      return r(), c("ul", Ll, [
        l.items !== null ? (r(), B(be, {
          key: 0,
          promise: l.items
        }, {
          default: w(({ response: s }) => [
            (r(!0), c(z, null, j(s, (o) => (r(), c("li", null, [
              F(zt, Y({ ref_for: !0 }, o), null, 16),
              o.childItems !== void 0 ? (r(), B(n, {
                key: 0,
                items: o.childItems
              }, null, 8, ["items"])) : O("", !0)
            ]))), 256))
          ]),
          pending: w(() => [
            A("li", null, [
              F(ke, {
                size: p(H).small
              }, null, 8, ["size"])
            ])
          ]),
          _: 1
        }, 8, ["promise"])) : O("", !0),
        T(t.$slots, "default")
      ]);
    };
  }
}), Gl = /* @__PURE__ */ D({
  __name: "badge",
  props: {
    position: { default: qe.topRight },
    text: {},
    type: {}
  },
  setup(e) {
    const l = e;
    return (t, a) => (r(), c("span", {
      class: N(["badge", `is-${l.position}`, l.type === void 0 ? "" : `is-${l.type}`])
    }, [
      G(x(l.text) + " ", 1),
      T(t.$slots, "default")
    ], 2));
  }
}), Rt = /* @__PURE__ */ D({
  __name: "tooltip",
  props: {
    text: {},
    is: {},
    has_arrow: { type: Boolean, default: !1 },
    position: { default: Ce.left },
    multiline: { type: Boolean, default: !1 },
    type: {},
    always_active: { type: Boolean, default: !1 },
    text_align: { default: Ze.left }
  },
  setup(e) {
    const l = e;
    return (t, a) => (r(), B(he(l.is), {
      class: N([
        l.has_arrow ? "has-tooltop-arrow" : "",
        l.position ? `has-tooltip-${l.position}` : "",
        l.multiline ? "has-tooltip-multiline" : "",
        l.type ? `has-tooltip-${l.type}` : "",
        l.text_align ? `has-tooltip-text-${l.text_align}` : "",
        l.always_active ? "has-tooltip-active" : ""
      ]),
      "data-tooltip": e.text
    }, {
      default: w(() => [
        T(t.$slots, "default")
      ]),
      _: 3
    }, 8, ["class", "data-tooltip"]));
  }
}), Hl = /* @__PURE__ */ D({
  __name: "tag",
  props: {
    type: { default: Z.primary },
    light: { type: Boolean, default: !1 },
    rounded: { type: Boolean, default: !1 },
    size: { default: H.normal },
    is_delete: { type: Boolean, default: !1 },
    text: {},
    is_loading: { type: [Object, Boolean], default: void 0 }
  },
  setup(e) {
    const l = e, t = f(() => {
      let a = ["tag", `is-${l.type}`, `is-${l.size}`];
      return l.light && a.push("is-light"), l.rounded && a.push("is-rounded"), l.is_delete && a.push("is-delete"), a;
    });
    return (a, n) => (r(), B(p(W), {
      tag: "span",
      is_loading: l.is_loading,
      class: N(t.value)
    }, {
      default: w(() => [
        T(a.$slots, "default", {}, () => [
          G(x(l.text), 1)
        ])
      ]),
      _: 3
    }, 8, ["is_loading", "class"]));
  }
}), Kl = /* @__PURE__ */ D({
  __name: "tags",
  props: {
    size: {},
    addons: { type: Boolean }
  },
  setup(e) {
    const l = e;
    return (t, a) => (r(), c("span", {
      class: N(["tags", l.size === null ? "" : "are-" + l.size, l.addons ? "has-addons" : ""])
    }, [
      T(t.$slots, "default")
    ], 2));
  }
}), Yl = /* @__PURE__ */ D({
  __name: "title",
  props: {
    level: { default: 1 },
    text: { default: "" },
    is_loading: { type: [Object, Boolean], default: void 0 }
  },
  setup(e) {
    const l = e;
    if (l.level < 1 || l.level > 6)
      throw "level must be between 1 and 6";
    var t = f(() => `h${l.level < 1 || l.level > 6 ? 1 : l.level.toFixed(0)}`);
    return (a, n) => (r(), B(p(W), {
      tag: p(t),
      is_loading: l.is_loading,
      class: N(["title", `is-${l.level}`])
    }, {
      default: w(() => [
        T(a.$slots, "default", {}, () => [
          G(x(l.text), 1)
        ])
      ]),
      _: 3
    }, 8, ["tag", "is_loading", "class"]));
  }
}), ql = /* @__PURE__ */ D({
  __name: "subtitle",
  props: {
    level: { default: 1 },
    text: { default: "" },
    is_loading: { type: [Object, Boolean], default: void 0 }
  },
  setup(e) {
    const l = e;
    if (l.level < 1 || l.level > 6)
      throw "level must be between 1 and 6";
    var t = f(() => `h${l.level < 1 || l.level > 6 ? 1 : l.level.toFixed(0)}`);
    return (a, n) => (r(), B(p(W), {
      tag: p(t),
      is_loading: l.is_loading,
      class: N(["subtitle", `is-${l.level}`])
    }, {
      default: w(() => [
        T(a.$slots, "default", {}, () => [
          G(x(l.text), 1)
        ])
      ]),
      _: 3
    }, 8, ["tag", "is_loading", "class"]));
  }
}), Zl = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  Animation: Bt,
  Badge: Gl,
  Button: te,
  ButtonAdd: Ta,
  ButtonCancel: xt,
  ButtonDelete: Pa,
  ButtonDisable: Ca,
  ButtonDownload: Ea,
  ButtonEdit: za,
  ButtonEnable: Ra,
  ButtonOkay: Tt,
  ButtonPrint: Ia,
  ButtonRefresh: Pt,
  ButtonSave: Wa,
  ButtonSubmit: ja,
  ButtonUpload: Va,
  ButtonsContainer: La,
  CheckMark: Ua,
  DropDown: Xa,
  DynamicSlot: el,
  Filter: Ct,
  Icon: K,
  Image: sl,
  Menu: El,
  MenuEntry: zt,
  MenuLabel: Rl,
  MenuList: Ul,
  Message: ul,
  NavBar: Cl,
  Notification: ge,
  PageNotification: gl,
  Pagination: Et,
  Progress: ke,
  Promised: be,
  Subtitle: ql,
  Tag: Hl,
  Tags: Kl,
  Title: Yl,
  ToolTip: Rt
}, Symbol.toStringTag, { value: "Module" })), Ql = /* @__PURE__ */ D({
  __name: "draggable-item",
  props: {
    copy_data: { default: null },
    disabled: { type: Boolean, default: !1 },
    tag: { default: "div" },
    handle_search: {}
  },
  emits: ["started", "stopped"],
  setup(e, { emit: l }) {
    const t = l, a = e, n = C(!1), s = C(!1), o = C(null), i = f(() => (a.disabled ?? !1) || s.value && a.handle_search !== null), d = f(() => {
      let b = [];
      return i || b.push("has-cursor"), n.value ? b.push("is-move") : b.push("is-grab"), b;
    }), u = (b) => i.value ? (b.preventDefault(), !1) : (b.stopPropagation(), b.dataTransfer.setData("value", JSON.stringify(a.copy_data)), n.value = !0, t("started"), !0), m = () => {
      n.value = !1, s.value = !0, t("stopped");
    };
    return de(() => {
      if (a.handle_search) {
        let b = o.value.querySelector(a.handle_search);
        b !== null && (s.value = !0, b.addEventListener("mousedown", () => s.value = !1), b.addEventListener("mouseup", () => s.value = !0));
      }
    }), (b, _) => (r(), B(he(a.tag), {
      ref_key: "handle",
      ref: o,
      draggable: !0,
      onDragstart: u,
      onDragend: m,
      class: N(d.value)
    }, {
      default: w(() => [
        T(b.$slots, "default")
      ]),
      _: 3
    }, 40, ["class"]));
  }
}), Xl = /* @__PURE__ */ D({
  __name: "dropzone",
  props: {
    is_valid_child: { type: Function, default: (e) => !0 },
    tag: { default: "div" }
  },
  emits: ["itemAdded", "itemEntered", "itemExited", "itemMoved"],
  setup(e, { emit: l }) {
    const t = e, a = l, n = C(!1), s = C(null), o = C(null);
    f(() => t.tag ?? "div");
    const i = (_) => {
      const g = o.value.getBoundingClientRect(), y = {
        x: g.x + g.width / 2,
        y: g.y + g.height / 2
      };
      let h = ne.center;
      return _.x < y.x ? _.y < y.y ? h = ne.topLeft : h = ne.bottomLeft : _.y < y.y ? h = ne.topRight : h = ne.bottomRight, s.value = h, s.value;
    }, d = (_) => {
      _.preventDefault(), n.value = !0, a("itemEntered", i(_));
    }, u = (_) => {
      n.value = !0, a("itemExited", i(_));
    }, m = (_) => {
      _.preventDefault(), a("itemMoved", i(_));
    }, b = (_) => {
      if (t.is_valid_child && !t.is_valid_child(JSON.parse(_.dataTransfer.getData("value"))))
        return !1;
      _.stopPropagation(), _.preventDefault(), a("itemAdded", JSON.parse(_.dataTransfer.getData("value")), s.value), n.value = !1;
    };
    return (_, g) => (r(), B(he(t.tag), {
      ref_key: "handle",
      ref: o,
      class: N({ "is-bordered": n.value }),
      onDragenter: d,
      onDragleave: u,
      onDrop: b,
      onDragover: m
    }, {
      default: w(() => [
        T(_.$slots, "default")
      ]),
      _: 3
    }, 40, ["class"]));
  }
}), en = ["onClick"], tn = {
  key: 0,
  class: "icon"
}, It = /* @__PURE__ */ D({
  __name: "list",
  props: {
    numbered: { type: Boolean },
    items: {},
    type: {},
    compact: { type: Boolean },
    outlined: { type: Boolean },
    highlighted: { type: Boolean }
  },
  setup(e) {
    const l = e, t = ce(), a = f(() => {
      var o = ["block-list", "has-radius", `is-${l.type ?? "primary"}`];
      return l.compact && o.push("is-small"), l.outlined && o.push("is-outlined"), l.highlighted && o.push("is-highlighted"), o;
    }), n = f(() => l.items ? l.items.map((o, i) => ({
      name: o.name ?? `item-${i}`,
      classes: [
        o.type ? `is-${o.type}` : "",
        o.outlined ? "is-outlined" : "",
        o.highlighted ? "is-highlighted" : "",
        o.icon ? "has-icon" : "",
        o.onClick ? "is-clickable" : ""
      ],
      onClick: o.onClick,
      icon: o.icon
    })) : null), s = (o) => {
      o.onClick && o.onClick();
    };
    return (o, i) => (r(), B(he(e.numbered == null || e.numbered == null || !e.numbered ? "ul" : "ol"), {
      class: N(a.value)
    }, {
      default: w(() => [
        n.value === null ? T(o.$slots, "default", { key: 0 }) : (r(!0), c(z, { key: 1 }, j(n.value, (d) => (r(), c(z, null, [
          p(t)[d.name] !== void 0 || p(t)[d.name] !== null || d.icon !== void 0 ? (r(), c("li", {
            key: 0,
            class: N(d.classes),
            onClick: (u) => s(d)
          }, [
            d.icon ? (r(), c("span", tn, [
              F(K, {
                icon: d.icon
              }, null, 8, ["icon"])
            ])) : O("", !0),
            T(o.$slots, d.name)
          ], 10, en)) : O("", !0)
        ], 64))), 256))
      ]),
      _: 3
    }, 8, ["class"]));
  }
}), an = ["onDragstart", "onDragover"], ln = /* @__PURE__ */ D({
  __name: "sortable",
  props: {
    items: {},
    type: { default: Z.primary },
    compact: { type: Boolean, default: !1 },
    outlined: { type: Boolean, default: !1 },
    highlighted: { type: Boolean, default: !1 }
  },
  emits: ["sorted"],
  setup(e, { emit: l }) {
    const t = e, a = l, n = C([]), s = C(-1), o = C(-1), i = C(null);
    U(t.items, (_, g) => {
      n.value = [...g];
    }), de(() => {
      t.items !== null && (n.value = [...t.items]);
    });
    const d = (_) => {
      var g = _.target.getBoundingClientRect(), y = {
        x: g.x + g.width / 2,
        y: g.y + g.height / 2
      };
      let h = ne.center;
      return _.y < y.y ? h = ne.top : h = ne.bottom, h;
    }, u = (_, g) => {
      g.stopPropagation(), s.value = _, g.dataTransfer.setData("value", null);
    }, m = (_, g) => {
      s.value && (g.stopPropagation(), _ != s.value ? (o.value = _, i.value = d(g)) : (o.value = -1, i.value = null));
    }, b = (_) => {
      if (s.value) {
        _.stopPropagation();
        var g = o.value + (i.value == ne.top ? 0 : 1), y = n.value.splice(g, 1)[0];
        g >= s.value && g--, n.value.splice(g, 0, y), o.value = -1, i.value = null, s.value = -1, a("sorted", n.value);
      }
    };
    return (_, g) => (r(), B(It, {
      type: e.type,
      compact: e.compact,
      outlined: e.outlined,
      highlighted: e.highlighted,
      onDrop: b
    }, {
      default: w(() => [
        (r(!0), c(z, null, j(n.value, (y, h) => (r(), c(z, null, [
          le(A("li", null, [
            F(ge, { light: !0 }, {
              default: w(() => [...g[1] || (g[1] = [
                G(" ", -1)
              ])]),
              _: 1
            })
          ], 512), [
            [oe, o.value === h && s.value !== h && i.value === p(ne).top]
          ]),
          A("li", {
            draggable: "true",
            onDragstart: (v) => u(h, v),
            onDragend: g[0] || (g[0] = (v) => s.value = null),
            onDragover: (v) => m(h, v),
            class: N({ "has-cursor": !0, "is-move": o.value == h, "is-grab": o.value != h })
          }, [
            T(_.$slots, "item", {
              item: y,
              index: h
            })
          ], 42, an),
          le(A("li", null, [
            F(ge, { light: !0 }, {
              default: w(() => [...g[2] || (g[2] = [
                G(" ", -1)
              ])]),
              _: 1
            })
          ], 512), [
            [oe, o.value === h && s.value !== h && i.value === p(ne).bottom]
          ])
        ], 64))), 256))
      ]),
      _: 3
    }, 8, ["type", "compact", "outlined", "highlighted"]));
  }
}), nn = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  DraggableItem: Ql,
  DropZone: Xl,
  Sortable: ln
}, Symbol.toStringTag, { value: "Module" })), Ee = "HiddenFields", et = "DisabledFields", on = (e) => e, pe = (e, l) => {
  const t = l("Translate", on);
  return f(() => e.translate ?? t);
};
function tt(e, l) {
  const t = l(Ee, fe(C([]))), a = l(et, fe(C([]))), n = f(() => t.value.filter((o) => o.indexOf(`${e}.`) === 0).map((o) => o.split(".")[1])), s = f(() => a.value.filter((o) => o.indexOf(`${e}.`) === 0).map((o) => o.split(".")[1]));
  return { hiddenValues: n, disabledValues: s };
}
async function at(e) {
  let l = null, t = e;
  e instanceof Function && (t = e()), t instanceof Promise ? l = t : l = Promise.resolve(t);
  let a = await l, n = [];
  return a.value !== void 0 ? n = a.value : n = a, n;
}
const sn = { class: "tags has-addons" }, rn = { class: "tag is-link" }, un = ["onClick"], dn = { key: 0 }, cn = ["placeholder"], pn = { class: "dropdown-menu" }, mn = { class: "dropdown-content" }, gn = ["onClick"], bn = {
  key: 1,
  class: "dropdown-item"
}, Wt = /* @__PURE__ */ D({
  __name: "autocomplete",
  props: {
    title: {},
    limit: {},
    callbackurl: {},
    values: {},
    fetch: { type: Function },
    name: {},
    disabled: { type: Boolean },
    translate: { type: Function },
    is_loading: { type: [Object, Boolean] }
  },
  emits: ["valueChanged"],
  setup(e, { expose: l, emit: t }) {
    const a = Q(R), n = f(() => V("Form.AutoComplete.NoResults", a)), s = t, o = e, i = pe(o, R), d = C([]), u = C(null), m = C(null), b = C(null), _ = C(null);
    U(u, async (k) => {
      if (k != null) {
        if (k.length >= 2)
          if (o.values != null && o.values != null) {
            let q = [];
            for (let S = 0; S < o.values.length && ((o.values[S].name.toUpperCase().indexOf(k.toUpperCase()) >= 0 || o.values[S].id.toUpperCase().indexOf(k.toUpperCase()) >= 0) && q.push(o.values[S]), q.length != 10); S++)
              ;
            m.value = q;
          } else {
            let S = await (await (o.fetch ?? fetch)(`${o.callbackurl}?q=${encodeURIComponent(k)}`)).json();
            S.length > 10 && S.splice(10, S.length - 10), m.value = S;
          }
      } else
        m.value = null, _.value.innerHTML = "";
    });
    const g = () => {
      if (d.value.length == 0)
        return null;
      const k = d.value.slice();
      return o.limit != null && o.limit == 1 ? k.length > 0 ? k[0] : null : k;
    }, y = async (k) => {
      if (k == null)
        d.value.length > 0 && d.value.splice(0, d.value.length), u.value = null;
      else {
        const q = await Promise.all(
          (Array.isArray(k) ? k : [k]).map(async (S) => {
            if (S.id !== void 0 && S.name !== void 0)
              return S;
            if (o.values != null && o.values != null)
              return S.id !== void 0 ? o.values.find((P) => P.id === S.id) : o.values.find((P) => P.name.toUpperCase() === S.toUpperCase() || P.id.toUpperCase() === S);
            {
              let L = await (await (o.fetch ?? fetch)(`${o.callbackurl}?${S.id === void 0 ? "q=" + encodeURIComponent(S) : "id=" + encodeURIComponent(S.id)}`)).json();
              return L.length > 0 ? (o.disabled && (L[0].readonly = !0), L[0]) : null;
            }
          })
        );
        d.value = q.filter((S) => S !== null), o.limit !== void 0 && o.limit !== null && d.value.length > o.limit && d.value.splice(o.limit), s("valueChanged", { name: o.name, value: g() });
      }
    }, h = (k) => {
      k.preventDefault(), u.value = k.clipboardData.getData("text/plain");
    }, v = (k) => {
      switch (k.key) {
        case "Backspace":
          u.value != null && u.value.length > 0 && (u.value = u.value.substring(0, u.value.length - 1));
          break;
        case "Enter":
        case "Shift":
          break;
        default:
          k.key.length == 1 && (u.value = (u.value == null ? "" : u.value) + k.key);
          break;
      }
    }, J = () => {
      u.value = null;
    }, M = () => {
      _.value.focus();
    }, E = (k) => {
      d.value.push(k), J(), s("valueChanged", { name: o.name, value: g() });
    }, X = (k) => {
      d.value.splice(k, 1), M(), s("valueChanged", { name: o.name, value: g() });
    };
    return l({
      /**
       * Gets the current value 
       */
      getValue: g,
      /**
       * Sets the current value
       * 
       * @param value AutoCompleteItem|AutoCompleteItem[]|string[]|null
       * @returns Promise<void>
       */
      setValue: y
    }), (k, q) => (r(), c("div", {
      class: "control autocomplete",
      onBlur: J,
      onClick: M
    }, [
      F(p(W), {
        tag: "div",
        is_loading: o.is_loading,
        class: N(["tagsfield", "field", "input", "is-grouped", "is-grouped-multiline", o.disabled ? "is-disabled" : ""])
      }, {
        default: w(() => [
          (r(!0), c(z, null, j(d.value, (S, P) => (r(), c("div", {
            class: "control",
            key: P
          }, [
            A("div", sn, [
              A("a", rn, x(p(i)(S.name)), 1),
              !S.readonly && !o.disabled ? (r(), c("a", {
                key: 0,
                class: "tag is-delete",
                onClick: (L) => X(P)
              }, null, 8, un)) : O("", !0)
            ])
          ]))), 128)),
          o.disabled ? O("", !0) : (r(), c("div", dn, [
            le(A("span", {
              ref_key: "contentSpan",
              ref: _,
              placeholder: p(i)(o.title ?? ""),
              contenteditable: "",
              class: N(b.value),
              onFocus: q[0] || (q[0] = (S) => {
                b.value = "is-focused";
              }),
              onBlur: q[1] || (q[1] = (S) => {
                b.value = null;
              }),
              onKeydown: v,
              onPaste: h
            }, null, 42, cn), [
              [oe, o.limit === void 0 || o.limit === null || d.value.length < o.limit]
            ])
          ]))
        ]),
        _: 1
      }, 8, ["is_loading", "class"]),
      o.disabled ? O("", !0) : (r(), c("div", {
        key: 0,
        class: N(["dropdown", { "is-active": m.value != null && u.value != null && u.value != "" }])
      }, [
        A("div", pn, [
          A("div", mn, [
            m.value != null && m.value.length > 0 ? (r(!0), c(z, { key: 0 }, j(m.value, (S) => (r(), c("a", {
              class: "dropdown-item",
              onClick: (P) => E(S)
            }, x(p(i)(S.name)), 9, gn))), 256)) : (r(), c("a", bn, x(n.value), 1))
          ])
        ])
      ], 2))
    ], 32));
  }
}), je = /* @__PURE__ */ D({
  __name: "button",
  props: {
    label: {},
    sstyle: {},
    icon: {},
    name: {},
    disabled: { type: Boolean },
    translate: { type: Function },
    is_loading: { type: [Object, Boolean] }
  },
  emits: ["buttonClicked"],
  setup(e, { emit: l }) {
    const t = e, a = l, n = pe(t, R);
    return (s, o) => (r(), B(te, {
      is_loading: t.is_loading,
      type: t.sstyle,
      icon: t.icon,
      title: p(n)(t.label ?? ""),
      onClick: o[0] || (o[0] = (i) => a("buttonClicked", t.name)),
      disabled: t.disabled
    }, null, 8, ["is_loading", "type", "icon", "title", "disabled"]));
  }
}), jt = /* @__PURE__ */ D({
  __name: "checkbox-group",
  props: {
    values: { type: [Array, Promise, Function, null] },
    inputId: {},
    is_loading: { type: [Object, Boolean] },
    name: {},
    disabled: { type: Boolean },
    translate: { type: Function }
  },
  emits: ["valueChanged"],
  setup(e, { expose: l, emit: t }) {
    const a = e, n = Q(R), s = f(() => V("Form.Error", n)), o = t, i = pe(a, R), d = C([]), u = C(!1), m = f(async () => {
      if (a.values === null)
        return [];
      {
        let h = await at(a.values), v = h.filter((J) => J.selected).map((J) => J.value);
        return d.value === null || d.value.length == 0 ? d.value = v.length > 0 ? [...v] : [] : (v = d.value, h = h.map((J) => ({
          label: J.label,
          value: J.value,
          selected: v.some((M) => M === J.value)
        }))), h;
      }
    });
    U(d, (h) => {
      o("valueChanged", { name: a.name, value: b() });
    });
    const b = () => d.value.length == 0 ? null : d.value, _ = (h) => {
      u.value = !0, d.value.splice(0), h !== null && (d.value = [...h]), u.value = !1, o("valueChanged", { name: a.name, value: b() });
    }, { hiddenValues: g, disabledValues: y } = tt(a.name, R);
    return l({
      /**
       * Gets the current value 
       */
      getValue: b,
      /**
       * Sets the current value
       * 
       * @param value any[]|null
       * @returns void
       */
      setValue: _
    }), (h, v) => (r(), c("div", null, [
      F(be, { promise: m.value }, {
        default: w(({ response: J }) => [
          J !== null ? (r(!0), c(z, { key: 0 }, j(J, (M, E) => le((r(), B(p(W), {
            tag: "label",
            is_loading: a.is_loading,
            class: "checkbox is-block",
            for: `${a.inputId}-${E}`
          }, {
            default: w(() => [
              F(p(W), {
                tag: "input",
                is_loading: a.is_loading,
                type: "checkbox",
                class: "checkbox",
                value: M.value,
                modelValue: d.value,
                "onUpdate:modelValue": v[0] || (v[0] = (X) => d.value = X),
                disabled: a.disabled || p(y).some((X) => X === M.value.toString()),
                id: `${a.inputId}-${E}`
              }, null, 8, ["is_loading", "value", "modelValue", "disabled", "id"]),
              G(" " + x(p(i)(M.label)), 1)
            ]),
            _: 2
          }, 1032, ["is_loading", "for"])), [
            [oe, !p(g).some((X) => X === M.value.toString())]
          ])), 256)) : O("", !0)
        ]),
        rejected: w(() => [
          F(p(ge), {
            type: p(ue).danger,
            message: s.value
          }, null, 8, ["type", "message"])
        ]),
        _: 1
      }, 8, ["promise"])
    ]));
  }
}), hn = {
  key: 0,
  class: "help is-danger"
}, Vt = /* @__PURE__ */ D({
  __name: "checkbox",
  props: {
    label: {},
    required: { type: Boolean, default: !1 },
    inputId: {},
    is_loading: { type: [Object, Boolean] },
    name: {},
    disabled: { type: Boolean, default: !1 },
    translate: {}
  },
  emits: ["valueChanged"],
  setup(e, { expose: l, emit: t }) {
    const a = e, n = t, s = pe(a, R), o = f(() => s.value(a.label)), i = C(!1);
    return U(i, (m) => n("valueChanged", { name: a.name, value: m })), l({
      /**
       * Gets the current value 
       */
      getValue: () => i.value,
      /**
       * Sets the current value
       * 
       * @param value boolean
       * @returns void
       */
      setValue: (m) => {
        i.value = m;
      }
    }), (m, b) => (r(), B(p(W), {
      tag: "label",
      is_loading: a.is_loading,
      class: "checkbox",
      for: a.inputId
    }, {
      default: w(() => [
        F(p(W), {
          tag: "input",
          is_loading: a.is_loading,
          type: "checkbox",
          class: "checkbox",
          name: a.name,
          disabled: a.disabled,
          modelValue: i.value,
          "onUpdate:modelValue": b[0] || (b[0] = (_) => i.value = _),
          id: a.inputId
        }, null, 8, ["is_loading", "name", "disabled", "modelValue", "id"]),
        G(" " + x(o.value) + " ", 1),
        a.required ? (r(), c("span", hn, "*")) : O("", !0)
      ]),
      _: 1
    }, 8, ["is_loading", "for"]));
  }
}), We = (e, l) => {
  let t = new Date(e);
  return t.setDate(e.getDate() + l), t;
}, ee = (e, l, t) => {
  let a = e;
  for (; a.length < t; )
    a = l + a;
  return a;
}, Oe = (e, l, t) => {
  let a = "";
  switch (e) {
    case "d":
    case "dd":
      a += `${ee(t.getDate().toString(), "0", e.length)}`;
      break;
    case "ddd":
    case "dddd":
      let s = "";
      switch (t.getDay()) {
        case 0:
          s = "Sunday";
          break;
        case 1:
          s = "Monday";
          break;
        case 2:
          s = "Tuesday";
          break;
        case 3:
          s = "Wednesday";
          break;
        case 4:
          s = "Thursday";
          break;
        case 5:
          s = "Friday";
          break;
        case 6:
          s = "Saturday";
          break;
      }
      a += `${V("Date.Weekdays." + (e.length > 3 ? s : s.substring(0, 3)), l)}`;
      break;
    case "f":
    case "ff":
    case "fff":
      a += `${ee(t.getMilliseconds().toString(), "0", e.length)}`;
      break;
    case "F":
    case "FF":
    case "FFF":
      a += `${t.getMilliseconds() == 0 ? "" : ee(t.getMilliseconds().toString(), "0", e.length)}`;
      break;
    case "g":
    case "gg":
      a += "A.D.";
      break;
    case "h":
    case "hh":
      a += `${ee((t.getHours() > 12 ? t.getHours() - 12 : t.getHours() == 0 ? 12 : t.getHours()).toString(), "0", e.length)}`;
      break;
    case "H":
    case "HH":
      a += `${ee(t.getHours().toString(), "0", e.length)}`;
      break;
    case "K":
    case "z":
    case "zz":
    case "zzz":
      let o = t.getTimezoneOffset() * -1, i = parseInt((o / 60).toFixed(0)), d = o - Math.abs(i) * 60;
      switch (e) {
        case "K":
        case "zzz":
          a += `${i < 0 ? "-" : "+"}${ee(Math.abs(i).toString(), "0", 2) + ":" + ee(Math.abs(d).toString(), "0", 2)}`;
          break;
        case "z":
        case "zz":
          a += `${i < 0 ? "-" : "+"}${ee(Math.abs(i).toString(), "0", e.length)}`;
          break;
      }
      break;
    case "m":
    case "mm":
      a += `${ee(t.getMinutes().toString(), "0", e.length)}`;
      break;
    case "M":
    case "MM":
      a += `${ee((t.getMonth() + 1).toString(), "0", e.length)}`;
      break;
    case "MMM":
    case "MMMM":
      let u = "";
      switch (t.getMonth()) {
        case 0:
          u = "January";
          break;
        case 1:
          u = "February";
          break;
        case 2:
          u = "March";
          break;
        case 3:
          u = "April";
          break;
        case 4:
          u = "May";
          break;
        case 5:
          u = "June";
          break;
        case 6:
          u = "July";
          break;
        case 7:
          u = "August";
          break;
        case 8:
          u = "September";
          break;
        case 9:
          u = "October";
          break;
        case 10:
          u = "November";
          break;
        case 11:
          u = "December";
          break;
      }
      a += `${V("Date.Months." + (e.length > 3 ? u : u.substring(0, 3)), l)}`;
      break;
    case "s":
    case "ss":
      a += `${ee(t.getSeconds().toString(), "0", e.length)}`;
      break;
    case "t":
    case "tt":
      t.getHours() >= 12 ? a += `${e.length == 1 ? "P" : "PM"}` : a += `${e.length == 1 ? "A" : "AM"}`;
      break;
    case "y":
    case "yy":
      for (var n = t.getFullYear().toString(); n.length > 2; )
        n = n.substring(1);
      a += `${ee(n.toString(), "0", e.length)}`;
      break;
    case "yyy":
    case "yyyy":
    case "yyyyy":
      a += `${ee(t.getFullYear().toString(), "0", e.length)}`;
      break;
    default:
      a += `[UNKOWN FORMAT ${e}]`;
      break;
  }
  return a;
}, Se = (e, l, t) => {
  t = t ?? "ddd MMM dd yyyy HH:mm:ss G\\MTzz00", l = l ?? f(() => "en");
  let a = "", n = "";
  for (var s = 0; s < t.length; s++)
    switch (t.charAt(s)) {
      case "\\":
        n != "" && (a += Oe(n, l, e), n = ""), a += t.charAt(s + 1), s++;
        break;
      case "d":
      case "f":
      case "F":
      case "g":
      case "h":
      case "H":
      case "K":
      case "m":
      case "M":
      case "s":
      case "t":
      case "y":
      case "z":
        n != "" && n.charAt(0) != t.charAt(s) ? (a += Oe(n, l, e), n = "") : n += t.charAt(s);
        break;
      default:
        n != "" && (a += Oe(n, l, e), n = ""), a += t.charAt(s);
        break;
    }
  return n != "" && (a += Oe(n, l, e), n = ""), a;
}, ct = RegExp("^(\\d{2}):(\\d{2}) (AM|PM)$"), lt = /* @__PURE__ */ D({
  __name: "time",
  props: {
    inputId: {},
    is_loading: { type: [Object, Boolean] },
    name: {},
    disabled: { type: Boolean }
  },
  emits: ["valueChanged"],
  setup(e, { expose: l, emit: t }) {
    const a = e, n = t, s = C(null), o = f(() => {
      if (s.value === null || s.value === "")
        return null;
      var u = Number(s.value.substring(3, 5)), m = Number(s.value.substring(0, 2)) % 12 + u / 60;
      return {
        backgroundImage: `url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='40' height='40'><circle cx='20' cy='20' r='18.5' fill='none' stroke='%23222' stroke-width='3' /><path d='M20,4 20,8 M4,20 8,20 M36,20 32,20 M20,36 20,32' stroke='%23bbb' stroke-width='1' /><circle cx='20' cy='20' r='2' fill='%23222' stroke='%23222' stroke-width='2' /></svg>"), url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='40' height='40'><path d='M18.5,24.5 19.5,4 20.5,4 21.5,24.5 Z' fill='%23222' style='transform:rotate(${360 * u / 60}deg); transform-origin: 50% 50%;' /></svg>"), url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='40' height='40'><path d='M18.5,24.5 19.5,8.5 20.5,8.5 21.5,24.5 Z' style='transform:rotate(${360 * m / 12}deg); transform-origin: 50% 50%;' /></svg>")`
      };
    });
    return U(s, (u) => {
      n("valueChanged", { name: a.name, value: u });
    }), l({
      /**
       * Gets the current value 
       */
      getValue: () => s.value,
      /**
       * Sets the current value
       * 
       * @param value string|null
       * @returns void
       */
      setValue: (u) => {
        if (u === "")
          u = null;
        else if (u !== null && ct.test(u)) {
          var m = ct.exec(u);
          u = `${m[3] === "AM" ? m[1] : (parseInt(m[1]) + 12).toFixed(0)}:${m[2]}:00`;
        }
        s.value = u;
      }
    }), (u, m) => (r(), B(p(W), {
      tag: "div",
      is_loading: a.is_loading,
      class: "control"
    }, {
      default: w(() => [
        F(p(W), {
          tag: "input",
          is_loading: a.is_loading,
          class: "input is-time",
          id: a.inputId,
          name: a.name,
          type: "time",
          modelValue: s.value,
          "onUpdate:modelValue": m[0] || (m[0] = (b) => s.value = b),
          disabled: a.disabled,
          style: Ae(o.value)
        }, null, 8, ["is_loading", "id", "name", "modelValue", "disabled", "style"])
      ]),
      _: 1
    }, 8, ["is_loading"]));
  }
}), vn = { class: "hero-body" }, yn = { class: "title" }, fn = {
  key: 0,
  class: "subtitle"
}, _n = /* @__PURE__ */ D({
  __name: "banner",
  props: {
    type: { default: Z.primary },
    title: {},
    subtitle: {}
  },
  setup(e) {
    const l = e;
    return (t, a) => (r(), c("section", {
      class: N(["hero", "is-small", "has-text-centered", e.type === void 0 ? "" : "is-" + l.type])
    }, [
      A("div", vn, [
        A("p", yn, x(l.title), 1),
        l.subtitle ? (r(), c("p", fn, x(l.subtitle), 1)) : O("", !0)
      ])
    ], 2));
  }
}), kn = { class: "box" }, Lt = /* @__PURE__ */ D({
  __name: "box",
  setup(e) {
    return (l, t) => (r(), c("div", kn, [
      T(l.$slots, "default")
    ]));
  }
}), Sn = { key: 0 }, Mn = ["onClick"], Dn = /* @__PURE__ */ D({
  __name: "breadcrumbs",
  props: {
    breadCrumbs: {},
    alignment: { default: Fe.left },
    size: { default: H.normal },
    seperator: {}
  },
  setup(e) {
    const l = e, t = f(() => {
      let n = ["breadcrumb"];
      return l.alignment && l.alignment !== Fe.left && n.push(`is-${l.alignment}`), l.size && l.size !== H.normal && n.push(`is-${l.size}`), l.seperator && n.push(`has-${l.seperator}-seperator`), n;
    }), a = (n) => {
      n !== void 0 && n();
    };
    return (n, s) => (r(), c("nav", {
      class: N(t.value),
      "aria-label": "breadcrumbs"
    }, [
      l.breadCrumbs !== null ? (r(), c("ul", Sn, [
        (r(!0), c(z, null, j(l.breadCrumbs, (o) => (r(), c("li", {
          class: N({ "is-active": o.active })
        }, [
          A("a", {
            onClick: (i) => a(o.onClick)
          }, [
            o.icon ? (r(), c("span", {
              key: 0,
              class: N(["icon", o.onClick ? "is-clickable" : ""])
            }, [
              F(p(K), {
                icon: o.icon
              }, null, 8, ["icon"])
            ], 2)) : O("", !0),
            G(" " + x(o.title), 1)
          ], 8, Mn)
        ], 2))), 256))
      ])) : O("", !0)
    ], 2));
  }
}), $n = {
  key: 0,
  class: "card-icon"
}, An = { class: "card-icon-wrapper" }, On = {
  key: 1,
  class: "card-header"
}, Jn = {
  key: 2,
  class: "card-content"
}, Nn = {
  key: 3,
  class: "card-footer"
}, Ut = /* @__PURE__ */ D({
  __name: "card",
  props: {
    full_width: { type: Boolean, default: !1 },
    full_height: { type: Boolean, default: !1 },
    icon: {}
  },
  setup(e) {
    const l = ce(), t = e, a = {
      addon_class: "card-footer-item"
    }, n = {
      header_class: "card-header-title has-text-centered",
      addon_class: "card-header-icon"
    };
    return (s, o) => (r(), c("div", {
      class: N(["card", { "is-fullwidth": t.full_width, "is-fullheight": t.full_height }])
    }, [
      t.icon ? (r(), c("div", $n, [
        A("div", An, [
          F(K, {
            icon: t.icon,
            size: p(se).xxlarge
          }, null, 8, ["icon", "size"])
        ])
      ])) : O("", !0),
      p(l).header ? (r(), c("div", On, [
        T(s.$slots, "header", me(_e(n)))
      ])) : O("", !0),
      p(l).content ? (r(), c("div", Jn, [
        T(s.$slots, "content")
      ])) : O("", !0),
      p(l).footer ? (r(), c("div", Nn, [
        T(s.$slots, "footer", me(_e(a)))
      ])) : O("", !0)
    ], 2));
  }
}), nt = /* @__PURE__ */ D({
  __name: "column-container",
  props: {
    modifiers: {},
    columns: {}
  },
  setup(e) {
    const l = ce(), t = e, a = f(() => {
      let s = ["columns"];
      return t.modifiers !== void 0 && t.modifiers !== null && (s = s.concat(t.modifiers.map((o) => `is-${o}`))), s;
    }), n = f(() => t.columns.map((s, o) => {
      let i = [
        "column",
        s.class ?? "",
        s.size ? `is-${s.size}` : "",
        s.offset ? `is-offset-${s.offset}` : ""
      ];
      return s.border && (s.border.some((d) => d === Ke.all) ? i.push("is-bordered") : s.border.forEach((d) => i.push(`is-bordered-${d}`))), {
        name: s.name ?? `col-${o}`,
        class: i
      };
    }));
    return (s, o) => (r(), c("div", {
      class: N(a.value)
    }, [
      (r(!0), c(z, null, j(n.value, (i) => (r(), c(z, null, [
        p(l)[i.name] ? (r(), c("div", {
          key: 0,
          class: N(i.class)
        }, [
          T(s.$slots, i.name)
        ], 2)) : O("", !0)
      ], 64))), 256))
    ], 2));
  }
}), wn = ["aria-label"], Fn = /* @__PURE__ */ D({
  __name: "footer",
  props: {
    aria_label: { default: "footer" }
  },
  setup(e) {
    const l = e;
    return (t, a) => (r(), c("footer", {
      class: "footer",
      "aria-label": l.aria_label
    }, [
      T(t.$slots, "default")
    ], 8, wn));
  }
}), Bn = ["aria-label"], xn = {
  key: 0,
  class: "level-left"
}, Tn = {
  key: 0,
  class: "level-item"
}, Pn = {
  key: 0,
  class: "level-item"
}, Cn = {
  key: 2,
  class: "level-right"
}, En = {
  key: 0,
  class: "level-item"
}, zn = /* @__PURE__ */ D({
  __name: "level",
  props: {
    aria_label: {},
    left_slots: {},
    right_slots: {},
    slots: {}
  },
  setup(e) {
    const l = e, t = ce();
    return (a, n) => (r(), c("nav", {
      class: "level",
      "aria-label": l.aria_label
    }, [
      l.left_slots ? (r(), c("div", xn, [
        (r(!0), c(z, null, j(l.left_slots, (s) => (r(), c(z, null, [
          p(t)[s] ? (r(), c("div", Tn, [
            T(a.$slots, s)
          ])) : O("", !0)
        ], 64))), 256))
      ])) : O("", !0),
      l.slots ? (r(!0), c(z, { key: 1 }, j(l.slots, (s) => (r(), c(z, null, [
        p(t)[s] ? (r(), c("div", Pn, [
          T(a.$slots, s)
        ])) : O("", !0)
      ], 64))), 256)) : O("", !0),
      l.right_slots ? (r(), c("div", Cn, [
        (r(!0), c(z, null, j(l.right_slots, (s) => (r(), c(z, null, [
          p(t)[s] ? (r(), c("div", En, [
            T(a.$slots, s)
          ])) : O("", !0)
        ], 64))), 256))
      ])) : O("", !0)
    ], 8, Bn));
  }
}), Rn = { class: "media" }, In = /* @__PURE__ */ D({
  __name: "media",
  props: {
    is_loading: { type: [Object, Boolean], default: void 0 }
  },
  setup(e) {
    const l = ce(), t = e;
    return (a, n) => (r(), c("article", Rn, [
      p(l).left_figure ? (r(), B(p(W), {
        key: 0,
        tag: "figure",
        is_loading: t.is_loading,
        class: "media-left"
      }, {
        default: w(() => [
          T(a.$slots, "left_figure")
        ]),
        _: 3
      }, 8, ["is_loading"])) : O("", !0),
      F(p(W), {
        is_loading: t.is_loading,
        class: "media-content"
      }, {
        default: w(() => [
          T(a.$slots, "content")
        ]),
        _: 3
      }, 8, ["is_loading"]),
      p(l).right_section ? (r(), B(p(W), {
        key: 1,
        is_loading: t.is_loading,
        class: "media-right"
      }, {
        default: w(() => [
          T(a.$slots, "right_section")
        ]),
        _: 3
      }, 8, ["is_loading"])) : O("", !0)
    ]));
  }
}), Wn = { class: "modal-content" }, jn = /* @__PURE__ */ D({
  __name: "modal",
  props: {
    display: { type: Boolean, default: !0 },
    has_close: { type: Boolean, default: !1 },
    z_index: { default: 99 }
  },
  emits: ["close"],
  setup(e, { emit: l }) {
    const t = e, a = l;
    return (n, s) => (r(), c("div", {
      class: N({ modal: !0, "is-active": t.display }),
      style: Ae(`z-index:${t.z_index}`)
    }, [
      s[1] || (s[1] = A("div", { class: "modal-background" }, null, -1)),
      A("div", Wn, [
        T(n.$slots, "default")
      ]),
      t.has_close ? (r(), c("button", {
        key: 0,
        class: "modal-close is-large",
        "aria-label": "close",
        onClick: s[0] || (s[0] = (o) => a("close"))
      })) : O("", !0)
    ], 6));
  }
}), Vn = {
  key: 0,
  class: "card-icon"
}, Ln = { class: "card-icon-wrapper" }, Un = {
  key: 1,
  class: "modal-card-head"
}, Gn = {
  key: 2,
  class: "modal-card-body"
}, Hn = {
  key: 3,
  class: "modal-card-foot"
}, Gt = /* @__PURE__ */ D({
  __name: "modal-card",
  props: {
    show: { type: Boolean },
    has_close: { type: Boolean },
    max_width: { type: Boolean },
    max_height: { type: Boolean },
    full_width: { type: Boolean },
    full_height: { type: Boolean },
    icon: {}
  },
  emits: ["close"],
  setup(e, { emit: l }) {
    const t = ce(), a = e, n = l, s = {
      addon_class: "card-footer-item"
    }, o = {
      header_class: "modal-card-title has-text-centered",
      addon_class: "card-header-icon"
    }, i = f(() => {
      var d = [];
      return a.full_width && d.push("is-fullwidth"), a.full_height && d.push("is-fullheight"), a.max_width && d.push("is-maxwidth"), a.max_height && d.push("is-maxheight"), d;
    });
    return (d, u) => (r(), c("div", {
      class: N(["modal", { "is-active": a.show }])
    }, [
      u[1] || (u[1] = A("div", { class: "modal-background" }, null, -1)),
      A("div", {
        class: N(["modal-card", i.value])
      }, [
        a.icon ? (r(), c("div", Vn, [
          A("div", Ln, [
            F(K, {
              icon: a.icon,
              size: p(se).xxlarge
            }, null, 8, ["icon", "size"])
          ])
        ])) : O("", !0),
        p(t).header ? (r(), c("div", Un, [
          T(d.$slots, "header", me(_e(o))),
          a.has_close ? (r(), c("button", {
            key: 0,
            class: "delete",
            "aria-label": "close",
            onClick: u[0] || (u[0] = (m) => n("close"))
          })) : O("", !0)
        ])) : O("", !0),
        p(t).content ? (r(), c("div", Gn, [
          T(d.$slots, "content")
        ])) : O("", !0),
        p(t).footer ? (r(), c("div", Hn, [
          T(d.$slots, "footer", me(_e(s)))
        ])) : O("", !0)
      ], 2)
    ], 2));
  }
}), Kn = {
  key: 0,
  class: "panel-heading"
}, Yn = {
  key: 1,
  class: "panel-tabs"
}, qn = {
  key: 0,
  class: "panel-block"
}, Zn = /* @__PURE__ */ D({
  __name: "panel",
  props: {
    type: {},
    block_names: {},
    full_width: { type: Boolean },
    full_height: { type: Boolean },
    hidden_sections: {}
  },
  setup(e) {
    const l = ce(), t = e, a = f(() => t.block_names ?? ["default"]), n = f(() => [
      t.type ? `is-${t.type}` : "",
      t.full_width ? "is-fullwidth" : "",
      t.full_height ? "is-fullheight" : ""
    ]);
    return (s, o) => (r(), c("div", {
      class: N(["panel", n.value])
    }, [
      p(l).header ? le((r(), c("div", Kn, [
        T(s.$slots, "header")
      ], 512)), [
        [oe, !(t.hidden_sections ?? []).includes("header")]
      ]) : O("", !0),
      p(l).tabs ? le((r(), c("div", Yn, [
        T(s.$slots, "tabs")
      ], 512)), [
        [oe, !(t.hidden_sections ?? []).includes("tabs")]
      ]) : O("", !0),
      (r(!0), c(z, null, j(a.value, (i) => (r(), c(z, null, [
        p(l)[i] ? le((r(), c("div", qn, [
          T(s.$slots, i)
        ], 512)), [
          [oe, !(t.hidden_sections ?? []).includes(i)]
        ]) : O("", !0)
      ], 64))), 256))
    ], 2));
  }
}), Qn = /* @__PURE__ */ D({
  __name: "section",
  props: {
    size: {}
  },
  setup(e) {
    const l = e;
    return (t, a) => (r(), c("section", {
      class: N(["section", l.size ? `is-${l.size}` : ""])
    }, [
      T(t.$slots, "default")
    ], 2));
  }
}), Xn = { key: 0 }, eo = { key: 1 }, to = { key: 2 }, ot = /* @__PURE__ */ D({
  __name: "table",
  props: {
    scrollable: { type: Boolean, default: !1 },
    fixed_header: { type: Boolean, default: !1 },
    full_width: { type: Boolean },
    narrow: { type: Boolean }
  },
  setup(e) {
    const l = ce(), t = e, a = f(() => [
      t.scrollable ? "table-container" : "",
      t.fixed_header && !t.scrollable ? "is-fixed" : ""
    ]), n = f(() => [
      "table",
      "is-striped",
      "is-hoverable",
      t.fixed_header && !t.scrollable ? "is-fixed" : "",
      t.full_width ? "is-fullwidth" : "",
      t.narrow ? "is-narrow" : ""
    ]);
    return (s, o) => (r(), c("div", {
      class: N(a.value)
    }, [
      A("table", {
        class: N(n.value)
      }, [
        p(l).thead ? (r(), c("thead", Xn, [
          T(s.$slots, "thead")
        ])) : O("", !0),
        p(l).tbody ? (r(), c("tbody", eo, [
          T(s.$slots, "tbody")
        ])) : O("", !0),
        p(l).tfoot ? (r(), c("tfoot", to, [
          T(s.$slots, "tfoot")
        ])) : O("", !0)
      ], 2)
    ], 2));
  }
}), ao = ["href", "onClick"], lo = {
  key: 0,
  class: "icon is-small"
}, no = { style: { width: "100px" } }, oo = /* @__PURE__ */ D({
  __name: "tabs",
  props: {
    tabs: {},
    alignment: { default: Ye.left },
    type: {},
    full_width: { type: Boolean }
  },
  setup(e) {
    const l = e, t = f(() => [
      "tabs",
      `is-${l.alignment}`,
      l.type ? `is-${l.type}` : "",
      l.full_width ? "is-fullwidth" : ""
    ]), a = (n, s) => {
      (s.href === null || s.href === void 0) && s.onClick !== void 0 && (n.preventDefault(), s.onClick());
    };
    return (n, s) => (r(), c("div", {
      class: N(t.value)
    }, [
      A("ul", null, [
        F(p(be), {
          promise: l.tabs
        }, {
          default: w(({ response: o }) => [
            (r(!0), c(z, null, j(o, (i) => (r(), c("li", {
              class: N({ "is-active": i.active })
            }, [
              A("a", {
                href: i.href,
                onClick: (d) => a(d, i)
              }, [
                i.icon ? (r(), c("span", lo, [
                  F(p(K), {
                    icon: i.icon
                  }, null, 8, ["icon"])
                ])) : O("", !0),
                A("span", null, x(i.title), 1)
              ], 8, ao)
            ], 2))), 256))
          ]),
          pending: w(() => [
            A("li", no, [
              F(p(ke), {
                size: p(H).small
              }, null, 8, ["size"])
            ])
          ]),
          _: 1
        }, 8, ["promise"])
      ])
    ], 2));
  }
}), so = { class: "slideout-content" }, ro = {
  key: 1,
  class: "slideout-head"
}, io = { class: "slideout-body" }, uo = {
  key: 2,
  class: "slideout-foot"
}, co = /* @__PURE__ */ D({
  __name: "slideout",
  props: {
    show: { type: Boolean },
    has_close: { type: Boolean },
    full_width: { type: Boolean },
    type: {},
    not_animated: { type: Boolean }
  },
  emits: ["close"],
  setup(e, { emit: l }) {
    const t = ce(), a = {
      addon_class: ""
    }, n = {
      header_class: "slideout-title has-text-centered",
      addon_class: ""
    }, s = e, o = l, i = f(() => [
      "slideout",
      s.show ? "is-active" : "",
      s.type !== void 0 && s.type !== null ? `is-${s.type}` : "",
      s.full_width ? "is-fullwidth" : "",
      s.not_animated ? "no-animation" : ""
    ]);
    return (d, u) => (r(), c("div", {
      class: N(i.value)
    }, [
      A("div", {
        class: "slideout-background",
        onClick: u[0] || (u[0] = (m) => o("close"))
      }),
      A("div", so, [
        s.has_close ? (r(), c("button", {
          key: 0,
          class: "delete",
          "aria-label": "close",
          onClick: u[1] || (u[1] = (m) => o("close"))
        })) : O("", !0),
        p(t).header ? (r(), c("div", ro, [
          T(d.$slots, "header", me(_e(n)))
        ])) : O("", !0),
        A("div", io, [
          p(t).content ? T(d.$slots, "content", { key: 0 }) : O("", !0),
          T(d.$slots, "default")
        ]),
        p(t).footer ? (r(), c("div", uo, [
          T(d.$slots, "footer", me(_e(a)))
        ])) : O("", !0)
      ])
    ], 2));
  }
}), po = ["onClick"], mo = { key: 1 }, go = {
  key: 0,
  class: "step-details"
}, bo = { class: "step-title" }, ho = { key: 0 }, vo = { class: "steps-content" }, yo = { class: "steps-actions" }, fo = { class: "steps-action" }, _o = {
  key: 0,
  class: "steps-action"
}, ko = {
  key: 1,
  class: "steps-action"
}, So = /* @__PURE__ */ D({
  __name: "step-wizard",
  props: {
    steps: {},
    use_previous_next: { type: Boolean, default: !0 },
    size: { default: H.normal },
    starting_index: {},
    orientation: { default: xe.default }
  },
  emits: ["done", "changedStep"],
  setup(e, { expose: l, emit: t }) {
    const a = ce(), n = Q(R), s = f(() => V("Pagination.Previous", n)), o = f(() => V("Pagination.Next", n)), i = f(() => V("Wizard.Done", n)), d = e, u = t, m = C(d.starting_index ?? 0);
    return U(m, (b, _) => {
      u("changedStep", b);
    }), l({
      /**
       * Used to move to a given step in the wizard
       * 
       * @param index the step index to move to
       */
      moveToStep: (b) => {
        m.value = b;
      }
    }), (b, _) => (r(), c("div", {
      class: N(["steps-container", d.orientation === p(xe).default ? "" : `${d.orientation}`])
    }, [
      A("ul", {
        class: N(["steps", d.size === p(H).normal ? "" : `is-${d.size}`])
      }, [
        (r(!0), c(z, null, j(d.steps, (g, y) => (r(), c("li", {
          class: N(["step-item", y < m.value ? "is-completed" : "", y === m.value ? "is-active" : "", g.type ? `is-${g.type}` : ""])
        }, [
          A("div", {
            class: "step-marker is-clickable",
            onClick: (h) => u("changedStep", y)
          }, [
            g.icon ? (r(), B(K, {
              key: 0,
              icon: g.icon
            }, null, 8, ["icon"])) : (r(), c("span", mo, x(y + 1), 1))
          ], 8, po),
          g.title !== "" ? (r(), c("div", go, [
            A("p", bo, x(g.title), 1),
            g.description ? (r(), c("p", ho, x(g.description), 1)) : O("", !0)
          ])) : O("", !0)
        ], 2))), 256))
      ], 2),
      A("div", vo, [
        (r(!0), c(z, null, j(d.steps, (g, y) => (r(), c(z, null, [
          p(a)[g.name] ? (r(), c("div", {
            key: 0,
            class: N(["step-content", y === m.value ? "is-active" : ""])
          }, [
            T(b.$slots, g.name)
          ], 2)) : O("", !0)
        ], 64))), 256))
      ]),
      A("div", yo, [
        d.use_previous_next ? (r(), c(z, { key: 0 }, [
          A("div", fo, [
            F(te, {
              title: s.value,
              disabled: m.value === 0,
              onClick: _[0] || (_[0] = () => {
                m.value--;
              })
            }, null, 8, ["title", "disabled"])
          ]),
          m.value + 1 < d.steps.length ? (r(), c("div", _o, [
            F(te, {
              title: o.value,
              disabled: !(d.steps[m.value].is_valid === void 0 || d.steps[m.value].is_valid),
              onClick: _[1] || (_[1] = () => {
                m.value++;
              })
            }, null, 8, ["title", "disabled"])
          ])) : O("", !0),
          m.value + 1 === d.steps.length ? (r(), c("div", ko, [
            F(te, {
              title: i.value,
              disabled: !(d.steps[m.value].is_valid === void 0 || d.steps[m.value].is_valid),
              onClick: _[2] || (_[2] = () => {
                u("done");
              })
            }, null, 8, ["title", "disabled"])
          ])) : O("", !0)
        ], 64)) : (r(), c(z, { key: 1 }, [
          p(a).actions ? T(b.$slots, "actions", { key: 0 }) : O("", !0),
          (r(!0), c(z, null, j(d.steps, (g, y) => (r(), c(z, null, [
            p(a)[`actions-${g.name}`] && y === m.value ? T(b.$slots, `actions-${g.name}`, { key: 0 }) : O("", !0)
          ], 64))), 256))
        ], 64))
      ])
    ], 2));
  }
}), Mo = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  Banner: _n,
  Box: Lt,
  Breadcrumbs: Dn,
  Card: Ut,
  ColumnContainer: nt,
  Footer: Fn,
  Level: zn,
  List: It,
  Media: In,
  Modal: jn,
  ModalCard: Gt,
  Panel: Zn,
  Section: Qn,
  Slideout: co,
  StepWizard: So,
  Table: ot,
  Tabs: oo
}, Symbol.toStringTag, { value: "Module" })), Do = ["onClick"], $o = {
  colspan: "100%",
  class: "has-text-centered"
}, $e = RegExp("^(\\d{2})-(\\d{2})-(\\d{4})$"), Je = RegExp("^(\\d{2})-(\\d{2})-(\\d{4}) (\\d{2}):(\\d{2})$"), Ht = /* @__PURE__ */ D({
  __name: "date",
  props: {
    includeTime: { type: Boolean },
    inputId: {},
    is_loading: { type: [Object, Boolean] },
    name: {},
    disabled: { type: Boolean, default: !1 }
  },
  emits: ["valueChanged"],
  setup(e, { expose: l, emit: t }) {
    const a = C(), n = e, s = t, o = C(!1), i = C(null), d = C(null), u = ua({
      Month: (/* @__PURE__ */ new Date()).getMonth(),
      Year: (/* @__PURE__ */ new Date()).getFullYear(),
      Today: (/* @__PURE__ */ new Date()).getDate()
    }), m = Q(R), b = fe({
      Sun: f(() => V("Date.Weekdays.Sun", m)),
      Mon: f(() => V("Date.Weekdays.Mon", m)),
      Tue: f(() => V("Date.Weekdays.Tue", m)),
      Wed: f(() => V("Date.Weekdays.Wed", m)),
      Thu: f(() => V("Date.Weekdays.Thu", m)),
      Fri: f(() => V("Date.Weekdays.Fri", m)),
      Sat: f(() => V("Date.Weekdays.Sat", m))
    }), _ = f(() => i.value !== null && (n.includeTime ? Je : $e).test(i.value)), g = () => {
      if (i.value === null || i.value === "")
        return null;
      {
        if (!Je.test(i.value) && n.includeTime)
          return null;
        if (!n.includeTime && !$e.test(i.value))
          return null;
        if ($e.test(i.value) && n.includeTime)
          return null;
        let S = n.includeTime ? Je.exec(i.value) : $e.exec(i.value);
        return new Date(
          parseInt(S[3]),
          parseInt(S[2]) - 1,
          parseInt(S[1]),
          n.includeTime ? parseInt(S[4]) : 0,
          n.includeTime ? parseInt(S[5]) : 0,
          0,
          0
        );
      }
    };
    U(i, (S) => {
      if (S === null)
        s("valueChanged", { name: n.name, value: null }), u.Month = (/* @__PURE__ */ new Date()).getMonth(), u.Year = (/* @__PURE__ */ new Date()).getFullYear();
      else if (!$e.test(S) && !Je.test(S)) {
        S = S.replaceAll(/[^0-9]/g, "");
        for (var P = [], L = 0; L < S.length; L += 2)
          L == 4 ? (P.push(S.substring(L, Math.min(S.length - L, 4) + L)), L += 2) : P.push(S.substring(L, Math.min(S.length - L, 2) + L));
        P.length > 0 && (/^([0-1]|(0[1-9])|(1[0-2]))$/.test(P[0]) || P.splice(0), P.length > 1 && (/^[0-3]/.test(P[1]) ? /^(01|03|05|07|08|10|12)$/.test(P[0]) ? /^([0-3]|(0[1-9])|([1-2][0-9])|(3[0-1]))$/.test(P[1]) || P.splice(1) : /^(02|04|06|09|11)$/.test(P[0]) ? /^([0-3]|(0[1-9])|([1-2][0-9])|(30))$/.test(P[1]) || P.splice(1) : /^([0-2]|(0[1-9])|([1-2][0-9]))$/.test(P[1]) || P.splice(1) : P.splice(1)), P.length > 3 && (/^([0-2]|([0-1][0-9])|(2[0-3]))$/.test(P[3]) || P.splice(3)), P.length > 4 && (/^[0-5][0-9]?$/.test(P[4]) || P.splice(4))), S = P.join(""), !n.includeTime && S.length > 8 && (S = S.substring(0, 8)), S.length >= 2 && (S = S.substring(0, 2) + "-" + (S.length > 2 ? S.substring(2) : "")), S.length >= 5 && (S = S.substring(0, 5) + "-" + (S.length > 5 ? S.substring(5) : "")), S.length >= 9 && n.includeTime && (S = S.substring(0, 9) + " " + (S.length > 9 ? S.substring(9) : "")), S.length >= 11 && (S = S.substring(0, 11) + ":" + (S.length > 11 ? S.substring(11) : "")), i.value = S;
      } else {
        var re = g();
        _ && s("valueChanged", { name: n.name, value: re }), u.Month = re?.getMonth() ?? (/* @__PURE__ */ new Date()).getMonth(), u.Year = re?.getFullYear() ?? (/* @__PURE__ */ new Date()).getFullYear();
      }
    });
    const y = f(() => Se(new Date(u.Year, u.Month, 1), m, "MMMM")), h = f(() => {
      var S = [], P = new Date(u.Year, u.Month, 1);
      P = We(P, P.getDay() * -1);
      for (var L = g(), re = We(new Date(u.Year, u.Month, 1), 32).getMonth(); P.getMonth() != re; ) {
        for (var ze = [], st = 0; st < 7; st++)
          ze.push({
            Number: P.getDate(),
            Disabled: P.getMonth() != u.Month,
            isToday: Se(P, m, "yyyy-MM-dd") == Se(/* @__PURE__ */ new Date(), m, "yyyy-MM-dd"),
            isSelected: L != null && Se(P, m, "yyyy-MM-dd") == Se(L, m, "yyyy-MM-dd")
          }), P = We(P, 1);
        S.push(ze);
      }
      return S;
    });
    l({
      /**
       * Gets the current value 
       */
      getValue: g,
      /**
       * Sets the current value
       * 
       * @param value Date|null
       * @returns void
       */
      setValue: function(S) {
        S === null ? i.value = null : i.value = Se(S, m, `dd-MM-yyyy${n.includeTime ? " HH:mm" : ""}`);
      }
    });
    const J = (S) => {
      S.value == null ? i.value != null && (i.value = i.value.split(" ")[0]) : i.value != null ? i.value = i.value.split(" ")[0] + " " + S.value : i.value = `${ee((u.Month == (/* @__PURE__ */ new Date()).getMonth() ? (/* @__PURE__ */ new Date()).getDate() : 1).toString(), "0", 2)}-${ee((u.Month + 1).toString(), "0", 2)}-${u.Year} ${S.value}`;
    }, M = (S) => {
      if (!S.Disabled && !S.isSelected)
        if (i.value === null)
          i.value = `${ee(S.Number.toString(), "0", 2)}-${ee((u.Month + 1).toString(), "0", 2)}-${u.Year}` + (n.includeTime ? a.value?.getValue() == null ? "" : " " + a.value.getValue() : "");
        else {
          var P = i.value.split(" ");
          P[0] = `${ee(S.Number.toString(), "0", 2)}-${ee((u.Month + 1).toString(), "0", 2)}-${u.Year}`, i.value = `${P[0]}${P.length > 1 ? " " + P[1] : ""}`;
        }
    }, E = () => {
      i.value = d.value, o.value = !1;
    }, X = () => {
      n.disabled || (d.value = i.value, o.value = !0);
    }, k = () => {
      n.disabled || (i.value = null);
    }, q = (S) => {
      u.Month + S == -1 ? (u.Year = u.Year - 1, u.Month = 11) : u.Month + S == 12 ? (u.Year = u.Year + 1, u.Month = 0) : u.Month += S;
    };
    return (S, P) => (r(), c("div", null, [
      F(p(W), {
        tag: "div",
        is_loading: n.is_loading,
        class: "control has-icons-left has-icons-right"
      }, {
        default: w(() => [
          F(p(W), {
            tag: "input",
            is_loading: n.is_loading,
            class: "input is-expanded",
            name: n.name,
            id: n.inputId,
            type: "text",
            modelValue: i.value,
            "onUpdate:modelValue": P[0] || (P[0] = (L) => i.value = L),
            placeholder: "DD-MM-YYYY" + (n.includeTime ? " HH:mm" : ""),
            disabled: n.disabled
          }, null, 8, ["is_loading", "name", "id", "modelValue", "placeholder", "disabled"]),
          A("span", {
            class: "icon is-small is-left is-clickable",
            onClick: X
          }, [
            F(p(K), {
              is_loading: n.is_loading,
              icon: "calendar-alt",
              size: p(se).xlarge
            }, null, 8, ["is_loading", "size"])
          ]),
          A("span", {
            class: "icon is-small is-right is-clickable",
            onClick: k
          }, [
            F(p(K), {
              is_loading: n.is_loading,
              icon: "window-close",
              size: p(se).xlarge
            }, null, 8, ["is_loading", "size"])
          ])
        ]),
        _: 1
      }, 8, ["is_loading"]),
      F(p(Gt), {
        show: o.value,
        icon: "calendar-alt"
      }, {
        header: w(() => [
          F(p(nt), {
            class: "card-header-title",
            columns: [{ name: "left" }, { name: "title", class: "has-text-centered" }, { name: "right", class: "has-text-right" }]
          }, {
            left: w(() => [
              F(p(K), {
                class: "is-clickable",
                icon: "arrow-circle-left",
                onClick: P[1] || (P[1] = (L) => q(-1))
              })
            ]),
            title: w(() => [
              G(x(y.value) + " " + x(u.Year), 1)
            ]),
            right: w(() => [
              F(p(K), {
                class: "is-clickable",
                icon: "arrow-circle-right",
                onClick: P[2] || (P[2] = (L) => q(1))
              })
            ]),
            _: 1
          })
        ]),
        content: w(() => [
          F(p(ot), { full_width: !0 }, Te({
            thead: w(() => [
              A("tr", null, [
                A("th", null, x(p(b).Sun), 1),
                A("th", null, x(p(b).Mon), 1),
                A("th", null, x(p(b).Tue), 1),
                A("th", null, x(p(b).Wed), 1),
                A("th", null, x(p(b).Thu), 1),
                A("th", null, x(p(b).Fri), 1),
                A("th", null, x(p(b).Sat), 1)
              ])
            ]),
            tbody: w(() => [
              (r(!0), c(z, null, j(h.value, (L) => (r(), c("tr", null, [
                (r(!0), c(z, null, j(L, (re) => (r(), c("td", {
                  class: N(["is-unselectable has-text-centered", re.Disabled ? "has-text-primary-dark has-background-primary-light" : "is-clickable", re.isToday ? "has-background-primary-dark has-text-primary-light" : "", re.isSelected ? "has-background-success-dark has-text-success-light" : ""]),
                  onClick: (ze) => M(re)
                }, x(re.Number), 11, Do))), 256))
              ]))), 256))
            ]),
            _: 2
          }, [
            n.includeTime ? {
              name: "tfoot",
              fn: w(() => [
                A("tr", null, [
                  A("td", $o, [
                    F(lt, {
                      ref: a.value,
                      name: `${n.name}-time`,
                      disabled: n.disabled,
                      onValueChanged: J
                    }, null, 8, ["name", "disabled"])
                  ])
                ])
              ]),
              key: "0"
            } : void 0
          ]), 1024)
        ]),
        footer: w(({ addon_class: L }) => [
          F(p(Tt), {
            class: N(L),
            disabled: !_.value,
            onClick: P[3] || (P[3] = (re) => o.value = !1)
          }, null, 8, ["class", "disabled"]),
          F(p(xt), {
            class: N(L),
            onClick: E
          }, null, 8, ["class"])
        ]),
        _: 1
      }, 8, ["show"])
    ]));
  }
}), Kt = /* @__PURE__ */ D({
  __name: "full-editor",
  props: {
    inputId: {},
    is_loading: { type: [Object, Boolean] },
    name: {},
    disabled: { type: Boolean }
  },
  emits: ["valueChanged"],
  async setup(e, { expose: l, emit: t }) {
    let a, n;
    const s = va(R);
    Pe([`${s}summernote-lite.min.css`]), [a, n] = da(() => import(`${s}summernote`)), await a, n();
    const o = C(null), i = e, d = t;
    return U(() => i.disabled, (b) => {
      o.value != null && $(o.value).summernote(b ? "disable" : "enable");
    }), l({
      /**
       * Gets the current value 
       */
      getValue: () => $(o.value).summernote("code"),
      /**
       * Sets the current value
       * 
       * @param value string|null
       * @returns void
       */
      setValue: (b) => {
        $(o.value).summernote("code", b);
      }
    }), de(() => {
      $(o.value).summernote({
        height: 400,
        callbacks: {
          onChange: function(b) {
            d("valueChanged", { name: i.name, value: b });
          }
        }
      }), (i.disabled ?? !1) && $(o.value).summernote("disable");
    }), ca(() => {
      $(o.value).summernote("destroy");
    }), (b, _) => (r(), B(p(W), {
      tag: "div",
      is_loading: i.is_loading,
      class: "summernote",
      ref_key: "snote",
      ref: o
    }, null, 8, ["is_loading"]));
  }
}), Ve = /* @__PURE__ */ D({
  __name: "header",
  props: {
    label: {},
    subtype: { default: "h1" },
    translate: {},
    is_loading: { type: [Object, Boolean] }
  },
  setup(e) {
    const l = e, t = pe(l, R);
    return (a, n) => (r(), B(p(W), {
      tag: l.subtype,
      is_loading: l.is_loading,
      class: "title"
    }, {
      default: w(() => [
        G(x(p(t)(l.label ?? "")), 1)
      ]),
      _: 1
    }, 8, ["tag", "is_loading"]));
  }
}), Ao = ["name"], Yt = /* @__PURE__ */ D({
  __name: "hidden",
  props: {
    name: {}
  },
  emits: ["valueChanged"],
  setup(e, { expose: l, emit: t }) {
    const a = e, n = t, s = C(null);
    return U(s, (d) => n("valueChanged", { name: a.name, value: d })), l({
      /**
       * Gets the current value 
       */
      getValue: () => s.value,
      /**
       * Sets the current value
       * 
       * @param value string|null
       * @returns void
       */
      setValue: (d) => {
        s.value = d;
      }
    }), (d, u) => le((r(), c("input", {
      type: "hidden",
      name: a.name,
      "onUpdate:modelValue": u[0] || (u[0] = (m) => s.value = m)
    }, null, 8, Ao)), [
      [mt, s.value]
    ]);
  }
}), qt = /* @__PURE__ */ D({
  __name: "number",
  props: {
    min: {},
    max: {},
    step: {},
    inputId: {},
    is_loading: { type: [Object, Boolean] },
    name: {},
    disabled: { type: Boolean, default: !1 }
  },
  emits: ["valueChanged"],
  setup(e, { expose: l, emit: t }) {
    const a = e, n = t, s = C(null), o = () => {
      if (s.value === "" || s.value === null)
        return null;
      let d = parseInt(s.value);
      return a.min !== void 0 && d < a.min * 1 || a.max !== void 0 && d > a.max * 1 ? null : d;
    }, i = (d) => {
      s.value = d === null ? "" : d.toString();
    };
    return U([s], (d) => n("valueChanged", { name: a.name, value: o() })), l({
      /**
       * Gets the current value 
       */
      getValue: o,
      /**
       * Sets the current value
       * 
       * @param value number|string|null
       * @returns void
       */
      setValue: i
    }), (d, u) => (r(), B(p(W), {
      tag: "input",
      is_loading: a.is_loading,
      type: "number",
      class: "input",
      id: a.inputId,
      name: a.name,
      modelValue: s.value,
      "onUpdate:modelValue": u[0] || (u[0] = (m) => s.value = m),
      disabled: a.disabled,
      min: a.min,
      max: a.max,
      step: a.step
    }, null, 8, ["is_loading", "id", "name", "modelValue", "disabled", "min", "max", "step"]));
  }
}), Le = /* @__PURE__ */ D({
  __name: "paragraph",
  props: {
    label: {},
    name: {},
    inputId: {},
    is_loading: { type: [Object, Boolean] },
    translate: { type: Function }
  },
  setup(e) {
    const l = e, t = pe(l, R);
    return (a, n) => (r(), B(p(W), {
      tag: "p",
      is_loading: l.is_loading,
      class: "is-form-paragraph",
      id: l.inputId
    }, {
      default: w(() => [
        G(x(p(t)(l.label ?? "")), 1)
      ]),
      _: 1
    }, 8, ["is_loading", "id"]));
  }
}), Zt = /* @__PURE__ */ D({
  __name: "radio-group",
  props: {
    values: { type: [Array, Promise, Function, null] },
    inputId: {},
    is_loading: { type: [Object, Boolean] },
    name: {},
    disabled: { type: Boolean },
    translate: { type: Function }
  },
  emits: ["valueChanged"],
  setup(e, { expose: l, emit: t }) {
    const a = e, n = Q(R), s = f(() => V("Form.Error", n)), o = t, i = pe(a, R), d = C(null), u = () => d.value;
    U(d, (y) => {
      o("valueChanged", { name: a.name, value: u() });
    });
    const m = f(async () => {
      if (a.values == null)
        return [];
      {
        let y = await at(a.values);
        return d.value === null && y.some((h) => h.selected) && (d.value = y.find((h) => h.selected)?.value), y.map((h) => ({
          label: h.label,
          value: h.value,
          selected: d.value === h.value
        }));
      }
    }), b = (y) => {
      d.value = y;
    }, { hiddenValues: _, disabledValues: g } = tt(a.name, R);
    return l({
      /**
       * Gets the current value 
       */
      getValue: u,
      /**
       * Sets the current value
       * 
       * @param value any|null
       * @returns void
       */
      setValue: b
    }), (y, h) => (r(), c("div", null, [
      F(be, { promise: m.value }, {
        default: w(({ response: v }) => [
          e.values != null ? (r(!0), c(z, { key: 0 }, j(v, (J, M) => le((r(), B(p(W), {
            tag: "label",
            is_loading: a.is_loading,
            class: "radio is-block",
            for: `${a.inputId}-${M}`
          }, {
            default: w(() => [
              F(p(W), {
                tag: "input",
                is_loading: a.is_loading,
                type: "radio",
                name: a.name,
                value: J.value,
                class: "radio",
                disabled: a.disabled || p(g).some((E) => E === J.value.toString()),
                id: `${a.inputId}-${M}`
              }, null, 8, ["is_loading", "name", "value", "disabled", "id"]),
              G(" " + x(p(i)(J.label)), 1)
            ]),
            _: 2
          }, 1032, ["is_loading", "for"])), [
            [oe, !p(_).some((E) => E === J.value.toString())]
          ])), 256)) : O("", !0)
        ]),
        rejected: w(() => [
          F(p(ge), {
            type: p(ue).danger,
            message: s.value
          }, null, 8, ["type", "message"])
        ]),
        _: 1
      }, 8, ["promise"])
    ]));
  }
}), Oo = ["value", "selected", "disabled"], Jo = ["label", "disabled"], No = ["value", "selected", "disabled"], Qt = (e, l, t) => {
  let a = {
    label: e === null ? l.label : `${e}->${l.label}`,
    values: [],
    value: l.value
  }, n = t.length;
  return t.push(a), l.values.forEach((s) => {
    s.values === void 0 ? a.values.push(s) : t = Qt(a.label, s, t);
  }), t[n].values.length == 0 && t.splice(n, 1), t;
}, Xt = /* @__PURE__ */ D({
  __name: "select",
  props: {
    values: {},
    multiple: { type: Boolean, default: !1 },
    inputId: {},
    is_loading: { type: [Object, Boolean] },
    name: {},
    disabled: { type: Boolean },
    translate: {}
  },
  emits: ["valueChanged"],
  setup(e, { expose: l, emit: t }) {
    const a = e, n = Q(R), s = f(() => V("Form.Error", n)), o = t, i = pe(a, R), d = C(a.multiple ? [] : null), u = C(!1), m = f(async () => {
      if (a.values == null)
        return [];
      {
        let h = await at(a.values), v = h.filter((M) => M.selected).map((M) => M.value);
        h.some((M) => M.values !== void 0) && h.filter((M) => M.values !== void 0).forEach((M) => {
          v = v.concat(
            M.values?.filter((E) => E.selected).map((E) => E.value)
          );
        }), d.value === null || d.value.length === 0 ? d.value = a.multiple ? [] : null : (h = h.map((M) => {
          let E = M;
          return E.values !== void 0 && (E.values = E.values.map((X) => (X.selected = d.value?.some((k) => k === X.value), X))), E;
        }), d.value !== null && Array.isArray(d.value) && (d.value = d.value.filter((M) => h.some((E) => E.value === M))));
        let J = [];
        return h.forEach((M) => {
          M.values === void 0 ? J.push(M) : J = Qt(null, M, J);
        }), J;
      }
    }), b = () => d.value === null || d.value.length === 0 ? null : a.multiple ? d.value.slice() : Array.isArray(d.value) ? d.value[0] : d.value;
    U(d, () => {
      u.value || o("valueChanged", { name: a.name, value: b() });
    }), U(u, (h) => {
      h || o("valueChanged", { name: a.name, value: b() });
    });
    const _ = (h) => {
      u.value = !0, h != null ? d.value = Array.isArray(h) ? h : [h] : a.multiple ? d.value = [] : d.value = null, u.value = !1;
    }, { hiddenValues: g, disabledValues: y } = tt(a.name, R);
    return l({
      /**
       * Gets the current value 
       */
      getValue: b,
      /**
       * Sets the current value
       * 
       * @param value any|any[]|null
       * @returns void
       */
      setValue: _
    }), (h, v) => (r(), B(p(W), {
      tag: "div",
      is_loading: a.is_loading,
      class: N({ select: !0, "is-multiple": a.multiple })
    }, {
      default: w(() => [
        m.value != null ? (r(), B(be, {
          key: 0,
          promise: m.value
        }, {
          default: w(({ response: J }) => [
            F(p(W), {
              tag: "select",
              is_loading: a.is_loading,
              id: a.inputId,
              name: a.name,
              multiple: a.multiple,
              class: N(a.multiple ? "is-multiple" : ""),
              modelValue: d.value,
              "onUpdate:modelValue": v[0] || (v[0] = (M) => d.value = M),
              disabled: a.disabled
            }, {
              default: w(() => [
                J != null ? (r(!0), c(z, { key: 0 }, j(J, (M) => (r(), c(z, null, [
                  M.values === void 0 ? le((r(), c("option", {
                    key: 0,
                    value: M.value,
                    selected: M.selected,
                    disabled: p(y).some((E) => E === M.value.toString())
                  }, x(p(i)(M.label)), 9, Oo)), [
                    [oe, !p(g).some((E) => E === M.value.toString())]
                  ]) : O("", !0),
                  M.values !== void 0 ? le((r(), c("optgroup", {
                    key: 1,
                    label: p(i)(M.label),
                    disabled: p(y).some((E) => E === M.value.toString())
                  }, [
                    (r(!0), c(z, null, j(M.values, (E) => le((r(), c("option", {
                      value: E.value,
                      selected: E.selected,
                      disabled: p(y).some((X) => X === E.value.toString())
                    }, x(p(i)(E.label)), 9, No)), [
                      [oe, !p(g).some((X) => X === E.value.toString())]
                    ])), 256))
                  ], 8, Jo)), [
                    [oe, !p(g).some((E) => E === M.value.toString())]
                  ]) : O("", !0)
                ], 64))), 256)) : O("", !0)
              ]),
              _: 2
            }, 1032, ["is_loading", "id", "name", "multiple", "class", "modelValue", "disabled"])
          ]),
          rejected: w(() => [
            F(p(ge), {
              type: p(ue).danger,
              message: s.value
            }, null, 8, ["type", "message"])
          ]),
          _: 1
        }, 8, ["promise"])) : O("", !0)
      ]),
      _: 1
    }, 8, ["is_loading", "class"]));
  }
}), wo = {
  key: 0,
  class: "help is-danger"
}, ea = /* @__PURE__ */ D({
  __name: "switch",
  props: {
    label: {},
    required: { type: Boolean },
    inputId: {},
    is_loading: { type: [Object, Boolean] },
    name: {},
    disabled: { type: Boolean },
    translate: { type: Function }
  },
  emits: ["valueChanged"],
  setup(e, { expose: l, emit: t }) {
    const a = e, n = t, s = pe(a, R), o = C(!1);
    return U(o, (u) => n("valueChanged", { name: a.name, value: u })), l({
      /**
       * Gets the current value 
       */
      getValue: () => o.value,
      /**
       * Sets the current value
       * 
       * @param value boolean
       * @returns void
       */
      setValue: (u) => {
        o.value = u;
      }
    }), (u, m) => (r(), B(p(W), {
      tag: "div",
      is_loading: a.is_loading,
      class: "field"
    }, {
      default: w(() => [
        F(p(W), {
          tag: "input",
          is_loading: a.is_loading,
          type: "checkbox",
          class: "switch is-rounded",
          id: a.inputId,
          name: a.name,
          modelValue: o.value,
          "onUpdate:modelValue": m[0] || (m[0] = (b) => o.value = b),
          disabled: a.disabled
        }, null, 8, ["is_loading", "id", "name", "modelValue", "disabled"]),
        F(p(W), {
          tag: "label",
          is_loading: a.is_loading,
          class: "label",
          for: u.$props.inputId
        }, {
          default: w(() => [
            G(x(p(s)(a.label)) + " ", 1),
            a.required ? (r(), c("span", wo, "*")) : O("", !0)
          ]),
          _: 1
        }, 8, ["is_loading", "for"])
      ]),
      _: 1
    }, 8, ["is_loading"]));
  }
}), ta = /* @__PURE__ */ D({
  __name: "text",
  props: {
    subtype: { default: "text" },
    maxlength: {},
    inputId: {},
    is_loading: { type: [Object, Boolean] },
    name: {},
    disabled: { type: Boolean }
  },
  emits: ["valueChanged"],
  setup(e, { expose: l, emit: t }) {
    const a = e, n = t, s = C(null);
    return U(s, (d) => n("valueChanged", { name: a.name, value: d })), l({
      /**
       * Gets the current value 
       */
      getValue: () => s.value,
      /**
       * Sets the current value
       * 
       * @param value any|null
       * @returns void
       */
      setValue: (d) => {
        s.value = d;
      }
    }), (d, u) => (r(), B(p(W), {
      tag: "input",
      is_loading: a.is_loading,
      id: a.inputId,
      type: e.subtype,
      class: "input",
      name: e.name,
      disabled: e.disabled,
      maxlength: a.maxlength,
      modelValue: s.value,
      "onUpdate:modelValue": u[0] || (u[0] = (m) => s.value = m)
    }, null, 8, ["is_loading", "id", "type", "name", "disabled", "maxlength", "modelValue"]));
  }
}), aa = 9, Me = String.fromCharCode(aa), Ne = `
`, la = /* @__PURE__ */ D({
  __name: "textarea",
  props: {
    maxlength: {},
    rows: {},
    cols: {},
    supportsTab: { type: Boolean },
    inputId: {},
    is_loading: { type: [Object, Boolean] },
    name: {},
    disabled: { type: Boolean }
  },
  emits: ["valueChanged"],
  setup(e, { expose: l, emit: t }) {
    const a = e, n = t, s = C(null);
    U(s, (u) => {
      n("valueChanged", { name: a.name, value: u });
    });
    const o = () => s.value, i = (u) => {
      s.value = u;
    };
    l({
      /**
       * Gets the current value 
       */
      getValue: o,
      /**
       * Sets the current value
       * 
       * @param value string|null
       * @returns void
       */
      setValue: i
    });
    const d = (u) => {
      if (a.supportsTab) {
        let m = o();
        if (m !== null)
          switch (u.keyCode) {
            case aa:
              let b = u.selectionStart ?? u.target.selectionStart, _ = u.selectionEnd ?? u.target.selectionEnd, g = m.substring(0, b), y = m.length > _ ? m.substring(_) : "", h = b === _ ? "" : m.substring(b, _);
              if (h.indexOf(`
`) < 0)
                u.shiftKey ? h.startsWith(Me) ? (h = h.substring(1), b--) : g.endsWith(Me) && (g = g.substring(0, g.length - 1), b--) : h = Me + h;
              else {
                let v = !1;
                h.endsWith(Ne) && (v = !0, h = h.substring(0, h.length - 1));
                let J = h.split(Ne);
                h = "", u.shiftKey && g.endsWith(Me) && (g = g.substring(0, g.length - 1), b--), J.forEach((M, E) => {
                  u.shiftKey && M.startsWith(Me) ? M = M.substring(1) : u.shiftKey || (M = Me + M), h += M + (E === J.length - 1 ? "" : Ne);
                }), v && (h += Ne);
              }
              return m = g + h + y, b += h.length == 1 ? 1 : 0, _ = b + (h.length == 1 ? 0 : h.length), i(m), u.target.selectionStart = b, u.target.selectionEnd = _, u.target.focus(), u.preventDefault != null && u.preventDefault(), !1;
            default:
              return !0;
          }
      }
      return !0;
    };
    return (u, m) => (r(), B(p(W), {
      tag: "textarea",
      is_loading: a.is_loading,
      class: "textarea",
      id: a.inputId,
      name: a.name,
      rows: a.rows,
      cols: a.cols,
      maxlength: a.maxlength,
      disabled: a.disabled,
      onKeydown: d,
      modelValue: s.value,
      "onUpdate:modelValue": m[0] || (m[0] = (b) => s.value = b)
    }, null, 8, ["is_loading", "id", "name", "rows", "cols", "maxlength", "disabled", "modelValue"]));
  }
}), Fo = (e) => {
  let l = ae.twelve;
  if (e !== void 0)
    switch (e) {
      case 1:
        l = ae.one;
        break;
      case 2:
        l = ae.two;
        break;
      case 3:
        l = ae.three;
        break;
      case 4:
        l = ae.four;
        break;
      case 5:
        l = ae.five;
        break;
      case 6:
        l = ae.six;
        break;
      case 7:
        l = ae.seven;
        break;
      case 8:
        l = ae.eight;
        break;
      case 9:
        l = ae.nine;
        break;
      case 10:
        l = ae.ten;
        break;
      case 11:
        l = ae.eleven;
        break;
      default:
        l = ae.twelve;
        break;
    }
  return l;
}, na = /* @__PURE__ */ D({
  __name: "inputs-collection",
  props: {
    fields: {},
    disabled: { type: Boolean },
    is_loading: { type: [Object, Boolean] }
  },
  emits: ["valueChanged", "buttonClicked"],
  setup(e, { expose: l, emit: t }) {
    const a = (g) => ({
      size: Fo(g.form_columns)
    }), n = e, s = t;
    let o = [];
    const i = f(() => {
      let g = [], y = [], h = 0;
      return o = n.fields.map((v, J) => C(null)), n.fields.forEach((v, J) => {
        let M = v.form_columns ?? 12;
        h + M > 12 && (g.push(y), y = [], h = 0), y.push({ ...v, refIndex: J }), h += M, h === 12 && (g.push(y), y = [], h = 0);
      }), y.length > 0 && g.push(y), g;
    }), d = R(Ee), u = R(et);
    return l({
      /**
       * Called to set the value for a component in the row
       * 
       * @param value any
       */
      setValue: (g) => {
        o.forEach((y, h) => {
          switch (n.fields[h].type) {
            case "subform":
              y.value.setValue(g);
              break;
            default:
              y.value.setValue !== void 0 && (g === null ? y.value.setValue(null) : Object.keys(g).some((v) => v === y.value.fieldName) ? y.value.setValue(g[y.value.fieldName]) : Object.keys(g).some((v) => v === y.value.altFieldName) && y.value.setValue(g[y.value.altFieldName]));
              break;
          }
        });
      },
      /**
       * Called to get the value of the components in this row.
       * Returns an object where the propertyName are the names of the fields in the subform.
       */
      getValue: () => {
        var g = {};
        return o.forEach((y) => {
          if (y.value.getValue != null)
            switch (y.value.type) {
              case "subform":
                g = Object.assign(g, y.value.getValue());
                break;
              default:
                g[y.value.fieldName] = y.value.getValue();
                break;
            }
        }), g;
      },
      /**
       * Called to see if all the copmonents in this row are valid.
       */
      isValid: () => !o.some((g) => !(g.value.isValid === void 0 || g.value.isValid()))
    }), (g, y) => (r(), c("section", null, [
      (r(!0), c(z, null, j(i.value, (h) => (r(), B(nt, {
        modifiers: [p(He).gapless],
        columns: h.map((v) => a(v))
      }, Te({ _: 2 }, [
        j(h.map((v, J) => ({ input: v, index: J })).filter((v) => !p(d).some((J) => J === v.input.name)), (v) => ({
          name: `col-${v.index}`,
          fn: w(() => [
            F(oa, {
              ref_for: !0,
              ref: (J) => p(o)[v.input.refIndex].value = J,
              input: v.input,
              onValueChanged: y[0] || (y[0] = (J) => s("valueChanged", J)),
              onButtonClicked: y[1] || (y[1] = (J) => s("buttonClicked", J)),
              disabled: (n.disabled ?? !1) || p(u).some((J) => J === v.input.name),
              is_loading: n.is_loading
            }, null, 8, ["input", "disabled", "is_loading"])
          ])
        }))
      ]), 1032, ["modifiers", "columns"]))), 256))
    ]));
  }
}), Bo = /* @__PURE__ */ D({
  __name: "subform",
  props: {
    fields: {},
    inputId: {},
    is_loading: { type: [Object, Boolean] },
    name: {},
    disabled: { type: Boolean, default: !1 }
  },
  emits: ["valueChanged", "buttonClicked"],
  setup(e, { expose: l, emit: t }) {
    const a = e, n = t, s = C(null), o = R(Ee, fe(C([]))), i = f(() => o ? o.value.some((b) => b === a.name) : !1);
    return l({
      /**
       * Called to set the value of 1 or more copmonents inside this sub form
       * 
       * @param value any
       */
      setValue: (b) => {
        s.value !== null && s.value.setValue(b);
      },
      /**
       * Called to get the value of this of all the components inside this subform.  
       * Returns an object where each propertyName is the name of the field and it's value is the value.
       */
      getValue: () => s.value === null ? null : s.value.getValue(),
      /**
       * Called to see if this sub form is valid.  It returns the result of true if all the components return true from their isValid calls
       */
      isValid: () => s.value === null ? !1 : s.value.isValid()
    }), (b, _) => le((r(), B(Lt, {
      id: a.name,
      name: a.name
    }, {
      default: w(() => [
        F(na, {
          fields: a.fields,
          ref_key: "inputs",
          ref: s,
          disabled: a.disabled,
          is_loading: a.is_loading,
          onValueChanged: _[0] || (_[0] = (g) => n("valueChanged", g)),
          onButtonClicked: _[1] || (_[1] = (g) => n("buttonClicked", g))
        }, null, 8, ["fields", "disabled", "is_loading"])
      ]),
      _: 1
    }, 8, ["id", "name"])), [
      [oe, !i.value]
    ]);
  }
});
var I = /* @__PURE__ */ ((e) => (e.autocomplete = "autocomplete", e.button = "button", e.checkbox_group = "checkbox-group", e.checkbox = "checkbox", e.date = "date", e.full_editor = "full-editor", e.header = "header", e.hidden = "hidden", e.number = "number", e.paragraph = "paragraph", e.radio_group = "radio-group", e.select = "select", e.subform = "subform", e.switch = "switch", e.text = "text", e.textarea = "textarea", e.time = "time", e))(I || {});
const xo = {
  key: 0,
  class: "is-required-marker"
}, To = [I.autocomplete, I.checkbox_group, I.date, I.number, I.radio_group, I.select, I.text, I.textarea, I.time, I.subform], Po = [I.subform, I.switch, I.select, I.radio_group, I.paragraph, I.header, I.checkbox_group, I.checkbox, I.button, I.autocomplete], oa = /* @__PURE__ */ D({
  __name: "form-component",
  props: {
    input: {},
    disabled: { type: Boolean, default: !1 },
    is_loading: { type: [Object, Boolean], default: void 0 },
    translate: {}
  },
  emits: ["valueChanged", "buttonClicked"],
  setup(e, { expose: l, emit: t }) {
    const a = C(null), n = pa(), s = t, o = e, i = pe(o, R), d = fe(C(o.input.type)), u = f(() => {
      let k = null;
      switch (o.input.type) {
        case I.autocomplete:
          k = Wt;
          break;
        case I.button:
          k = je;
          break;
        case I.checkbox_group:
          k = jt;
          break;
        case I.checkbox:
          k = Vt;
          break;
        case I.date:
          k = Ht;
          break;
        case I.full_editor:
          k = Kt;
          break;
        case I.header:
          k = Ve;
          break;
        case I.hidden:
          k = Yt;
          break;
        case I.number:
          k = qt;
          break;
        case I.paragraph:
          k = Le;
          break;
        case I.radio_group:
          k = Zt;
          break;
        case I.select:
          k = Xt;
          break;
        case I.switch:
          k = ea;
          break;
        case I.text:
          k = ta;
          break;
        case I.textarea:
          k = la;
          break;
        case I.time:
          k = lt;
          break;
        case I.subform:
          k = Bo;
          break;
      }
      return k;
    }), m = function(k) {
      a.value !== null && a.value.setValue !== void 0 && a.value.setValue(k);
    };
    de(() => {
      a.value !== null && o.input.value !== void 0 && o.input.value !== null && m(o.input.value);
    });
    const b = f(() => o.input.disabled ?? o.disabled ?? !1), _ = f(() => o.input.name), g = f(() => o.input.name), y = f(() => To.some((k) => k === o.input.type) && o.input.label !== void 0 && o.input.label !== null), h = f(() => {
      let k = Object.assign({}, o.input ?? {});
      if (delete k.type, y.value && delete k.label, k.className != null && delete k.className, k.form_columns != null && delete k.form_columns, Po.some((q) => q === o.input.type) && (k.translate = o.translate), k.disabled = o.disabled, k.is_loading = o.is_loading, k.additional !== void 0) {
        for (const q in k.additional)
          k[q] = k.additional[q];
        delete k.additional;
      }
      return k.inputId = n, k;
    }), v = (k) => {
      if (k.value !== void 0 && k.value !== null && Array.isArray(k.value)) {
        let q = [...k.value];
        k.value = q;
      }
      s("valueChanged", k);
    }, J = (k) => {
      s("buttonClicked", k);
    }, M = () => {
      if (a.value != null && a.value.getValue != null) {
        let k = a.value.getValue();
        return k != null && Array.isArray(k) ? [...k] : k;
      }
      return null;
    };
    return l({
      /**
       * Called to set the value for this given form component
       * 
       * @param value any
       */
      setValue: m,
      /**
       * Property that returns the name of this given component
       */
      fieldName: _,
      /**
       * Property that returns the type of form component this is
       */
      type: d,
      /**
       * Property that returns the alternative field name for this component
       */
      altFieldName: g,
      /**
       * Called to get the value of this component.
       * If this is a basic component, it returns that value.
       * If this is a subform it will return an object where the propertyName are the names of the fields in the subform.
       */
      getValue: M,
      /**
       * Called to see if this component is valid.
       * If this is a basic component, it ensures it has a value if required.
       * If this is a subform it returns the result from the subform isValid call.
       */
      isValid: () => {
        if (o.input.type === "subform" && a.value !== null)
          return a.value.isValid();
        if (o.input.required ?? !1) {
          let k = M();
          return k != null && (Array.isArray(k) ? k.length > 0 : !0) && k.toString() !== "";
        }
        return !0;
      },
      /**
       * Called to set the values of a subform component, this will throw an error if this component is not a subform.
       * 
       * @param values any|null
       */
      setValues: (k) => {
        if (o.input.type === "subform" && a.value !== null)
          a.value.setValues(k);
        else
          throw "unable to call set values on any form element except a subform";
      }
    }), (k, q) => o.input.type === p(I).header ? (r(), B(Ve, {
      key: 0,
      subtype: o.input.subtype,
      label: o.input.label,
      is_loading: o.is_loading,
      ref_key: "inp",
      ref: a
    }, null, 8, ["subtype", "label", "is_loading"])) : o.input.type === p(I).paragraph ? (r(), B(Le, {
      key: 1,
      name: o.input.name,
      label: o.input.label,
      "input-id": p(n),
      is_loading: o.is_loading,
      ref_key: "inp",
      ref: a
    }, null, 8, ["name", "label", "input-id", "is_loading"])) : o.input.type === p(I).button ? (r(), B(p(W), {
      key: 2,
      tag: "div",
      is_loading: o.is_loading,
      class: "field"
    }, {
      default: w(() => [
        F(p(W), {
          tag: "div",
          is_loading: o.is_loading,
          class: "control"
        }, {
          default: w(() => [
            F(je, Y(h.value, {
              disabled: b.value,
              onButtonClicked: J,
              ref_key: "inp",
              ref: a
            }), null, 16, ["disabled"])
          ]),
          _: 1
        }, 8, ["is_loading"])
      ]),
      _: 1
    }, 8, ["is_loading"])) : (r(), B(p(W), {
      key: 3,
      tag: "div",
      is_loading: o.is_loading,
      class: "field"
    }, {
      default: w(() => [
        y.value ? (r(), B(p(W), {
          key: 0,
          tag: "label",
          is_loading: o.is_loading,
          class: "label",
          for: p(n)
        }, {
          default: w(() => [
            G(x(p(i)(o.input.label ?? "")) + " ", 1),
            o.input.required ? (r(), c("span", xo, "*")) : O("", !0)
          ]),
          _: 1
        }, 8, ["is_loading", "for"])) : O("", !0),
        F(p(W), {
          tag: "div",
          is_loading: o.is_loading,
          class: "control"
        }, {
          default: w(() => [
            (r(), B(he(u.value), Y(h.value, {
              onValueChanged: v,
              ref_key: "inp",
              ref: a
            }), null, 16))
          ]),
          _: 1
        }, 8, ["is_loading"])
      ]),
      _: 1
    }, 8, ["is_loading"]));
  }
}), Co = {
  onsubmit: "return false;",
  class: "container is-fullhd"
}, Eo = /* @__PURE__ */ D({
  __name: "component-form",
  props: {
    elements: {},
    disabled: { type: Boolean, default: !1 },
    is_loading: { type: [Object, Boolean], default: void 0 },
    translate: {}
  },
  emits: ["valueChanged", "buttonClicked"],
  setup(e, { expose: l, emit: t }) {
    const a = e, n = t, s = pe(a, R);
    Re("Translate", (v) => s.value(v));
    const o = C(null), i = () => o.value !== null ? o.value.getValue() : null, d = (v) => {
      o.value !== null && o.value.setValue(v);
    }, u = () => o.value !== null ? o.value.isValid() : !1, m = C([]);
    Re(Ee, fe(m));
    const b = (v) => {
      Array.isArray(v) ? m.value = [...m.value, ...v] : m.value.push(v);
    }, _ = (v) => {
      Array.isArray(v) ? m.value = m.value.filter((J) => v.indexOf(J) >= 0) : m.value = m.value.filter((J) => J !== v);
    }, g = C([]);
    return Re(et, fe(g)), l({
      /**
       * Returns the values of the given form elements as an object where the property name is the name of the form element and the property value is 
       * that elements value
       */
      getValues: i,
      /**
       * Called to set the values on the form elements using an object where the property name is the name of the form element
       * 
       * @param values any
       */
      setValues: d,
      /**
       * Called to see if the form is valid.  Returns a boolean value that is true if all required fields have a value.
       */
      isValid: u,
      /**
       * Called to hide 1 or more fields in the form
       * 
       * @param name string|string[]
       */
      hideField: b,
      /**
       * Called to show 1 or more hidden fields in the form
       * 
       * @param name string|string[]
       */
      showField: _,
      /**
       * Called to disable 1 or more fields in the form
       * 
       * @param name string|string[]
       */
      disableField: (v) => {
        Array.isArray(v) ? g.value = [...g.value, ...v] : g.value.push(v);
      },
      /**
       * Called to enable 1 or more disabled fields in the form
       * 
       * @param name string|string[]
       */
      enableField: (v) => {
        Array.isArray(v) ? g.value = g.value.filter((J) => v.indexOf(J) >= 0) : g.value = g.value.filter((J) => J !== v);
      }
    }), (v, J) => (r(), c("form", Co, [
      F(na, {
        fields: a.elements,
        ref_key: "inputs",
        ref: o,
        disabled: a.disabled,
        is_loading: a.is_loading,
        onValueChanged: J[0] || (J[0] = (M) => n("valueChanged", M)),
        onButtonClicked: J[1] || (J[1] = (M) => n("buttonClicked", M))
      }, null, 8, ["fields", "disabled", "is_loading"])
    ]));
  }
}), zo = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  AutoComplete: Wt,
  Button: je,
  Checkbox: Vt,
  CheckboxGroup: jt,
  ComponentForm: Eo,
  DateField: Ht,
  FormComponent: oa,
  FullEditor: Kt,
  Header: Ve,
  Hidden: Yt,
  NumberField: qt,
  Paragraph: Le,
  RadioGroup: Zt,
  Select: Xt,
  Switch: ea,
  Text: ta,
  TextArea: la,
  Time: lt
}, Symbol.toStringTag, { value: "Module" })), pt = document.currentScript === null || document.currentScript === void 0 ? import.meta.url : document.currentScript.src;
Pe(`${pt.substring(0, pt.lastIndexOf("/"))}/vibrantvue.min.css`);
const Ro = Object.values(Qe).filter((e, l, t) => t.indexOf(e) === l), Io = (e) => {
  document.getElementsByTagName("html")[0].setAttribute("data-theme", `${e || ""}`);
}, Wo = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  AVAIABLE_SKINS: Ro,
  setSkin: Io
}, Symbol.toStringTag, { value: "Module" })), jo = /* @__PURE__ */ D({
  __name: "chart",
  props: {
    labels: {},
    datasets: {},
    type: {},
    title: {},
    show_refresh: { type: Boolean },
    width: {},
    height: {},
    legend_position: { default: Ge.right },
    scales: {},
    tooltips: {}
  },
  emits: ["legendItemClick"],
  setup(e, { emit: l }) {
    const t = `${_a(R)}chart.umd.min.js`, a = C(null), n = e, s = l;
    let o = null;
    const i = () => {
      o?.update();
    }, d = f(() => {
      var u = "";
      return n.width && (u = `width:${n.width}px;`), n.height && (u += `height:${n.height}px;`), u;
    });
    return U(() => n.type, (u) => {
      o != null && (o.type = u ?? "line");
    }), U(
      () => n.labels,
      (u) => {
        o != null && (o.data.labels = u, (n.show_refresh == null || !n.show_refresh) && i());
      },
      { deep: !0 }
    ), U(
      () => n.datasets,
      (u) => {
        o != null && (o.data.datasets = u, (n.show_refresh == null || !n.show_refresh) && i());
      },
      { deep: !0 }
    ), de(async () => {
      let u = {
        responsive: !0,
        animation: {
          duration: 100
        },
        plugins: {
          legend: {
            position: `${n.legend_position}`,
            labels: {
              filter: (b, _) => b.text != null
            },
            onClick: function(b, _) {
              s("legendItemClick", o, _);
            }
          }
        }
      };
      n.scales != null && n.scales != null && (u.scales = n.scales), n.tooltips != null && n.tooltips != null && (u.tooltips = n.tooltips);
      const { Chart: m } = await Ue(t, ["Chart"]);
      o = new m(a.value.getContext("2d"), {
        type: n.type == null ? "line" : n.type,
        data: {
          datasets: n.datasets,
          labels: n.labels
        },
        options: u
      }), o.update();
    }), (u, m) => (r(), B(Ut, null, Te({
      content: w(() => [
        A("canvas", {
          ref_key: "canvas",
          ref: a,
          style: Ae(d.value)
        }, null, 4)
      ]),
      _: 2
    }, [
      n.title ? {
        name: "header",
        fn: w((b) => [
          A("h3", {
            class: N(b.header_class)
          }, x(n.title), 3)
        ]),
        key: "0"
      } : void 0,
      n.show_refresh != null && n.show_refresh != null && n.show_refresh ? {
        name: "footer",
        fn: w((b) => [
          F(Pt, {
            class: N(b.addon_class),
            onClick: i
          }, null, 8, ["class"])
        ]),
        key: "1"
      } : void 0
    ]), 1024));
  }
}), Vo = /* @__PURE__ */ D({
  __name: "code-writer",
  props: {
    language: {},
    autocompletes: {},
    readonly: { type: Boolean, default: !1 },
    value: { default: "" }
  },
  emits: ["valueChanged"],
  setup(e, { expose: l, emit: t }) {
    const a = `${ka(R)}src-noconflict/ace.js`, n = e, s = t, o = C(null), i = C(null), d = function() {
      return i.value.getValue() == "" ? null : i.value.getValue();
    }, u = function(b) {
      i.value.setValue(b ?? "");
    };
    U(() => n.readonly, (b) => {
      i.value.setReadOnly(b == null || b == null ? !1 : b);
    }), U(() => n.value, (b) => {
      u(b);
    }), U(() => n.language, (b) => {
      i.value.getSession().setMode(b);
    });
    const m = f(() => {
      let b = Number.MAX_SAFE_INTEGER;
      if (n.autocompletes != null && n.autocompletes != null) {
        for (let _ = 0; _ < n.autocompletes.length; _++)
          n.autocompletes[_].method.indexOf(".") >= 0 ? b = Math.min(b, n.autocompletes[_].method.indexOf(".")) : b = Math.min(b, n.autocompletes[_].method.length);
        if (b > 3 && n.autocompletes.length > 0) {
          let _ = !0, g = n.autocompletes[0].method.substring(0, 3);
          for (let y = 0; y < n.autocompletes.length; y++)
            if (n.autocompletes[y].method.substring(0, 3) != g) {
              _ = !1;
              break;
            }
          _ && (b = 3);
        }
      }
      return b;
    });
    return l({
      /**
       * Gets the current value 
       */
      getValue: d,
      /**
       * Sets the current value
       * 
       * @param value string|null
       */
      setValue: u
    }), de(async () => {
      const { ace: b } = await Ue(a, ["ace"]);
      i.value = ma(b.edit(o.value.$el, {
        mode: n.language,
        selectionStyle: "text",
        minLines: 20,
        maxLines: 50,
        enableBasicAutocompletion: !0
      })), i.value.setReadOnly(n.readonly === void 0 || n.readonly === null ? !1 : n.readonly), n.value !== null && n.value !== void 0 && i.value.setValue(n.value), i.value.on("change", () => s("valueChanged", d())), n.autocompletes !== null && n.autocompletes !== void 0 && (i.value.setOptions({
        enableBasicAutocompletion: !0,
        enableLiveAutocompletion: !0
      }), i.value.completers = [{
        identifierRegexps: [/[a-zA-Z0-9_\.]+/],
        getCompletions: function(_, g, y, h, v) {
          var J = [];
          if (h = h.toUpperCase(), h.length >= m && (J = n.autocompletes.filter((M) => M.method.toUpperCase().startsWith(h) && M.method.length > h.legend).map((M) => ({
            caption: M.method + (M.description === null || M.description === void 0 ? "" : "->" + M.description),
            value: M.method,
            meta: "autos"
          }))), J.length === 0) {
            v(null, []);
            return;
          }
          v(null, J.map(function(M) {
            return M;
          }));
        }
      }]);
    }), (b, _) => (r(), c("div", {
      class: "editor",
      ref_key: "container",
      ref: o
    }, null, 512));
  }
}), Lo = { key: 0 }, Uo = { colspan: "100%" }, Go = ["colspan", "rowspan"], Ho = ["onClick"], Ko = { class: "icon" }, Yo = { key: 0 }, qo = { colspan: "100%" }, Zo = ["colspan", "rowspan", "onClick"], Qo = { key: 1 }, Xo = { colspan: "100%" }, es = /* @__PURE__ */ D({
  __name: "grid",
  props: {
    columns: {},
    data: {},
    empty_message: {},
    column_rows: {},
    has_filter: { type: Boolean },
    filter_min_length: {},
    current_sort: {},
    is_loading: {},
    getRowColor: {},
    scrollable: { type: Boolean },
    fixed_header: { type: Boolean },
    full_width: { type: Boolean },
    narrow: { type: Boolean },
    use_next: { type: Boolean, default: !0 },
    has_more: { type: Boolean, default: void 0 },
    has_previous: { type: Boolean, default: void 0 },
    size: { default: H.small },
    rounded: { type: Boolean, default: !1 },
    button_type: {},
    total_pages: {},
    current_page: {},
    zero_page_index: { type: Boolean }
  },
  emits: ["moveForward", "moveBack", "goToPage", "cellClicked", "sort", "filter"],
  setup(e, { emit: l }) {
    const t = ce(), a = e, n = l, s = {
      scrollable: a.scrollable,
      fixed_header: a.fixed_header,
      full_width: a.full_width,
      narrow: a.narrow
    }, o = {
      use_next: a.use_next,
      has_more: a.has_more,
      has_previous: a.has_previous,
      size: a.size,
      rounded: a.rounded,
      button_type: a.button_type,
      total_pages: a.total_pages,
      current_page: a.current_page
    }, i = f(() => !!(a.has_previous || a.has_more || a.current_page !== void 0 && a.total_pages !== void 0 && ie(a.total_pages) > 1)), d = f(() => a.column_rows === void 0 || a.column_rows.length === 0 ? a.columns : a.column_rows.map((g) => g.map((y) => a.columns.filter((h) => h.some((v) => v.id === y))[0].find((h) => h.id === y)))), u = f(
      () => d.value.filter((g) => g.some((y) => !(y.headerOnly ?? !1)))
    ), m = (g) => {
      a.current_sort !== void 0 && a.current_sort !== null && a.current_sort.column === g ? n("sort", {
        column: g,
        ascending: !a.current_sort.ascending
      }) : n("sort", {
        column: g,
        ascending: !0
      });
    }, b = (g, y) => {
      if (a.getRowColor) {
        let h = a.getRowColor(g, y);
        if (h)
          return `is-${h}`;
      }
      return null;
    }, _ = (g, y, h, v) => {
      let J = [];
      if ((y.cellClass || y.getCellColor) && (y.cellClass && J.push(`${y.cellClass}`), y.getCellColor)) {
        let M = y.getCellColor(g, h, v);
        M && J.push(`is-${M}`);
      }
      return J;
    };
    return (g, y) => (r(), B(ot, me(_e(s)), Te({
      thead: w(() => [
        a.has_filter ?? !1 ? (r(), c("tr", Lo, [
          A("th", Uo, [
            F(Ct, {
              min_length: a.filter_min_length,
              onFilter: y[0] || (y[0] = (h) => n("filter", h))
            }, null, 8, ["min_length"])
          ])
        ])) : O("", !0),
        (r(!0), c(z, null, j(a.columns, (h) => (r(), c("tr", null, [
          (r(!0), c(z, null, j(h, (v) => (r(), c("th", {
            colspan: v.headerColspan,
            rowspan: v.headerRowspan,
            class: N(v.headerClass)
          }, [
            T(g.$slots, `head-${v.id}`, {}, () => [
              a.current_sort !== void 0 && a.current_sort !== null && (v.canSort ?? !1) && v.id === a.current_sort.column ? (r(), c("span", {
                key: 0,
                class: "icon-text is-clickable",
                onClick: (J) => m(v.id)
              }, [
                A("span", Ko, [
                  F(K, {
                    icon: a.current_sort.ascending ? "arrow-up" : "arrow-down"
                  }, null, 8, ["icon"])
                ]),
                A("span", null, x(v.title), 1)
              ], 8, Ho)) : (r(), c(z, { key: 1 }, [
                G(x(v.title), 1)
              ], 64))
            ])
          ], 10, Go))), 256))
        ]))), 256))
      ]),
      tbody: w(() => [
        a.data === null || a.is_loading || a.data.length === 0 ? (r(), c("tr", Yo, [
          A("td", qo, [
            a.data === null || a.is_loading ? (r(), B(ke, { key: 0 })) : (r(), B(ge, {
              key: 1,
              message: a.empty_message ?? "No data available"
            }, null, 8, ["message"]))
          ])
        ])) : (r(!0), c(z, { key: 1 }, j(a.data, (h, v) => (r(), c(z, null, [
          (r(!0), c(z, null, j(u.value, (J, M) => (r(), c("tr", {
            key: `row-${v}-${M}`,
            class: N(b(v, h))
          }, [
            (r(!0), c(z, null, j(J.filter((E) => !(E.headerOnly ?? !1)), (E) => (r(), c("td", {
              key: `data-${v}-${M}`,
              colspan: E.dataColspan,
              rowspan: E.dataRowspan,
              class: N(_(v, E, h, E.propertyName ? h[E.propertyName] : void 0)),
              onClick: (X) => n("cellClicked", { rowIndex: v, data: E.propertyName ? h[E.propertyName] : null, row: h })
            }, [
              T(g.$slots, `body-${E.id}`, Y({ ref_for: !0 }, { rowIndex: v, data: E.propertyName ? h[E.propertyName] : null, row: h }), () => [
                G(x(E.propertyName ? h[E.propertyName] : null), 1)
              ])
            ], 10, Zo))), 128))
          ], 2))), 128))
        ], 64))), 256))
      ]),
      _: 2
    }, [
      i.value || p(t).tfoot_head || p(t).tfoot_bottom ? {
        name: "tfoot",
        fn: w(() => [
          p(t).tfoot_head ? T(g.$slots, "tfoot_head", { key: 0 }) : O("", !0),
          i.value ? (r(), c("tr", Qo, [
            A("td", Xo, [
              F(Et, Y(o, {
                onMoveForward: y[1] || (y[1] = (h) => n("moveForward")),
                onMoveBack: y[2] || (y[2] = (h) => n("moveBack")),
                onGoToPage: y[3] || (y[3] = (h) => n("goToPage", h))
              }), null, 16)
            ])
          ])) : O("", !0),
          p(t).tfoot_bottom ? T(g.$slots, "tfoot_bottom", { key: 2 }) : O("", !0)
        ]),
        key: "0"
      } : void 0
    ]), 1040));
  }
}), ts = { class: "progress-group" }, as = /* @__PURE__ */ D({
  __name: "progress-group",
  props: {
    size: {},
    values: {},
    max: {}
  },
  setup(e) {
    const l = e, t = f(() => {
      let s = 0;
      for (let o = 0; o < l.values.length; o++)
        s += l.values[o].value;
      return s;
    }), a = f(() => l.values.map((s) => ({
      size: l.size ?? H.normal,
      type: s.type,
      percentage: s.value / (l.max ?? t.value) * 100,
      caption: s.caption ?? `${s.value}`,
      onClick: s.onClick
    }))), n = f(() => l.max !== void 0 ? {
      size: l.size ?? H.normal,
      type: null,
      percentage: (l.max - t.value) / l.max * 100,
      caption: null
    } : null);
    return (s, o) => (r(), c("div", ts, [
      (r(!0), c(z, null, j(a.value, (i, d) => (r(), B(p(Rt), {
        is: "progress",
        class: N(`progress is-${i.size} is-${i.type} ${i.onClick !== void 0 ? "is-clickable" : ""}`),
        key: d,
        text: i.caption ?? "",
        position: p(Ce).bottom,
        style: Ae({ width: `${i.percentage}%` }),
        value: "100",
        max: "100",
        onClick: () => {
          i.onClick !== void 0 && i.onClick();
        }
      }, {
        default: w(() => [
          G(x(`${i.percentage}%`), 1)
        ]),
        _: 2
      }, 1032, ["class", "text", "position", "style", "onClick"]))), 128)),
      n.value != null ? (r(), c("progress", {
        key: 0,
        class: N(`progress is-${n.value.size} is-${n.value.type}`),
        style: Ae({ width: `${n.value.percentage}%` }),
        value: "100",
        max: "100"
      }, x(`${n.value.percentage}%`), 7)) : O("", !0)
    ]));
  }
}), ls = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  Chart: jo,
  CodeWriter: Vo,
  Grid: es,
  ProgressGroup: as
}, Symbol.toStringTag, { value: "Module" })), {
  Animation: ps,
  Button: ms,
  ButtonsContainer: gs,
  ButtonAdd: bs,
  ButtonCancel: hs,
  ButtonDelete: vs,
  ButtonDisable: ys,
  ButtonDownload: fs,
  ButtonEdit: _s,
  ButtonEnable: ks,
  ButtonOkay: Ss,
  ButtonPrint: Ms,
  ButtonRefresh: Ds,
  ButtonSave: $s,
  ButtonSubmit: As,
  ButtonUpload: Os,
  CheckMark: Js,
  DropDown: Ns,
  DynamicSlot: ws,
  Filter: Fs,
  Icon: Bs,
  Image: xs,
  Message: Ts,
  Notification: Ps,
  PageNotification: Cs,
  Pagination: Es,
  Promised: zs,
  Progress: Rs,
  NavBar: Is,
  Menu: Ws,
  MenuLabel: js,
  MenuList: Vs,
  MenuEntry: Ls,
  ToolTip: Us,
  Badge: Gs,
  Tag: Hs,
  Tags: Ks,
  Title: Ys,
  Subtitle: qs
} = Zl, { DraggableItem: Zs, DropZone: Qs, Sortable: Xs } = nn, {
  AutoComplete: er,
  CheckboxGroup: tr,
  Checkbox: ar,
  DateField: lr,
  ComponentForm: nr,
  FullEditor: or,
  Header: sr,
  Hidden: rr,
  NumberField: ir,
  Paragraph: ur,
  RadioGroup: dr,
  Select: cr,
  Switch: pr,
  Text: mr,
  TextArea: gr,
  Time: br,
  FormComponent: hr
} = zo, {
  Banner: vr,
  Box: yr,
  Breadcrumbs: fr,
  Card: _r,
  ColumnContainer: kr,
  Footer: Sr,
  Level: Mr,
  List: Dr,
  Media: $r,
  Modal: Ar,
  ModalCard: Or,
  Panel: Jr,
  Section: Nr,
  Table: wr,
  Tabs: Fr,
  Slideout: Br,
  StepWizard: xr
} = Mo, { AVAIABLE_SKINS: Tr, setSkin: Pr } = Wo, {
  ColorTypes: Cr,
  NoticeTypes: Er,
  Sizes: zr,
  AnimationSpeeds: Rr,
  AnimationTypes: Ir,
  IconSizes: Wr,
  ChartLegendPositions: jr,
  ChartTypes: Vr,
  DropZoneQuadrants: Lr,
  BreadCrumbAlignments: Ur,
  BreadCrumbSeperators: Gr,
  ColumnContainerModifiers: Hr,
  ColumnSizes: Kr,
  ColumnOffsetSizes: Yr,
  BorderTypes: qr,
  TabAlignments: Zr,
  TabStyles: Qr,
  TileSizes: Xr,
  TileTypes: ei,
  FixedNavBarPositions: ti,
  FixedMenuPositions: ai,
  BadgePositions: li,
  ToolTipPositions: ni,
  ToolTipTextAlignments: oi,
  ButtonAlignments: si,
  SectionSizes: ri
} = ba, { loadNonEs6Module: ii } = ga, { Chart: ui, CodeWriter: di, Grid: ci, ProgressGroup: pi } = ls;
export {
  Tr as AVAIABLE_SKINS,
  ps as Animation,
  Rr as AnimationSpeeds,
  Ir as AnimationTypes,
  er as AutoComplete,
  Gs as Badge,
  li as BadgePositions,
  vr as Banner,
  qr as BorderTypes,
  yr as Box,
  Ur as BreadCrumbAlignments,
  Gr as BreadCrumbSeperators,
  fr as Breadcrumbs,
  ms as Button,
  bs as ButtonAdd,
  si as ButtonAlignments,
  hs as ButtonCancel,
  vs as ButtonDelete,
  ys as ButtonDisable,
  fs as ButtonDownload,
  _s as ButtonEdit,
  ks as ButtonEnable,
  Ss as ButtonOkay,
  Ms as ButtonPrint,
  Ds as ButtonRefresh,
  $s as ButtonSave,
  As as ButtonSubmit,
  Os as ButtonUpload,
  gs as ButtonsContainer,
  _r as Card,
  ui as Chart,
  jr as ChartLegendPositions,
  Vr as ChartTypes,
  Js as CheckMark,
  ar as Checkbox,
  tr as CheckboxGroup,
  di as CodeWriter,
  Cr as ColorTypes,
  kr as ColumnContainer,
  Hr as ColumnContainerModifiers,
  Yr as ColumnOffsetSizes,
  Kr as ColumnSizes,
  nr as ComponentForm,
  lr as DateField,
  Zs as DraggableItem,
  Ns as DropDown,
  Qs as DropZone,
  Lr as DropZoneQuadrants,
  ws as DynamicSlot,
  Fs as Filter,
  ai as FixedMenuPositions,
  ti as FixedNavBarPositions,
  Sr as Footer,
  hr as FormComponent,
  or as FullEditor,
  ci as Grid,
  sr as Header,
  rr as Hidden,
  Bs as Icon,
  Wr as IconSizes,
  xs as Image,
  Mr as Level,
  Dr as List,
  $r as Media,
  Ws as Menu,
  Ls as MenuEntry,
  js as MenuLabel,
  Vs as MenuList,
  Ts as Message,
  Ar as Modal,
  Or as ModalCard,
  Is as NavBar,
  Er as NoticeTypes,
  Ps as Notification,
  ir as NumberField,
  Cs as PageNotification,
  Es as Pagination,
  Jr as Panel,
  ur as Paragraph,
  Rs as Progress,
  pi as ProgressGroup,
  zs as Promised,
  dr as RadioGroup,
  Nr as Section,
  ri as SectionSizes,
  cr as Select,
  zr as Sizes,
  Br as Slideout,
  Xs as Sortable,
  xr as StepWizard,
  qs as Subtitle,
  pr as Switch,
  Zr as TabAlignments,
  Qr as TabStyles,
  wr as Table,
  Fr as Tabs,
  Hs as Tag,
  Ks as Tags,
  mr as Text,
  gr as TextArea,
  Xr as TileSizes,
  ei as TileTypes,
  br as Time,
  Ys as Title,
  Us as ToolTip,
  ni as ToolTipPositions,
  oi as ToolTipTextAlignments,
  ii as loadNonEs6Module,
  cs as provideAceJS,
  us as provideAnimation,
  ds as provideChatJS,
  is as provideFontAwesome,
  ss as provideIconSet,
  os as provideLanguage,
  rs as provideSummerNote,
  Pr as setSkin,
  Q as useLanguage
};
//# sourceMappingURL=vibrantvue.esm.js.map
