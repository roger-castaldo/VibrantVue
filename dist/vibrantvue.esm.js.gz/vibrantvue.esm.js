import { computed as k, defineComponent as D, openBlock as o, createBlock as I, Transition as na, withCtx as E, renderSlot as P, createElementBlock as i, normalizeClass as F, inject as z, ref as x, watch as j, createVNode as C, createCommentVNode as A, toDisplayString as T, mergeProps as Y, toValue as oe, createElementVNode as M, unref as g, Fragment as B, renderList as W, resolveDynamicComponent as pe, createTextVNode as q, onMounted as ce, withDirectives as H, vModelText as De, vShow as ne, normalizeProps as me, resolveComponent as mt, useSlots as ie, readonly as ye, vModelCheckbox as je, normalizeStyle as Ae, guardReactiveProps as fe, reactive as ra, createSlots as xe, withAsyncContext as oa, onUnmounted as ua, vModelSelect as ia, vModelDynamic as da, useId as ca, provide as Ie, markRaw as pa } from "vue";
const Ce = (e) => new Promise((l) => {
  let t = [], a = document.head || document.getElementsByTagName("head")[0];
  (Array.isArray(e) ? e : [e]).forEach((s, r) => {
    if (s.toLowerCase().endsWith(".css") || (s += ".css"), document.querySelectorAll('link[server_path="' + s + '"]').length == 0) {
      let d = document.createElement("link"), c = new Promise((u) => {
        d.onload = function() {
          u(s);
        };
      });
      t[r] = c, a.appendChild(d), d.setAttribute("rel", "stylesheet"), d.setAttribute("type", "text/css"), d.setAttribute("server_path", s), d.setAttribute("href", s);
    } else
      t[r] = Promise.resolve(s);
  }), Promise.all(t).then((s) => {
    l(s);
  });
}), ve = [], Ge = (e, l) => new Promise((t) => {
  let a = ve.find((s) => s.path === e);
  if (a != null)
    if (a.result === void 0 && l !== void 0 || a.result === null && l === void 0) {
      let s = setTimeout(() => {
        let r = ve.find((n) => n.path === e);
        r == null ? (clearTimeout(s), t(void 0)) : (r.result !== void 0 && l !== void 0 || r.result === void 0 && l === void 0) && (clearTimeout(s), t(r.result));
      }, 500);
    } else
      t(a.result);
  else {
    ve.push({
      path: e,
      result: l === void 0 ? null : void 0
    });
    let s = document.createElement("script");
    s.onload = () => {
      let n = ve.findIndex((d) => d.path === e);
      if (l === void 0)
        ve[n].result = void 0;
      else {
        let d = {};
        l.forEach((c) => {
          d[c] = window[c];
        }), ve[n].result = d;
      }
      t(ve[n].result);
    }, s.setAttribute("src", e), (document.head || document.getElementsByTagName("head")[0]).appendChild(s);
  }
}), ht = () => {
  var t;
  let e, l = "";
  return typeof self.crypto < "u" && (e = self.crypto, l = (t = e.randomUUID) == null ? void 0 : t.call(e)), l || "";
}, ma = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  css: Ce,
  generateUUID: ht,
  loadNonEs6Module: Ge
}, Symbol.toStringTag, { value: "Module" }));
var X = /* @__PURE__ */ ((e) => (e.white = "white", e.black = "black", e.light = "light", e.dark = "dark", e.primary = "primary", e.link = "link", e.info = "info", e.success = "success", e.warning = "warning", e.danger = "danger", e))(X || {}), ue = /* @__PURE__ */ ((e) => (e.info = "info", e.success = "success", e.warning = "warning", e.danger = "danger", e))(ue || {}), Z = /* @__PURE__ */ ((e) => (e.small = "small", e.normal = "normal", e.medium = "medium", e.large = "large", e))(Z || {}), ge = /* @__PURE__ */ ((e) => (e.slower = "slower", e.slow = "slow", e.fast = "fast", e.faster = "faster", e))(ge || {}), we = /* @__PURE__ */ ((e) => (e.bounce = "bounce", e.flash = "flash", e.pulse = "pulse", e.rubberBand = "rubberBand", e.shakeX = "shakeX", e.shakeY = "shakeY", e.headShake = "headShake", e.swing = "swing", e.tada = "tada", e.wobble = "wobble", e.jello = "jello", e.heartBeat = "heartBeat", e.backOutDown = "backOutDown", e.backOutLeft = "backOutLeft", e.backOutRight = "backOutRight", e.backOutUp = "backOutUp", e.bounceIn = "bounceIn", e.bounceInDown = "bounceInDown", e.bounceInLeft = "bounceInLeft", e.bounceInRight = "bounceInRight", e.bounceInUp = "bounceInUp", e.bounceOut = "bounceOut", e.boundOutDown = "boundOutDown", e.bounceOutLeft = "bounceOutLeft", e.boundOutRight = "boundOutRight", e.bounceOutUp = "bounceOutUp", e.fadeIn = "fadeIn", e.fadeInDown = "fadeInDown", e.fadeInDownBig = "fadeInDownBig", e.fadeInLeft = "fadeInLeft", e.fadeInLeftBig = "fadeInLeftBig", e.fadeInRight = "fadeInRight", e.fadeInRightBig = "fadeInRightBig", e.fadeInUp = "fadeInUp", e.fadeInUpBig = "fadeInUpBig", e.fadeInTopLeft = "fadeInTopLeft", e.fadeInTopRight = "fadeInTopRight", e.fadeInBottomLeft = "fadeInBottomLeft", e.fadeInBottomRight = "fadeInBottomRight", e.fadeOut = "fadeOut", e.fadeOutDown = "fadeOutDown", e.fadeOutDownBig = "fadeOutDownBig", e.fadeOutLeft = "fadeOutLeft", e.fadeOutLeftBig = "fadeOutLeftBig", e.fadeOutRight = "fadeOutRight", e.fadeOutRightBig = "fadeOutRightBig", e.fadeOutUp = "fadeOutUp", e.fadeOutUpBig = "fadeOutUpBig", e.fadeOutTopLeft = "fadeOutTopLeft", e.fadeOutTopRight = "fadeOutTopRight", e.fadeOutBottomRight = "fadeOutBottomRight", e.fadeOutBottomLeft = "fadeOutBottomLeft", e.flip = "flip", e.flipInX = "flipInX", e.flipInY = "flipInY", e.flipOutX = "flipOutX", e.flipOutY = "flipOutY", e.lightSpeedInRight = "lightSpeedInRight", e.lightSpeedInLeft = "lightSpeedInLeft", e.lightSpeedOutRight = "lightSpeedOutRight", e.lightSpeedOutLeft = "lightSpeedOutLeft", e.rotateIn = "rotateIn", e.rotateInDownLeft = "rotateInDownLeft", e.rotateInDownRight = "rotateInDownRight", e.rotateInUpLeft = "rotateInUpLeft", e.rotateInUpRight = "rotateInUpRight", e.rotateOut = "rotateOut", e.rotateOutDownLeft = "rotateOutDownLeft", e.rotateOutDownRight = "rotateOutDownRight", e.rotateOutUpLeft = "rotateOutUpLeft", e.rotateOutUpRight = "rotateOutUpRight", e.hinge = "hinge", e.jackInTheBox = "jackInTheBox", e.rollIn = "rollIn", e.rollOut = "rollOut", e.zoomIn = "zoomIn", e.zoomInDown = "zoomInDown", e.zoomInLeft = "zoomInLeft", e.zoomInRight = "zoomInRight", e.zoomInUp = "zoomInUp", e.zoomOut = "zoomOut", e.zoomOutDown = "zoomOutDown", e.zoomOutLeft = "zoomOutLeft", e.zoomOutRight = "zoomOutRight", e.zoomOutUp = "zoomOutUp", e.slideInDown = "slideInDown", e.slideInLeft = "slideInLeft", e.slideInRight = "slideInRight", e.slideInUp = "slideInUp", e.slideOutDown = "slideOutDown", e.slideOutLeft = "slideOutLeft", e.slideOutRight = "slideOutRight", e.slideOutUp = "slideOutUp", e))(we || {}), bt = /* @__PURE__ */ ((e) => (e.area = "area", e.bar = "bar", e.bubble = "bubble", e.doughnut = "doughnut", e.pie = "pie", e.line = "line", e.polarArea = "polarArea", e.radar = "radar", e.scatter = "scatter", e))(bt || {}), He = /* @__PURE__ */ ((e) => (e.top = "top", e.left = "left", e.bottom = "bottom", e.right = "right", e.chartArea = "chartArea", e))(He || {}), re = /* @__PURE__ */ ((e) => (e.xxsmall = "2xs", e.xsmall = "xs", e.small = "sm", e.normal = "", e.large = "lg", e.xlarge = "xl", e.xxlarge = "2xl", e))(re || {}), se = /* @__PURE__ */ ((e) => (e.center = "center", e.topLeft = "topLeft", e.bottomLeft = "bottomLeft", e.topRight = "topRight", e.bottomRight = "bottomRight", e.top = "top", e.bottom = "bottom", e))(se || {}), Oe = /* @__PURE__ */ ((e) => (e.centered = "centered", e.right = "right", e.left = "left", e))(Oe || {}), vt = /* @__PURE__ */ ((e) => (e.arrow = "arrow", e.button = "button", e.dot = "dot", e.succeeds = "succeeds", e))(vt || {}), Ke = /* @__PURE__ */ ((e) => (e.mobile = "mobile", e.desktop = "desktop", e.gapless = "gapless", e.multiline = "multiline", e.centered = "centered", e.borderleft = "borderleft", e.borderright = "borderright", e.borderbottom = "borderbottom", e.bordertop = "bordertop", e.fullWidth = "fullwidth", e.fullHeight = "fullheight", e))(Ke || {}), le = /* @__PURE__ */ ((e) => (e.three_quarters = "three-quarters", e.two_thirds = "two-thirds", e.half = "half", e.one_third = "one-third", e.one_quarter = "one-quarter", e.full = "full", e.one_fifth = "one-fifth", e.two_fifths = "two-fifths", e.three_fifths = "three-fifths", e.four_fifths = "four-fifths", e.one = "1", e.two = "2", e.three = "3", e.four = "4", e.five = "5", e.six = "6", e.seven = "7", e.eight = "8", e.nine = "9", e.ten = "10", e.eleven = "11", e.twelve = "12", e.narrow = "narrow", e.wide = "wide", e))(le || {}), gt = /* @__PURE__ */ ((e) => (e.three_quarters = "three-quarters", e.two_thirds = "two-thirds", e.half = "half", e.one_third = "one-third", e.one_quarter = "one-quarter", e.one_fifth = "one-fifth", e.two_fifths = "two-fifths", e.three_fifths = "three-fifths", e.four_fifths = "four-fifths", e.one = "1", e.two = "2", e.three = "3", e.four = "4", e.five = "5", e.six = "6", e.seven = "7", e.eight = "8", e.nine = "9", e.ten = "10", e.eleven = "11", e))(gt || {}), Ye = /* @__PURE__ */ ((e) => (e.left = "left", e.right = "right", e.bottom = "bottom", e.top = "top", e.all = "all", e))(Ye || {}), qe = /* @__PURE__ */ ((e) => (e.centered = "centered", e.right = "right", e.left = "left", e))(qe || {}), yt = /* @__PURE__ */ ((e) => (e.boxed = "boxed", e.toggled = "toggled", e.roundToggle = "roundToggle", e))(yt || {}), ft = /* @__PURE__ */ ((e) => (e.one = "1", e.two = "2", e.three = "3", e.four = "4", e.five = "5", e.six = "6", e.seven = "7", e.eight = "8", e.nine = "9", e.ten = "10", e.eleven = "11", e.twelve = "12", e))(ft || {}), _t = /* @__PURE__ */ ((e) => (e.parent = "parent", e.child = "child", e.ancestor = "ancestor", e))(_t || {}), Te = /* @__PURE__ */ ((e) => (e.top = "is-fixed-top", e.bottom = "is-fixed-bottom", e))(Te || {}), kt = /* @__PURE__ */ ((e) => (e.left = "left", e.right = "right", e))(kt || {}), Ze = /* @__PURE__ */ ((e) => (e.topLeft = "top-left", e.top = "top", e.topRight = "top-right", e.right = "right", e.bottomRight = "bottom-right", e.bottom = "bottom", e.bottomLeft = "bottom-left", e.left = "left", e))(Ze || {}), Be = /* @__PURE__ */ ((e) => (e.left = "left", e.right = "right", e.bottom = "bottom", e.top = "top", e))(Be || {}), Qe = /* @__PURE__ */ ((e) => (e.left = "left", e.centered = "centered", e.right = "right", e))(Qe || {}), St = /* @__PURE__ */ ((e) => (e.centered = "centered", e.right = "right", e.left = "left", e))(St || {}), Xe = /* @__PURE__ */ ((e) => (e.cerulean = "cerulean", e.cosmo = "cosmo", e.cyborg = "cyborg", e.dark = "dark", e.darkly = "darkly", e.default = "default", e.flatly = "flatly", e.journal = "journal", e.light = "light", e.litera = "litera", e.lumen = "lumen", e.lux = "lux", e.materia = "materia", e.minty = "minty", e.morph = "morph", e.pulse = "pulse", e.quartz = "quartz", e.sandstone = "sandstone", e.simplex = "simplex", e.sketchy = "sketchy", e.slate = "slate", e.solar = "solar", e.spacelab = "spacelab", e.superhero = "superhero", e.united = "united", e.vapor = "vapor", e.yeti = "yeti", e.zephyr = "zephyr", e))(Xe || {}), Mt = /* @__PURE__ */ ((e) => (e.medium = "medium", e.large = "large", e))(Mt || {}), Pe = /* @__PURE__ */ ((e) => (e.default = "default", e.verticalRight = "is-vertical-right", e.verticalLeft = "is-vertical-left", e))(Pe || {});
const ha = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  AnimationSpeeds: ge,
  AnimationTypes: we,
  BadgePositions: Ze,
  BorderTypes: Ye,
  BreadCrumbAlignments: Oe,
  BreadCrumbSeperators: vt,
  ButtonAlignments: St,
  ChartLegendPositions: He,
  ChartTypes: bt,
  ColorTypes: X,
  ColumnContainerModifiers: Ke,
  ColumnOffsetSizes: gt,
  ColumnSizes: le,
  DropZoneQuadrants: se,
  FixedMenuPositions: kt,
  FixedNavBarPositions: Te,
  IconSizes: re,
  NoticeTypes: ue,
  SectionSizes: Mt,
  Sizes: Z,
  SkinTypes: Xe,
  StepWizardOrientations: Pe,
  TabAlignments: qe,
  TabStyles: yt,
  TileSizes: ft,
  TileTypes: _t,
  ToolTipPositions: Be,
  ToolTipTextAlignments: Qe
}, Symbol.toStringTag, { value: "Module" })), Dt = "Language", Dr = (e, l) => l(Dt, e), Q = (e) => {
  const l = e(Dt, "en");
  return k(() => l);
}, $t = "IconSet", $r = (e, l) => l($t, e), ba = (e) => {
  const l = e($t, "solid");
  return k(() => l);
}, At = "SummerNoteCDN", Ar = (e, l) => l(At, e), va = (e) => e(At, "https://cdnjs.cloudflare.com/ajax/libs/summernote/0.9.0/"), Jt = "FontAwesomeCDN", Jr = (e, l) => l(Jt, e), ga = (e) => e(Jt, "https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.2/css/"), Nt = "AnimateCDN", Nr = (e, l) => l(Nt, e), ya = (e) => e(Nt, "https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/"), Ft = "ChartJSCDN", Fr = (e, l) => l(Ft, e), fa = (e) => e(Ft, "https://cdnjs.cloudflare.com/ajax/libs/Chart.js/4.4.7/"), wt = "AceJSCDN", wr = (e, l) => l(wt, e), _a = (e) => e(wt, "https://cdn.jsdelivr.net/npm/ace-builds@1.37.3/"), Ot = /* @__PURE__ */ D({
  __name: "animation",
  props: {
    incoming: {},
    outgoing: {},
    inout: {},
    speed: { default: ge.slow },
    speedIn: {},
    speedOut: {},
    repeating: {}
  },
  setup(e) {
    const l = ya(z);
    Ce(`${l}animate.min.css`);
    const t = e, a = (p) => {
      switch (p) {
        case ge.slower:
          return 3e3;
        case ge.fast:
          return 800;
        case ge.faster:
          return 500;
        default:
          return 2e3;
      }
    }, s = (p) => p === void 0 ? "" : `animate__${p}`, r = (p) => p === void 0 ? "animate__slow" : `animate__${p}`, n = k(() => ({
      enter: a(t.speedIn ?? t.speed),
      leave: a(t.speedOut ?? t.speed)
    })), d = k(() => [
      "animate__animated",
      s(t.incoming ?? t.inout),
      r(t.speedIn ?? t.speed)
    ].join(" ")), c = k(() => [
      "animate__animated",
      s(t.outgoing ?? t.inout),
      r(t.speedOut ?? t.speed)
    ].join(" ")), u = k(() => [
      "animate__animated",
      "animate__infinite",
      s(t.repeating),
      r(t.speed)
    ].join(" "));
    return (p, h) => t.repeating ? (o(), i("div", {
      key: 1,
      class: F(u.value)
    }, [
      P(p.$slots, "default")
    ], 2)) : (o(), I(na, {
      key: 0,
      "enter-active-class": d.value,
      "leave-active-class": c.value,
      duration: n.value
    }, {
      default: E(() => [
        P(p.$slots, "default")
      ]),
      _: 3
    }, 8, ["enter-active-class", "leave-active-class", "duration"]));
  }
}), ka = "brands.min.css", Sa = "all.min.css", ot = "icon_styles", Ma = /\.fa-([^: ]+):before/g, Da = /url\(([^)]+)\)/g, Me = x([]), Re = x(!1), ut = async (e, l) => {
  if (!Re.value) {
    Re.value = !0;
    let t;
    Me.value.length === 0 ? (t = document.createElement("style"), t.setAttribute("id", ot), document.head.appendChild(t), t.setAttribute("type", "text/css")) : t = document.getElementById(ot), Me.value = [" "];
    let a = await Promise.all([
      fetch(`${e}${ka}`),
      fetch(`${e}${Sa}`),
      fetch(`${e}${l}.min.css`)
    ]), s = await a[0].text();
    [...s.matchAll(Ma)].forEach((r) => {
      Me.value.push(r[1]);
    }), s = `${await a[1].text()}
    ${await a[2].text()}
    ${s}`, [...s.matchAll(Da)].forEach((r) => {
      s = s.replace(r[0], `url(${new URL(r[1], e)})`);
    }), t.innerText = s, Me.value.splice(0, 1), Re.value = !1;
  }
}, K = /* @__PURE__ */ D({
  __name: "icon",
  props: {
    icon: {},
    size: {}
  },
  setup(e) {
    const l = ga(z), t = ba(z);
    Me.value.length === 0 ? ut(l, t.value) : j(t, () => ut(l, t.value));
    const a = e, s = k(() => {
      let r = [];
      return a.icon !== void 0 && a.icon !== null && (Me.value.indexOf(a.icon) >= 0 ? r.push("fa-brands") : (r.push("fa-ico"), r.push(`fa-${t.value}`)), r.push((a.icon.indexOf("fa-") == -1 ? " fa-" : " ") + a.icon)), a.size !== void 0 && a.size !== null && a.size !== re.normal && r.push(`fa-${a.size}`), r;
    });
    return (r, n) => (o(), i("i", {
      class: F(s.value)
    }, null, 2));
  }
}), $a = ["disabled"], Aa = {
  key: 0,
  class: "icon is-small"
}, Ja = { key: 1 }, te = /* @__PURE__ */ D({
  __name: "button",
  props: {
    icon: {},
    type: { default: X.primary },
    title: {},
    disabled: { type: Boolean },
    size: { default: Z.normal },
    hide_mobile: { type: Boolean },
    hide_tablet: { type: Boolean },
    hide_desktop: { type: Boolean },
    is_rounded: { type: Boolean }
  },
  emits: ["click"],
  setup(e, { emit: l }) {
    const t = e, a = l, s = k(() => [
      "button",
      `is-${t.size ?? Z.normal}`,
      `is-${t.type ?? X.primary}`,
      t.disabled ? "disabled" : "",
      t.is_rounded ? "is-rounded" : "",
      t.hide_mobile ? "is-hidden-mobile" : "",
      t.hide_tablet ? "is-hidden-tablet-only" : "",
      t.hide_desktop ? "is-hidden-desktop is-hidden-widescreen" : ""
    ]);
    return (r, n) => (o(), i("button", {
      class: F(s.value),
      disabled: t.disabled,
      onClick: n[0] || (n[0] = (d) => a("click"))
    }, [
      t.icon ? (o(), i("span", Aa, [
        C(K, {
          icon: t.icon
        }, null, 8, ["icon"])
      ])) : A("", !0),
      t.title ? (o(), i("span", Ja, T(t.title), 1)) : A("", !0)
    ], 10, $a));
  }
}), Na = '{"en":{"Add":"Add","Cancel":"Cancel","Delete":"Delete","Disable":"Disable","Download":"Download","Edit":"Edit","Enable":"Enable","Okay":"Okay","Print":"Print","Refresh":"Refresh","Save":"Save","Submit":"Submit","Upload":"Upload"},"ar":{"Add":"مضافا","Cancel":"إلغاء","Delete":"تحذف","Disable":"العجز","Download":"تحميل","Edit":"Edit","Enable":"التمكين","Okay":"حسناً","Print":"الطباعة","Refresh":"التجديد","Save":"أنقذ","Submit":"Submit","Upload":"تحميل"},"az":{"Add":"Axtarış","Cancel":"Tarix","Delete":"Delete","Disable":"Qeydiyyat","Download":"Qeydiyyat","Edit":"Tarix","Enable":"Qeydiyyat","Okay":" Okay","Print":"Çap","Refresh":"Axtarış","Save":"Yadda","Submit":"Qeydiyyat","Upload":"Tarix"},"bg":{"Add":"Добавяне","Cancel":"Отмяна","Delete":"Изтриване","Disable":"Изключване","Download":"Изтегляне","Edit":"Редактиране","Enable":"Включване","Okay":"Добре","Print":"Печат","Refresh":"Обновяване","Save":"Запис","Submit":"Подаване","Upload":"Качване"},"bn":{"Add":"যোগ","Cancel":"বাতিল","Delete":"মুছে","Disable":"নিষ্ক্রিয়","Download":"ডাউনলোড","Edit":"সম্পাদনা","Enable":"সক্রিয়","Okay":"ঠিক","Print":"প্রিন্ট","Refresh":"নতুন","Save":"সংরক্ষণ","Submit":"জমা","Upload":"আপলোড"},"ca":{"Add":"Afegeix","Cancel":"Cancel·","Delete":"Esborra","Disable":"Deshabilita","Download":"Descarrega","Edit":"Edita","Enable":"Habilita","Okay":"Bé","Print":"Imprimeix","Refresh":"Refresca","Save":"Desa","Submit":"Envia","Upload":"Puja"},"cs":{"Add":"Přidat","Cancel":"Zrušit","Delete":"Smazat","Disable":"Zakázat","Download":"Stáhnout","Edit":"Upravit","Enable":"Povolit","Okay":"Dobře","Print":"Tisk","Refresh":"Obnovit","Save":"Uložit","Submit":"Odeslat","Upload":"Načíst"},"da":{"Add":"Tilføj","Cancel":"Annullér","Delete":"Slet","Disable":"Deaktivér","Download":"Download","Edit":"Redigér","Enable":"Aktivér","Okay":"Okay","Print":"Udskriv","Refresh":"Genopfrisk","Save":"Gem","Submit":"Indsend","Upload":"Upload"},"de":{"Add":"Hinzufügen","Cancel":"Abbrechen","Delete":"Löschen","Disable":"Deaktivieren","Download":"Herunterladen","Edit":"Bearbeiten","Enable":"Aktivieren","Okay":"Okay","Print":"Drucken","Refresh":"Aktualisieren","Save":"Speichern","Submit":"Senden","Upload":"Hochladen"},"el":{"Add":"Προσθήκη","Cancel":"Ακύρωση","Delete":"Διαγραφή","Disable":"Απενεργοποίηση","Download":"Λήψη","Edit":"Επεξεργασία","Enable":"Ενεργοποίηση","Okay":"Εντάξει","Print":"Εκτύπωση","Refresh":"Ανανέωση","Save":"Αποθήκευση","Submit":"Υποβολή","Upload":"Αποστολή"},"eo":{"Add":"Aldonu","Cancel":"Cancel","Delete":"Delete","Disable":"Distingebla","Download":"Elŝutu","Edit":"Edit","Enable":"Enable","Okay":"Bone","Print":"Presaĵo","Refresh":"Refresh","Save":"Savi","Submit":"Submit","Upload":"Ĝis"},"es":{"Add":"Añadir","Cancel":"Cancelar","Delete":"Suprimir","Disable":"Inhabilitación","Download":"Descargar","Edit":"Editar","Enable":"Habilitación","Okay":"Está","Print":"Imprimir","Refresh":"Refresh","Save":"Guardar","Submit":"Submit","Upload":"Subir"},"et":{"Add":"Lisa","Cancel":"Tühistage","Delete":"Kustuta","Disable":"Keela","Download":"Laadi","Edit":"Edit","Enable":"Luba","Okay":"Olgu","Print":"Printi","Refresh":"Värskenda","Save":"Päästa","Submit":"Esita","Upload":"Laadi"},"eu":{"Add":"Gehitu","Cancel":"Utzi","Delete":"Ezabatu","Disable":"Desgaitu","Download":"Deskargatu","Edit":"Editatu","Enable":"Gaitu","Okay":"Ados","Print":"Inprimatu","Refresh":"Freskatu","Save":"Gorde","Submit":"Bidali","Upload":"Igo"},"fa":{"Add":"Add","Cancel":"لغو","Delete":"حذف","Disable":"Disable","Download":"Download","Edit":"ویرایش","Enable":"گزینه","Okay":"خوب","Print":"Print","Refresh":"بازسازی","Save":"Save","Submit":"ارسال","Upload":"آپلود"},"fi":{"Add":"Lisää","Cancel":"Peruuta","Delete":"Poista","Disable":"Poista","Download":"Lataa","Edit":"Muuta","Enable":"Käytä","Okay":"Selvä","Print":"Tulosta","Refresh":"Päivitä","Save":"Tallenna","Submit":"Lähetä","Upload":"Lähetä"},"fr":{"Add":"Ajouter","Cancel":"Annuler","Delete":"Supprimer","Disable":"Désactiver","Download":"Télécharger","Edit":"Modifier","Enable":"Activer","Okay":"Très","Print":"Imprimer","Refresh":"Actualiser","Save":"Enregistrer","Submit":"Soumettre","Upload":"Envoi"},"ga":{"Add":"Déan","Cancel":"Cealaigh","Delete":"Scriosta","Disable":"Díroghnaigh","Download":"Íoslódáil","Edit":"Toir","Enable":"Cumasaigh","Okay":"Riachtanais","Print":"Priontáil","Refresh":"Athraigh","Save":"Sábháil","Submit":"Cuir","Upload":"Uaslódáil"},"gl":{"Add":"Add","Cancel":"Cancelar","Delete":"Eliminar","Disable":"Disable","Download":"Baixar","Edit":"Edit","Enable":"Habilitar","Okay":"Ok","Print":"Imprimir","Refresh":"Refresco","Save":"Save","Submit":"Presentación","Upload":"Upload"},"he":{"Add":"הוסף","Cancel":"ביטול","Delete":"Delete","Disable":"אכזבה","Download":"הורד","Edit":"Editעריכה","Enable":"אפשרות","Okay":"בסדר","Print":"הדפסה","Refresh":"מרעננים","Save":"להציל","Submit":"הגשת","Upload":"Upload"},"hi":{"Add":"जोड़ें","Cancel":"रद्द","Delete":"डिलीट","Disable":"अक्षम","Download":"डाउनलोड","Edit":"संपादित","Enable":"सक्षम","Okay":"ओके","Print":"छाप","Refresh":"रिफ्रेश","Save":"सहेजें","Submit":"जमा","Upload":"अपलोड"},"hu":{"Add":"Hozzáadás","Cancel":"Törlés","Delete":"Törlés","Disable":"Kikapcsolás","Download":"Letöltés","Edit":"Szerkesztés","Enable":"Beállítás","Okay":"Oké","Print":"Nyomtatás","Refresh":"Frissítés","Save":"Mentés","Submit":"Küldés","Upload":"Feltöltés"},"id":{"Add":"Tambah","Cancel":"Batal","Delete":"Hapus","Disable":"Matikan","Download":"Unduh","Edit":"Sunting","Enable":"Aktifkan","Okay":"Oke","Print":"Cetak","Refresh":"Segarkan","Save":"Simpan","Submit":"Kirim","Upload":"Unggah"},"it":{"Add":"Aggiungi","Cancel":"Annulla","Delete":"Cancella","Disable":"Disattivare","Download":"Scarica","Edit":"Modifica","Enable":"Abilitare","Okay":"Ok","Print":"Stampa","Refresh":"Rifiuti","Save":"Salva","Submit":"Inviare","Upload":"Caricamento"},"ja":{"Add":"追加する","Cancel":"キャンセル","Delete":"削除","Disable":"免責事項","Download":"ダウンロード","Edit":"編集","Enable":"アクセス","Okay":"お問い合わせ","Print":"プリント","Refresh":"リフレッシュ","Save":"保存する","Submit":"送信する","Upload":"アップロード"},"ko":{"Add":"기타","Cancel":"이름","Delete":"기타","Disable":"기타","Download":"다운로드","Edit":"제품정보","Enable":"이름","Okay":"이름","Print":"제품정보","Refresh":"지원하다","Save":"제품","Submit":"제출하기","Upload":"제품정보"},"lt":{"Add":"Pridėti","Cancel":"Atsisakyti","Delete":"Trinti","Disable":"Išjungti","Download":"Atsisiųsti","Edit":"Keisti","Enable":"Įjungti","Okay":"Gerai","Print":"Spausdinti","Refresh":"Atnaujinti","Save":"Įrašyti","Submit":"Siųsti","Upload":"Siųsti"},"lv":{"Add":"Pievienot","Cancel":"Atcelt","Delete":"Dzēst","Disable":"Atslēgt","Download":"Lejupielādēt","Edit":"Rediģēt","Enable":"Ieslēgt","Okay":"Labi","Print":"Drukāt","Refresh":"Atsvaidzināt","Save":"Saglabāt","Submit":"Nosūtīt","Upload":"Augšupielāde"},"ms":{"Add":"Tambah","Cancel":"Batal","Delete":"Dihapus","Disable":"Matikan","Download":"Muaturun","Edit":"Edit","Enable":"Hidupkan","Okay":"Oke","Print":"Cetakan","Refresh":"Segarkan","Save":"Simpan","Submit":"Diserahkan","Upload":"Unggah"},"nb":{"Add":"Legg","Cancel":"Avbryt","Delete":"Slett","Disable":"Slå","Download":"Last","Edit":"Rediger","Enable":"Slå","Okay":"Ok","Print":"Skriv","Refresh":"Oppdater","Save":"Lagre","Submit":"Send","Upload":"Last"},"nl":{"Add":"Voeg","Cancel":"Annuleren","Delete":"Verwijderen","Disable":"Uitschakelen","Download":"Downloaden","Edit":"Bewerken","Enable":"Inschakelen","Okay":"Oké","Print":"Afdrukken","Refresh":"Verversen","Save":"Opslaan","Submit":"Verzenden","Upload":"Uploaden"},"pl":{"Add":"Dodaj","Cancel":"Anuluj","Delete":"Usuń","Disable":"Wyłącz","Download":"Pobierz","Edit":"Edycja","Enable":"Włącz","Okay":"Dobrze","Print":"Drukuj","Refresh":"Odśwież","Save":"Zapisz","Submit":"Prześlij","Upload":"Wyślij"},"pt":{"Add":"Adicionar","Cancel":"Cancelar","Delete":"Excluir","Disable":"Deficiência","Download":"Baixar","Edit":"Editar","Enable":"Habilitar","Okay":"Está","Print":"Impressão","Refresh":"Atualizar","Save":"Salvar","Submit":"Submeter-me","Upload":"Carregar"},"ro":{"Add":"Adaugă","Cancel":"Renunță","Delete":"Șterge","Disable":"Dezactivează","Download":"Descărcare","Edit":"Editare","Enable":"Activează","Okay":"Bine","Print":"Tipărește","Refresh":"Reîmprospătează","Save":"Salvează","Submit":"Trimite","Upload":"Încarcă"},"ru":{"Add":"Добавить","Cancel":"Отменить","Delete":"Исключить","Disable":"Инвалид","Download":"Скачать","Edit":"Редактировать","Enable":"Допускать","Okay":"Хорошо","Print":"Печать","Refresh":"Освежить","Save":"Спасти","Submit":"Представить","Upload":"Загрузить"},"sk":{"Add":"Pridať","Cancel":"Zrušiť","Delete":"Odstrániť","Disable":"Zakázať","Download":"Stiahnuť","Edit":"Upraviť","Enable":"Povoliť","Okay":"Dobre","Print":"Tlač","Refresh":"Obnoviť","Save":"Uložiť","Submit":"Predložiť","Upload":"Odoslať"},"sl":{"Add":"Dodaj","Cancel":"Prekliči","Delete":"Zbriši","Disable":"Onemogoči","Download":"Prenesi","Edit":"Uredi","Enable":"Omogoči","Okay":"V","Print":"Natisni","Refresh":"Osveži","Save":"Shrani","Submit":"Pošlji","Upload":"Pošlji"},"sq":{"Add":"_Shto","Cancel":"Anullo","Delete":"Elemino","Disable":"Jo","Download":"Shkarkimi","Edit":"Ndrysho","Enable":"Aktivo","Okay":"Mirë","Print":"Printo","Refresh":"Rifresko","Save":"Ruaj","Submit":"Dërgo","Upload":"Ngarko"},"sv":{"Add":"Lägg","Cancel":"Avbokning","Delete":"Delete","Disable":"Inaktivera","Download":"Ladda","Edit":"Edit","Enable":"Aktivera","Okay":"Okej","Print":"Print","Refresh":"Refresh","Save":"Spara","Submit":"Inlämning","Upload":"Upload"},"th":{"Add":"เพิ่ม","Cancel":"ยกเลิก","Delete":"ลบ","Disable":"ปิดการใช้งาน","Download":"ดาวน์โหลด","Edit":"แก้ไข","Enable":"เปิด","Okay":"โอเค","Print":"พิมพ์","Refresh":"ปรับปรุงใหม่","Save":"บันทึก","Submit":"ส่ง","Upload":"อัปโหลด"},"tl":{"Add":"Magdagdag","Cancel":"Huwag","Delete":"Ibagsak","Disable":"Hindi","Download":"Ibaba","Edit":"Baguhin","Enable":"Kaibig","Okay":"Okay","Print":"Nakalimbag","Refresh":"Nakapagpapasigla","Save":"Mag","Submit":"Pagpapasakop","Upload":"Itaas"},"tr":{"Add":"Add","Cancel":"Cancel","Delete":"Delete","Disable":"Engelliler","Download":"Download","Edit":"Edit","Enable":"Enable","Okay":"Tamam","Print":"Baskı","Refresh":"Yenileme","Save":"Kaydet","Submit":"Gönder","Upload":"Download"},"uk":{"Add":"Додати","Cancel":"Зареєструватися","Delete":"Делет","Disable":"Вимкнути","Download":"Завантажити","Edit":"Редагування","Enable":"Увімкнути","Okay":"Проксимус","Print":"Друк","Refresh":"Реверс","Save":"Зберегти","Submit":"Подати","Upload":"Завантажити"},"ur":{"Add":"_شامل","Cancel":"منسوخ","Delete":"حذف","Disable":"منسوخ","Download":"اوپر","Edit":"مرتب","Enable":"فعال","Okay":"ٹھیک","Print":"پرنٹ","Refresh":"خوشی","Save":"محفوظ","Submit":"غیر","Upload":"اپ"},"zh":{"Add":"添加","Cancel":"取消","Delete":"删除","Disable":"禁用","Download":"下载","Edit":"编辑","Enable":"启用","Okay":"还好","Print":"打印","Refresh":"刷新","Save":"保存","Submit":"提交","Upload":"上传"},"zt":{"Add":"添加","Cancel":"取消","Delete":"刪除","Disable":"禁用","Download":"下載","Edit":"編輯","Enable":"開啟","Okay":"好吧","Print":"打印","Refresh":"刷新","Save":"保存","Submit":"提交","Upload":"上傳"}}', Fa = '{"en":{"Filter":"Filter"},"ar":{"Filter":"فيلم"},"az":{"Filter":" Filter"},"bg":{"Filter":"Филтър"},"bn":{"Filter":"ফিল্টার"},"ca":{"Filter":"Filtre"},"cs":{"Filter":"Filtr"},"da":{"Filter":"Filter"},"de":{"Filter":"Filter"},"el":{"Filter":"Φίλτρο"},"eo":{"Filter":"Filtero"},"es":{"Filter":"Filtro"},"et":{"Filter":"Filter"},"eu":{"Filter":"Iragazkia"},"fa":{"Filter":"فیلتر"},"fi":{"Filter":"Suodatin"},"fr":{"Filter":"Filtre"},"ga":{"Filter":"Scagaire"},"gl":{"Filter":"Filtrar"},"he":{"Filter":"Filter"},"hi":{"Filter":"फिल्टर"},"hu":{"Filter":"Szűrő"},"id":{"Filter":"Filter"},"it":{"Filter":"Filtro"},"ja":{"Filter":"フィルター"},"ko":{"Filter":"제품정보"},"lt":{"Filter":"Filtras"},"lv":{"Filter":"Filtrs"},"ms":{"Filter":"Penapis"},"nb":{"Filter":"Filtrer"},"nl":{"Filter":"Filter"},"pl":{"Filter":"Filtr"},"pt":{"Filter":"Filtro"},"ro":{"Filter":"Filtru"},"ru":{"Filter":"Фильтр"},"sk":{"Filter":"Filter"},"sl":{"Filter":"Filter"},"sq":{"Filter":"Filtra"},"sv":{"Filter":"Filter"},"th":{"Filter":"กรอง"},"tl":{"Filter":"Pansala"},"tr":{"Filter":"Filtre"},"uk":{"Filter":"Фільтри"},"ur":{"Filter":"فائلز"},"zh":{"Filter":"过滤器"},"zt":{"Filter":"分頁"}}', wa = '{"en":{"Previous":"Previous","Next":"Next","Older":"Older","Newer":"Newer","GoToPage":"Go To Page"},"ar":{"Previous":"سابقا","Next":"التالي","Older":"كبار","Newer":"Newer","GoToPage":"الذهاب إلى الصفحة"},"az":{"Previous":" Previous","Next":" Next","Older":"Yaşlı","Newer":"Yeniyetmə","GoToPage":"Qeydiyyat"},"bg":{"Previous":"Предишен","Next":"Следващият","Older":"По-","Newer":"По-","GoToPage":"Отиване на страница"},"bn":{"Previous":"পূর্ববর্তী","Next":"পরবর্তী","Older":"বয়স্ক","Newer":"নিউকার","GoToPage":"চিহ্নিত স্থানে চলুন"},"ca":{"Previous":"Anterior","Next":"Següent","Older":"Vella","Newer":"Més","GoToPage":"Vés a la pàgina"},"cs":{"Previous":"Předchozí","Next":"Další","Older":"Starší","Newer":"Novější","GoToPage":"Přejít na stránku"},"da":{"Previous":"Forrige","Next":"Næste","Older":"Ældre","Newer":"Nyere","GoToPage":"Gå til side"},"de":{"Previous":"Vorherige","Next":"Nach","Older":"Ältere","Newer":"Neuer","GoToPage":"Zur Seite gehen"},"el":{"Previous":"Προηγούμενο","Next":"Επόμενο","Older":"Μεγαλύτερος","Newer":"Νεότερα","GoToPage":"Μετάβαση στη σελίδα"},"eo":{"Previous":"Antaŭa","Next":"La","Older":"Pli","Newer":"Pli","GoToPage":"Iru al paĝo"},"es":{"Previous":"Anterior","Next":"Siguiente","Older":"Older","Newer":"Newer","GoToPage":"Ir a la página"},"et":{"Previous":"Eelmine","Next":"Järgmine","Older":"Vanem","Newer":"Uuem","GoToPage":"Mine lehele"},"eu":{"Previous":"Aurrekoa","Next":"Hurrengoa","Older":"Zaharragoa","Newer":"Newer","GoToPage":"Joan orrira"},"fa":{"Previous":"Previous","Next":"بعدی","Older":"مسن","Newer":"Newer","GoToPage":"به صفحه بروید"},"fi":{"Previous":"Edellinen","Next":"Seuraava","Older":"Vanhempi","Newer":"Uusi","GoToPage":"Siirry sivulle"},"fr":{"Previous":"Précédent","Next":"Suivant","Older":"Plus","Newer":"Plus","GoToPage":"Aller à la page"},"ga":{"Previous":"Roimhe","Next":"Ar","Older":"Sean","Newer":"Nuashonraigh","GoToPage":"Téigh go Leathanach"},"gl":{"Previous":"Anterior","Next":"Seguinte","Older":"Idade","Newer":"Newer","GoToPage":"Ir á páxina"},"he":{"Previous":"הקודם","Next":"הבא","Older":"מבוגר","Newer":"חדש","GoToPage":"ללכת לדף"},"hi":{"Previous":"पिछला","Next":"अगला","Older":"पुराना","Newer":"नया","GoToPage":"पृष्ठ पर जाएं"},"hu":{"Previous":"Előző","Next":"Következő","Older":"Idősebb","Newer":"Újabb","GoToPage":"Ugrás az oldalra"},"id":{"Previous":"Sebelumnya","Next":"Berikutnya","Older":"Lebih","Newer":"Baru","GoToPage":"Ke Halaman"},"it":{"Previous":"Precedente","Next":"Il","Older":"Vecchio","Newer":"Nuovo","GoToPage":"Vai alla pagina"},"ja":{"Previous":"新着情報","Next":"次へ","Older":"古い投稿","Newer":"ニュース","GoToPage":"サイトマップ"},"ko":{"Previous":"이름","Next":"이름","Older":"인기있는","Newer":"더","GoToPage":"본문 바로가기"},"lt":{"Previous":"Ankstesnis","Next":"Sekantis","Older":"Senesni","Newer":"Naujokas","GoToPage":"Pereiti į puslapį"},"lv":{"Previous":"Iepriekšējais","Next":"Nākamais","Older":"Vecāki","Newer":"Jaunāks","GoToPage":"Iet uz lapu"},"ms":{"Previous":"Sebelumnya","Next":"Next","Older":"♪","Newer":"Perancis","GoToPage":"Pergi Ke Halaman"},"nb":{"Previous":"Forrige","Next":"Neste","Older":"Eldre","Newer":"Nyere","GoToPage":"Gå til siden"},"nl":{"Previous":"Vorige","Next":"Volgende","Older":"Ouder","Newer":"Nieuwer","GoToPage":"Ga naar pagina"},"pl":{"Previous":"Poprzedni","Next":"Następny","Older":"Starszy","Newer":"Nowsza","GoToPage":"Przejdź do strony"},"pt":{"Previous":"Anterior","Next":"Próximo","Older":"O","Newer":"Mais","GoToPage":"Ir para a página"},"ro":{"Previous":"Precedent","Next":"Înainte","Older":"Mai","Newer":"Mai","GoToPage":"Du-te la pagina"},"ru":{"Previous":"Предыдущий","Next":"Следующий","Older":"Старше","Newer":"Новый","GoToPage":"Перейти на страницу"},"sk":{"Previous":"Predchádzajúca","Next":"Nasledujúci","Older":"Staršie","Newer":"Novšie","GoToPage":"Prejsť na stránku"},"sl":{"Previous":"Prejšnja","Next":"Naprej","Older":"Starejši","Newer":"Novejši","GoToPage":"Pojdi na stran"},"sq":{"Previous":"Paraardhëse","Next":"Në","Older":"Më","Newer":"Ri","GoToPage":"Shko tek faqja"},"sv":{"Previous":"Föregående","Next":"Nästa","Older":"Äldre","Newer":"Nyare","GoToPage":"Gå till Page"},"th":{"Previous":"ก่อนหน้า","Next":"ต่อไป","Older":"อายุ","Newer":"สร้างใหม่","GoToPage":"ไปยังหน้า"},"tl":{"Previous":"Bago","Next":"Susunod","Older":"Mas","Newer":"Mas","GoToPage":"Pumunta sa Pahina"},"tr":{"Previous":"Önceki","Next":"Sonraki","Older":"Yaşlı","Newer":"Newer","GoToPage":"Go To Page"},"uk":{"Previous":"Попереднє","Next":"Про","Older":"Старші","Newer":"Нова","GoToPage":"Перейти на сторінку"},"ur":{"Previous":"پہلے","Next":"اگلا","Older":"عمررسیدہ","Newer":"نیا","GoToPage":"صفحہ ۲۴ پر جائیں"},"zh":{"Previous":"上一个","Next":"下一个","Older":"老年人","Newer":"更新","GoToPage":"转到页面"},"zt":{"Previous":"前一個","Next":"下一頁","Older":"老了","Newer":"更新","GoToPage":"跳至頁面"}}', Oa = `{"en":{"Weekdays":{"Sun":"Sun","Mon":"Mon","Tue":"Tue","Wed":"Wed","Thu":"Thu","Fri":"Fri","Sat":"Sat","Sunday":"Sunday","Monday":"Monday","Tuesday":"Tuesday","Wednesday":"Wednesday","Thursday":"Thursday","Friday":"Friday","Saturday":"Saturday"},"Months":{"Jan":"Jan","Feb":"Feb","Mar":"Mar","Apr":"Apr","May":"May","Jun":"Jun","Jul":"Jul","Aug":"Aug","Sep":"Sep","Oct":"Oct","Nov":"Nov","Dec":"Dec","January":"January","February":"February","March":"March","April":"April","June":"June","July":"July","August":"August","September":"September","October":"October","November":"November","December":"December"},"Today":"Today"},"ar":{"Weekdays":{"Sun":"الشمس","Mon":"مون","Tue":"Tue","Wed":"Wed","Thu":"Thu","Fri":"فري","Sat":"Sat","Sunday":"الأحد","Monday":"الاثنين","Tuesday":"الثلاثاء","Wednesday":"الأربعاء","Thursday":"الخميس","Friday":"الجمعة","Saturday":"السبت"},"Months":{"Jan":"يان","Feb":"شباط/فبراير","Mar":"Mar","Apr":"Apr","May":"أيار/مايو","Jun":"جون","Jul":"(جول)","Aug":"آب/أغسطس","Sep":"Sep","Oct":"Oct","Nov":"Nov","Dec":"Dec","January":"كانون","February":"شباط/فبراير","March":"آذار/مارس","April":"نيسان/أبريل","June":"حزيران/يونيه","July":"تموز/يوليه","August":"آب/أغسطس","September":"أيلول/سبتمبر","October":"تشرين","November":"تشرين","December":"كانون"},"Today":"اليوم"},"az":{"Weekdays":{"Sun":"Qalereya","Mon":"Bakı","Tue":"Qalereya","Wed":"Biznes","Thu":"Qalereya","Fri":"Bakı","Sat":"Bakı","Sunday":"Bakı","Monday":"Bakı","Tuesday":"Bakı","Wednesday":"Bakı","Thursday":"Bakı","Friday":"Bakı","Saturday":"Bakı"},"Months":{"Jan":"Axtarış","Feb":"Bakı","Mar":"Bakı","Apr":"Bakı","May":"İyul","Jun":"Bakı","Jul":"Bakı","Aug":"Axtarış","Sep":"Bakı","Oct":"Axtarış","Nov":"Bakı","Dec":"Elan","January":"Yanvar","February":"Fevral","March":"Bakı","April":"Bakı","June":"İyun","July":"İyul","August":"Avqust","September":"Bakı","October":"Bakı","November":"Bakı","December":"Bakı"},"Today":"Bu"},"bg":{"Weekdays":{"Sun":"Слънце","Mon":"Мон","Tue":"Туе","Wed":"Сватба","Thu":"Thu","Fri":"Fri","Sat":"Сат","Sunday":"Неделя","Monday":"Понеделник","Tuesday":"Вторник","Wednesday":"Сряда","Thursday":"Четвъртък","Friday":"Петък","Saturday":"Събота"},"Months":{"Jan":"Ян","Feb":"Февруари","Mar":"Мар","Apr":"Apr","May":"Май","Jun":"Джун","Jul":"Юли","Aug":"Aug","Sep":"Сеп","Oct":"Окт","Nov":"Nov","Dec":"Дек","January":"Януари","February":"Февруари","March":"Март","April":"Април","June":"Юни","July":"Юли","August":"Август","September":"Септември","October":"Октомври","November":"Ноември","December":"Декември"},"Today":"Днес"},"bn":{"Weekdays":{"Sun":"রবি","Mon":"মন","Tue":"মঙ্গল","Wed":"অস্বীকৃত","Thu":"বৃহঃ","Fri":"ফ্রিসেল","Sat":"শনি","Sunday":"রবিবার","Monday":"সোমবার","Tuesday":"মঙ্গলবার","Wednesday":"বুধবার","Thursday":"বৃহস্পতিবার","Friday":"শুক্রবার","Saturday":"শনিবার"},"Months":{"Jan":"জানুয়ারী","Feb":"ফেব্রুয়ারীMarch","Mar":"মার্চApril","Apr":"এপ্রিল","May":"মে","Jun":"জুনিউ","Jul":"জুমি","Aug":"আগস্ট","Sep":"সেপ্টেম্বরOctober","Oct":"অক্টোবর","Nov":"নভেম্বর","Dec":"ডিসেম্বর","January":"জানুয়ারী","February":"ফেব্রুয়ারী","March":"মার্চ","April":"এপ্রিল","June":"জুন","July":"জুলাই","August":"আগস্ট","September":"সেপ্টেম্বর","October":"অক্টোবর","November":"নভেম্বর","December":"সদস্য"},"Today":"আজ"},"ca":{"Weekdays":{"Sun":"Sol","Mon":"Dl","Tue":"Dt","Wed":"Dc","Thu":"Dj","Fri":"DvSaturday","Sat":"DsSunday","Sunday":"Diumenge","Monday":"Dilluns","Tuesday":"Dimarts","Wednesday":"Dimecres","Thursday":"Dijous","Friday":"Divendres","Saturday":"Dissabte"},"Months":{"Jan":"Mare","Feb":"FebMarch","Mar":"Mar","Apr":"AbrMay","May":"Maig","Jun":"JunJuly","Jul":"JulAugust","Aug":"AgoSeptember","Sep":"Set","Oct":"Oct","Nov":"Nov","Dec":"Des","January":"Gener","February":"Febrer","March":"Març","April":"Abril","June":"Juny","July":"Juliol","August":"Agost","September":"Setembre","October":"Octubre","November":"Novembre","December":"Desembre"},"Today":"Avui"},"cs":{"Weekdays":{"Sun":"Slunce","Mon":"Po","Tue":"Tue","Wed":"St","Thu":"Thu","Fri":"Fri","Sat":"Sad","Sunday":"Neděle","Monday":"Pondělí","Tuesday":"Úterý","Wednesday":"Středa","Thursday":"Čtvrtek","Friday":"Pátek","Saturday":"Sobota"},"Months":{"Jan":"Jan","Feb":"Únor","Mar":"Březen","Apr":"Duben","May":"May","Jun":"Jun","Jul":"Jul","Aug":"Srpen","Sep":"Září","Oct":"Říjen","Nov":"Listopad","Dec":"Prosinec","January":"Leden","February":"Únor","March":"Březen","April":"Duben","June":"Červen","July":"Červenec","August":"Srpen","September":"Září","October":"Říjen","November":"Listopad","December":"Prosinec"},"Today":"Dnes"},"da":{"Weekdays":{"Sun":"Sol","Mon":"Mon","Tue":"Tir","Wed":"On","Thu":"Thu","Fri":"Fri","Sat":"Lø","Sunday":"Søndag","Monday":"Mandag","Tuesday":"Tirsdag","Wednesday":"Onsdag","Thursday":"Torsdag","Friday":"Fredag","Saturday":"Lørdag"},"Months":{"Jan":"Jan","Feb":"Feb","Mar":"Mar","Apr":"Apr","May":"Maj","Jun":"Jun","Jul":"Jul","Aug":"Aug","Sep":"Sep","Oct":"Okt","Nov":"Nov","Dec":"Dec","January":"Januar","February":"Februar","March":"Marts","April":"April","June":"Juni","July":"Juli","August":"August","September":"September","October":"Oktober","November":"November","December":"December"},"Today":"I"},"de":{"Weekdays":{"Sun":"Sonne","Mon":"Mo","Tue":"Di","Wed":"Mi","Thu":"Do","Fri":"Fri","Sat":"Sa","Sunday":"Sonntag","Monday":"Montag","Tuesday":"Dienstag","Wednesday":"Mittwoch","Thursday":"Donnerstag","Friday":"Freitag","Saturday":"Samstag"},"Months":{"Jan":"Jan","Feb":"Feb","Mar":"Mär","Apr":"Apr","May":"Mai","Jun":"Jun","Jul":"Juli","Aug":"Aug","Sep":"Sep","Oct":"Okt","Nov":"Nov","Dec":"Dez","January":"Januar","February":"Februar","March":"März","April":"April","June":"Juni","July":"Juli","August":"August","September":"September","October":"Oktober","November":"November","December":"Dezember"},"Today":"Heute"},"el":{"Weekdays":{"Sun":"Ήλιος","Mon":"Δευ","Tue":"Τεύχος","Wed":"Τετ","Thu":"Θου","Fri":"Παρ","Sat":"Σάβ","Sunday":"Κυριακή","Monday":"Δευτέρα","Tuesday":"Τρίτη","Wednesday":"Τετάρτη","Thursday":"Πέμπτη","Friday":"Παρασκευή","Saturday":"Σάββατο"},"Months":{"Jan":"Ιαν","Feb":"Φεβ","Mar":"Μαρ","Apr":"Απρ","May":"Μάιος","Jun":"Ιουν","Jul":"Ιουλ","Aug":"Αυγ","Sep":"Σεπ","Oct":"Οκτ","Nov":"Νοε","Dec":"Δεκ","January":"Ιανουάριος","February":"Φεβρουάριος","March":"Μάρτιος","April":"Απρίλιος","June":"Ιούνιος","July":"Ιούλιος","August":"Αύγουστος","September":"Σεπτέμβριος","October":"Οκτώβριος","November":"Νοέμβριος","December":"Δεκέμβριος"},"Today":"Σήμερα"},"eo":{"Weekdays":{"Sun":"Suno","Mon":"Mon","Tue":"Tue","Wed":"Ni","Thu":"Tumulto","Fri":"Frio","Sat":"Sidanta","Sunday":"Dimanĉo","Monday":"Lundo","Tuesday":"Marŝi","Wednesday":"Merkredo","Thursday":"Ĵaŭdon","Friday":"Vendrede","Saturday":"Sabato"},"Months":{"Jan":"Jan","Feb":"Feb","Mar":"Marŝa","Apr":"Apr","May":"Majo","Jun":"Jun","Jul":"Jul","Aug":"Aŭgusto","Sep":"Sep","Oct":"Oktobro","Nov":"Nov-Zelando","Dec":"Dec","January":"Januaro","February":"Februaro","March":"Marto","April":"April","June":"Junio","July":"Julio","August":"Aŭgusto","September":"Septembro","October":"Oktobro","November":"Novembro","December":"Decembro"},"Today":"Hodiaŭ"},"es":{"Weekdays":{"Sun":"Sol","Mon":"Mon","Tue":"Tue","Wed":"Wed","Thu":"Thu","Fri":"Fri","Sat":"Sat","Sunday":"Domingo","Monday":"Lunes","Tuesday":"Martes","Wednesday":"Miércoles","Thursday":"Jueves","Friday":"Viernes","Saturday":"Sábado"},"Months":{"Jan":"Jan","Feb":"Feb","Mar":"Mar","Apr":"Apr","May":"Mayo","Jun":"Jun","Jul":"Jul","Aug":"Aug","Sep":"Sep","Oct":"Oct","Nov":"Nov","Dec":"Dec","January":"Enero","February":"Febrero","March":"Marzo","April":"Abril","June":"Junio","July":"Julio","August":"Agosto","September":"Septiembre","October":"Octubre","November":"Noviembre","December":"Diciembre"},"Today":"Hoy"},"et":{"Weekdays":{"Sun":"Päike","Mon":"Mon","Tue":"Tue","Wed":"Wed","Thu":"Thu","Fri":"Fri","Sat":"Sattus","Sunday":"Pühapäev","Monday":"Esmaspäev","Tuesday":"Teisipäev","Wednesday":"Kolmapäev","Thursday":"Neljapäeval","Friday":"Reede","Saturday":"Laupäev"},"Months":{"Jan":"Jan","Feb":"Veebruar","Mar":"Mar","Apr":"Apr","May":"May","Jun":"Jun","Jul":"Jul","Aug":"Aug","Sep":"Sep","Oct":"Oktoober","Nov":"Nov","Dec":"Dec","January":"Jaanuar","February":"Veebruar","March":"Märts","April":"Aprill","June":"Juuni","July":"Juuli","August":"August","September":"September","October":"Oktoober","November":"November","December":"Detsember"},"Today":"Täna"},"eu":{"Weekdays":{"Sun":"Sun","Mon":"Mon","Tue":"Tue","Wed":"Apustua","Thu":"Og","Fri":"Fri","Sat":"Sat","Sunday":"Igandea","Monday":"Astelehena","Tuesday":"Asteartea","Wednesday":"Asteazkena","Thursday":"Osteguna","Friday":"Ostirala","Saturday":"Larunbata"},"Months":{"Jan":"Jan","Feb":"Ots","Mar":"Marmar","Apr":"Apr","May":"Maiatza","Jun":"Jun","Jul":"Jul","Aug":"Abusua","Sep":"Ira","Oct":"Oct","Nov":"Aza","Dec":"Abendua","January":"Urtarrila","February":"Otsaila","March":"Martxoa","April":"Apirila","June":"Ekaina","July":"Uztaila","August":"Abuztua","September":"Iraila","October":"Urria","November":"Azaroa","December":"Abendua"},"Today":"Gaur"},"fa":{"Weekdays":{"Sun":"خورشید","Mon":"مون","Tue":"Tue","Wed":"Wed","Thu":"تو","Fri":"Fri","Sat":"Sat","Sunday":"یکشنبه","Monday":"دوشنبه","Tuesday":"سه","Wednesday":"چهارشنبه","Thursday":"پنجشنبه","Friday":"جمعه","Saturday":"شنبه"},"Months":{"Jan":"ژانویه","Feb":"فوریه","Mar":"Mar","Apr":"آوریل","May":"ممکن","Jun":"Jun","Jul":"جول","Aug":"آگوست","Sep":"سپتامبر","Oct":"اکتبر","Nov":"نوامبر","Dec":"دسامبر","January":"ژانویه","February":"فوریه","March":"مارس","April":"آوریل","June":"ژوئن","July":"جولای","August":"آگوست","September":"سپتامبر","October":"اکتبر","November":"نوامبر","December":"دسامبر"},"Today":"امروز"},"fi":{"Weekdays":{"Sun":"Su","Mon":"Ma","Tue":"Ti","Wed":"Ke","Thu":"To","Fri":"Pe","Sat":"La","Sunday":"Sunnuntai","Monday":"Maanantai","Tuesday":"Tiistai","Wednesday":"Keskiviikko","Thursday":"Torstai","Friday":"Perjantai","Saturday":"Lauantai"},"Months":{"Jan":"Tammi","Feb":"Helmi","Mar":"Maalis","Apr":"Huhti","May":"Toukokuu","Jun":"Kesä","Jul":"Heinä","Aug":"Elo","Sep":"Syys","Oct":"Loka","Nov":"Marras","Dec":"Joulu","January":"Tammikuu","February":"Helmikuu","March":"Maaliskuu","April":"Huhtikuu","June":"Kesäkuu","July":"Heinäkuu","August":"Elokuu","September":"Syyskuu","October":"Lokakuu","November":"Marraskuu","December":"Joulukuu"},"Today":"Tänään"},"fr":{"Weekdays":{"Sun":"Soleil","Mon":"Mon","Tue":"Tu","Wed":"Mariage","Thu":"Jeu","Fri":"Ven","Sat":"Sat","Sunday":"Dimanche","Monday":"Lundi","Tuesday":"Mardi","Wednesday":"Mercredi","Thursday":"Jeudi","Friday":"Vendredi","Saturday":"Samedi"},"Months":{"Jan":"Janvier","Feb":"Fév","Mar":"Mars","Apr":"Avr","May":"Mai","Jun":"Juin","Jul":"Juillet","Aug":"Août","Sep":"Sep","Oct":"Oct","Nov":"Nov","Dec":"Déc","January":"Janvier","February":"Février","March":"Mars","April":"Avril","June":"Juin","July":"Juillet","August":"Août","September":"Septembre","October":"Octobre","November":"Novembre","December":"Décembre"},"Today":"Aujourd'hui"},"ga":{"Weekdays":{"Sun":"Ghrian","Mon":"Uisce","Tue":"Déan","Wed":"Táimid","Thu":"Thuama","Fri":"Múirín","Sat":"Sábháil","Sunday":"Domhnach","Monday":"Dé","Tuesday":"Dé","Wednesday":"Dé","Thursday":"Déardaoin","Friday":"Dé","Saturday":"Dé"},"Months":{"Jan":"An","Feb":"Is","Mar":"Mar","Apr":"Aibreán","May":"Bealtaine","Jun":"Amharc","Jul":"Jul","Aug":"Lúnasa","Sep":"Meán","Oct":"Deireadh","Nov":"Cineál","Dec":"Déan","January":"Irl","February":"Amharc","March":"Márta","April":"Amharc","June":"Meitheamh","July":"Irl","August":"Amharc","September":"Meán","October":"Deireadh","November":"Samhain","December":"Nollaig"},"Today":"Sa"},"gl":{"Weekdays":{"Sun":"Sol","Mon":"Mon","Tue":"Tue","Wed":"Apostamos","Thu":"Tu","Fri":"Frio","Sat":"Sat","Sunday":"Domingo","Monday":"Luns","Tuesday":"Martes","Wednesday":"Miércoles","Thursday":"Xoves","Friday":"Venres","Saturday":"Sábado"},"Months":{"Jan":"Jan","Feb":"Febreiro","Mar":"Mar","Apr":"Abril","May":"Maio","Jun":"Jun","Jul":"Xullo","Aug":"Aug","Sep":"Sep","Oct":"Oct","Nov":"Novidade","Dec":"Dec","January":"Xaneiro","February":"Febreiro","March":"Marzo","April":"Abril","June":"Xuño","July":"Xullo","August":"Agosto","September":"Setembro","October":"Outubro","November":"Novembro","December":"Decembro"},"Today":"Hoxe"},"he":{"Weekdays":{"Sun":"השמש","Mon":"מונמון","Tue":"Tue","Wed":"Wed","Thu":"תור","Fri":"פרי","Sat":"Sat","Sunday":"יום","Monday":"יום","Tuesday":"יום","Wednesday":"יום","Thursday":"יום","Friday":"יום","Saturday":"יום"},"Months":{"Jan":"יאן","Feb":"פברואר","Mar":"Mar","Apr":"אנגלית","May":"במאי","Jun":"ג'ון","Jul":"יולי","Aug":"אוגוסט","Sep":"ספרד","Oct":"באוקטובר","Nov":"נובמבר","Dec":"דצמבר","January":"ינואר","February":"פברואר","March":"מרץ","April":"אפריל","June":"יוני","July":"יולי","August":"אוגוסט","September":"ספטמבר","October":"אוקטובר","November":"נובמבר","December":"דצמבר"},"Today":"היום"},"hi":{"Weekdays":{"Sun":"सूर्य","Mon":"सोम","Tue":"मंगल","Wed":"Wed","Thu":"गुरु","Fri":"शुक्र","Sat":"सत","Sunday":"रविवार","Monday":"सोमवार","Tuesday":"मंगलवार","Wednesday":"बुधवार","Thursday":"गुरुवार","Friday":"शुक्रवार","Saturday":"शनिवार"},"Months":{"Jan":"जनवरी","Feb":"फ़रवरी","Mar":"मार्च","Apr":"अप्रैल","May":"मई","Jun":"जून","Jul":"जुलाई","Aug":"अगस्त","Sep":"सितंबर","Oct":"अक्टूबर","Nov":"नवम्बर","Dec":"दिसम्बर","January":"जनवरी","February":"फ़रवरी","March":"मार्च","April":"अप्रैल","June":"जून","July":"जुलाई","August":"अगस्त","September":"सितंबर","October":"अक्टूबर","November":"नवंबर","December":"दिसम्बर"},"Today":"आज"},"hu":{"Weekdays":{"Sun":"Nap","Mon":"H","Tue":"Sze","Wed":"Wed","Thu":"Thu","Fri":"Fri","Sat":"Sat","Sunday":"Vasárnap","Monday":"Hétfő","Tuesday":"Kedd","Wednesday":"Szerda","Thursday":"Csütörtök","Friday":"Péntek","Saturday":"Szombat"},"Months":{"Jan":"Jan","Feb":"Feb","Mar":"Mar","Apr":"Apr","May":"Május","Jun":"Jun","Jul":"Jul","Aug":"Aug","Sep":"Sz","Oct":"Okt","Nov":"Nov","Dec":"Dec","January":"Január","February":"Február","March":"Március","April":"Április","June":"Június","July":"Július","August":"Augusztus","September":"Szeptember","October":"Október","November":"November","December":"December"},"Today":"Ma"},"id":{"Weekdays":{"Sun":"Matahari","Mon":"Mon","Tue":"Tue","Wed":"Busana","Thu":"Thu","Fri":"Fri","Sat":"Sab","Sunday":"Minggu","Monday":"Senin","Tuesday":"Selasa","Wednesday":"Rabu","Thursday":"Kamis","Friday":"Jumat","Saturday":"Sabtu"},"Months":{"Jan":"Jan","Feb":"Feb","Mar":"Mar","Apr":"Apr","May":"Mei","Jun":"Jun","Jul":"Jul","Aug":"Aug","Sep":"Sep","Oct":"Okt","Nov":"Nov","Dec":"Dec","January":"Januari","February":"Februari","March":"Maret","April":"April","June":"Juni","July":"Juli","August":"Agustus","September":"September","October":"Oktober","November":"November","December":"Desember"},"Today":"Hari"},"it":{"Weekdays":{"Sun":"Sole","Mon":"Mon","Tue":"Tue","Wed":"Wed","Thu":"Gio","Fri":"Fri","Sat":"Rasoio","Sunday":"Domenica","Monday":"Lunedì","Tuesday":"Martedì","Wednesday":"Mercoledì","Thursday":"Giovedì","Friday":"Venerdì","Saturday":"Sabato"},"Months":{"Jan":"Jan","Feb":"Febbraio","Mar":"Mar","Apr":"Aprile","May":"Maggio","Jun":"Jun","Jul":"Jul","Aug":"Agosto","Sep":"Articolo","Oct":"Ottobre","Nov":"No","Dec":"Dec","January":"Gennaio","February":"Febbraio","March":"Marzo","April":"Aprile","June":"Giugno","July":"Luglio","August":"Agosto","September":"Settembre","October":"Ottobre","November":"Novembre","December":"Dicembre"},"Today":"Oggi"},"ja":{"Weekdays":{"Sun":"日曜日","Mon":"モンド","Tue":"火曜日","Wed":"お問い合わせ","Thu":"日","Fri":"フリガナ","Sat":"スタッフ","Sunday":"日曜日","Monday":"月曜日～金曜日","Tuesday":"火曜日","Wednesday":"水曜日","Thursday":"木曜日","Friday":"金曜日","Saturday":"土曜日"},"Months":{"Jan":"1月1日","Feb":"1月2日","Mar":"マーキー","Apr":"4月4日","May":"5月5日","Jun":"ジュンジュン","Jul":"7月7日","Aug":"8月8日","Sep":"9月9日","Oct":"10月10日","Nov":"11月11日","Dec":"12月12日","January":"1月1日","February":"2月2日","March":"3月3日","April":"4月4日","June":"6月6日","July":"7月7日","August":"8月8日","September":"9月9日","October":"10月10日","November":"11月11日","December":"12月12日"},"Today":"今日更新"},"ko":{"Weekdays":{"Sun":"(주)","Mon":"담당자","Tue":" ","Wed":"사이트맵","Thu":"₢","Fri":"₢","Sat":"·","Sunday":"주","Monday":"월요일,","Tuesday":"*","Wednesday":"-","Thursday":"주","Friday":"월~금","Saturday":"·"},"Months":{"Jan":"1","Feb":"2월","Mar":"3","Apr":"4","May":"5","Jun":"주","Jul":"7","Aug":"8","Sep":"9월","Oct":"10월","Nov":"11월","Dec":"12월","January":"1월","February":"2","March":"3","April":"4","June":"6월","July":"7","August":"8","September":"9","October":"10월","November":"11","December":"12"},"Today":"으로"},"lt":{"Weekdays":{"Sun":"Saulė","Mon":"Mon","Tue":"Tue","Wed":"WEd","Thu":"Thu","Fri":"FrNAME","Sat":"Sat","Sunday":"Sekmadienis","Monday":"Pirmadienis","Tuesday":"Antradienis","Wednesday":"Trečiadienis","Thursday":"Ketvirtadienis","Friday":"Penktadienis","Saturday":"Šeštadienis"},"Months":{"Jan":"Sau","Feb":"Vas","Mar":"Mar","Apr":"Bal","May":"Gegužės","Jun":"Bir","Jul":"Lie","Aug":"Rgp","Sep":"Rp","Oct":"Spalis","Nov":"Nr","Dec":"Gruodis","January":"Sausis","February":"Vasaris","March":"Kovas","April":"Balandis","June":"Birželis","July":"Liepa","August":"Rugpjūtis","September":"Rugsėjis","October":"Spalis","November":"Lapkritis","December":"Gruodis"},"Today":"Šiandien"},"lv":{"Weekdays":{"Sun":"Saule","Mon":"N","Tue":"Otr","Wed":"Tre","Thu":"Cet","Fri":"Pie","Sat":"Ses","Sunday":"Svētdiena","Monday":"Pirmdiena","Tuesday":"Otrdiena","Wednesday":"Trešdiena","Thursday":"Ceturtdiena","Friday":"Piektdiena","Saturday":"Sestdiena"},"Months":{"Jan":"Janvāris","Feb":"Febr","Mar":"Mar","Apr":"Apr","May":"Maijs","Jun":"Jūn","Jul":"Jūl","Aug":"Aug","Sep":"Sept","Oct":"Okt","Nov":"Nov","Dec":"Dec","January":"Janvāris","February":"Februāris","March":"Marts","April":"Aprīlis","June":"Jūnijs","July":"Jūlijs","August":"Augusts","September":"Septembris","October":"Oktobris","November":"Novembris","December":"Decembris"},"Today":"Šodien"},"ms":{"Weekdays":{"Sun":"Sun","Mon":"Mon","Tue":"Perancis","Wed":"♪","Thu":"Khaw","Fri":"Perancis","Sat":"♪","Sunday":"Ahad","Monday":"Isnin","Tuesday":"Selasa","Wednesday":"Rabu","Thursday":"Khamis","Friday":"Jumat","Saturday":"Sabtu"},"Months":{"Jan":"Jan","Feb":"Perancis","Mar":"Perancis","Apr":"Apr","May":"Mei","Jun":"Juni","Jul":"♪","Aug":"Aug","Sep":"Perancis","Oct":"Takh","Nov":"Nov","Dec":"Amerika","January":"Januari","February":"2010,","March":"2010,","April":"April","June":"Juni","July":"Juli","August":"Ogos","September":"Perancis","October":"Oktober","November":"November","December":"Amerika"},"Today":"Hari"},"nb":{"Weekdays":{"Sun":"Sun","Mon":"Mon","Tue":"Tue","Wed":"Wed","Thu":"Thu","Fri":"Fri","Sat":"Sat","Sunday":"Søndag","Monday":"Mandag","Tuesday":"Tirsdag","Wednesday":"Onsdag","Thursday":"Torsdag","Friday":"Fredag","Saturday":"Lørdag"},"Months":{"Jan":"Jan","Feb":"Feb","Mar":"Mar","Apr":"Apr","May":"Mai","Jun":"Jun","Jul":"Jul","Aug":"Aug","Sep":"Sep","Oct":"Okt","Nov":"Nov","Dec":"Dec","January":"Januar","February":"Februar","March":"Mars","April":"April","June":"Juni","July":"Juli","August":"August","September":"September","October":"Oktober","November":"November","December":"Desember"},"Today":"I"},"nl":{"Weekdays":{"Sun":"Zon","Mon":"Ma","Tue":"Di","Wed":"Wo","Thu":"Do","Fri":"Vr","Sat":"Zat","Sunday":"Zondag","Monday":"Maandag","Tuesday":"Dinsdag","Wednesday":"Woensdag","Thursday":"Donderdag","Friday":"Vrijdag","Saturday":"Zaterdag"},"Months":{"Jan":"Jan","Feb":"Feb","Mar":"Mar","Apr":"Apr","May":"Mei","Jun":"Juni","Jul":"Jul","Aug":"Aug","Sep":"Sep","Oct":"Okt","Nov":"Nov","Dec":"Dec","January":"Januari","February":"Februari","March":"Maart","April":"April","June":"Juni","July":"Juli","August":"Augustus","September":"September","October":"Oktober","November":"November","December":"December"},"Today":"Vandaag"},"pl":{"Weekdays":{"Sun":"Słońce","Mon":"Mon","Tue":"Wtyczka","Wed":"Środ","Thu":"Thu","Fri":"Fri","Sat":"Sat","Sunday":"Niedziela","Monday":"Poniedziałek","Tuesday":"Wtorek","Wednesday":"Środa","Thursday":"Czwartek","Friday":"Piątek","Saturday":"Sobota"},"Months":{"Jan":"Jan","Feb":"Luty","Mar":"Mar","Apr":"Kwiecień","May":"Maj","Jun":"Czerwiec","Jul":"Lipiec","Aug":"Sierpień","Sep":"Wrzesień","Oct":"Październik","Nov":"Nov","Dec":"Grudzień","January":"Styczeń","February":"Luty","March":"Marzec","April":"Kwiecień","June":"Czerwiec","July":"Lipiec","August":"Sierpień","September":"Wrzesień","October":"Październik","November":"Listopad","December":"Grudzień"},"Today":"Dzisiaj"},"pt":{"Weekdays":{"Sun":"Sol","Mon":"Monsenhor","Tue":"Tue","Wed":"Wed","Thu":"Tu","Fri":"Frio","Sat":"Satisfeito","Sunday":"Domingo","Monday":"Segunda-feira","Tuesday":"Terça-feira","Wednesday":"Quarta-feira","Thursday":"Quinta-feira","Friday":"Sexta-feira","Saturday":"Sábado"},"Months":{"Jan":"Jan","Feb":"Fev","Mar":"Mar","Apr":"Abr","May":"Maio","Jun":"Jun","Jul":"Jul","Aug":"A","Sep":"Sep","Oct":"O","Nov":"Não","Dec":"Dez","January":"Janeiro","February":"Fevereiro","March":"Março","April":"Abril","June":"Junho","July":"Julho","August":"Agosto","September":"Setembro","October":"Outubro","November":"Novembro","December":"Dezembro"},"Today":"Hoje"},"ro":{"Weekdays":{"Sun":"Soare","Mon":"Luni","Tue":"Tue","Wed":"Căsătorie","Thu":"Thu","Fri":"Vine","Sat":"Sat","Sunday":"Duminică","Monday":"Luni","Tuesday":"Marţi","Wednesday":"Miercuri","Thursday":"Joi","Friday":"Vineri","Saturday":"Sâmbătă"},"Months":{"Jan":"Jan","Feb":"Februarie","Mar":"Mar","Apr":"Apr","May":"May","Jun":"Jun","Jul":"Jul","Aug":"Aug","Sep":"Sep","Oct":"Oct","Nov":"Nov","Dec":"Dec","January":"Ianuarie","February":"Februarie","March":"Martie","April":"Aprilie","June":"Iunie","July":"Iulie","August":"August","September":"Septembrie","October":"Octombrie","November":"Noiembrie","December":"Decembrie"},"Today":"Astăzi"},"ru":{"Weekdays":{"Sun":"Солнце","Mon":"Мон","Tue":"Туи","Wed":"Свадьба","Thu":"Ту","Fri":"Фри","Sat":"Сидеть","Sunday":"Воскресенье","Monday":"Понедельник","Tuesday":"Вторник","Wednesday":"Среда","Thursday":"Четверг","Friday":"Пятница","Saturday":"Суббота"},"Months":{"Jan":"Ян","Feb":"Февраль","Mar":"Мар","Apr":"Апр","May":"Май","Jun":"Джун","Jul":"Джул","Aug":"Ауг","Sep":"Сеп","Oct":"Октября","Nov":"Ноябрь","Dec":"Декларация","January":"Январь","February":"Февраль","March":"Март","April":"Апрель","June":"Июнь","July":"Июль","August":"Август","September":"Сентябрь","October":"Октября","November":"Ноябрь","December":"Декабрь"},"Today":"Сегодня"},"sk":{"Weekdays":{"Sun":"Slnko","Mon":"Po","Tue":"Ut","Wed":"Str","Thu":"Št","Fri":"Pi","Sat":"So","Sunday":"Nedeľa","Monday":"Pondelok","Tuesday":"Utorok","Wednesday":"Streda","Thursday":"Štvrtok","Friday":"Piatok","Saturday":"Sobota"},"Months":{"Jan":"Jan","Feb":"Feb","Mar":"Mar","Apr":"Apríl","May":"Máj","Jun":"Jún","Jul":"Júl","Aug":"August","Sep":"Sep","Oct":"Okt","Nov":"Nov","Dec":"Dec","January":"Január","February":"Február","March":"Marec","April":"Apríl","June":"Jún","July":"Júl","August":"August","September":"September","October":"Október","November":"November","December":"December"},"Today":"Dnes"},"sl":{"Weekdays":{"Sun":"Sonce","Mon":"Naslednji","Tue":"Tor","Wed":"Sre","Thu":"Čet","Fri":"Fri","Sat":"Sob","Sunday":"Nedelja","Monday":"Ponedeljek","Tuesday":"Torek","Wednesday":"Sreda","Thursday":"Četrtek","Friday":"Petek","Saturday":"Sobota"},"Months":{"Jan":"Jan","Feb":"Feb","Mar":"Mar","Apr":"Apr","May":"Maj","Jun":"Jun","Jul":"Jul","Aug":"Avg","Sep":"Sep","Oct":"Okt","Nov":"Nov","Dec":"Dec","January":"Januar","February":"Februar","March":"Marec","April":"April","June":"Junij","July":"Julij","August":"Avgust","September":"September","October":"Oktober","November":"November","December":"December"},"Today":"Danes"},"sq":{"Weekdays":{"Sun":"Dielli","Mon":"Mon","Tue":"Tue","Wed":"Mer","Thu":"Tsu","Fri":"Pre","Sat":"Sat","Sunday":"E","Monday":"E","Tuesday":"E","Wednesday":"E","Thursday":"E","Friday":"E","Saturday":"E"},"Months":{"Jan":"Jan","Feb":"Fb","Mar":"Meri","Apr":"Për","May":"Maj","Jun":"Jun","Jul":"Jul","Aug":"Aug","Sep":"Sep","Oct":"Tetor","Nov":"Nov","Dec":"Dhjetor","January":"Janar","February":"Shkurt","March":"Mars","April":"Prill","June":"Qershor","July":"Korrik","August":"Gusht","September":"Shtator","October":"Tetor","November":"Nëntor","December":"Dhjetor"},"Today":"Sot"},"sv":{"Weekdays":{"Sun":"Sol","Mon":"Mon","Tue":"Tue","Wed":"Wed","Thu":"Thu","Fri":"Fri","Sat":"Sattar","Sunday":"Söndag","Monday":"Måndag","Tuesday":"Tisdag","Wednesday":"Onsdag","Thursday":"Torsdag","Friday":"Fredag","Saturday":"Lördag"},"Months":{"Jan":"Jan","Feb":"Feb","Mar":"Mar","Apr":"Apr","May":"Maj","Jun":"Jun","Jul":"Jul","Aug":"Aug","Sep":"Sep","Oct":"Okt","Nov":"Nov","Dec":"Dec","January":"Januari","February":"Februari","March":"Mars","April":"April","June":"Juni","July":"Juli","August":"Augusti","September":"September","October":"Oktober","November":"November","December":"December"},"Today":"Idag"},"th":{"Weekdays":{"Sun":"อาทิตย์","Mon":"นิ้ว","Tue":"Tue","Wed":"เว็บ","Thu":"ทู","Fri":"เนื้อ","Sat":"ที่นั่ง","Sunday":"อาทิตย์","Monday":"จันทร์","Tuesday":"อังคาร","Wednesday":"วันพุธ","Thursday":"พฤหัสบดี","Friday":"ศุกร์","Saturday":"เสาร์"},"Months":{"Jan":"ไม่นะ","Feb":"ก.","Mar":"ขนาด","Apr":"ขนาด","May":"พฤษภาคม","Jun":"จุน","Jul":"ก.","Aug":"อัก","Sep":"เซพ","Oct":"ตลับหมึก","Nov":"นอฟ","Dec":"ธ.","January":"มกราคม","February":"กุมภาพันธ์","March":"มีนาคม","April":"เมษายน","June":"มิถุนายน","July":"กรกฎาคม","August":"สิงหาคม","September":"กันยายน","October":"ตุลาคม","November":"พฤศจิกายน","December":"ธันวาคม"},"Today":"วันนี้"},"tl":{"Weekdays":{"Sun":"Araw","Mon":"Buwan","Tue":"Tue","Wed":"Damo","Thu":"Thu","Fri":"Kaibigan","Sat":"Sat","Sunday":"Linggo","Monday":"Lunes","Tuesday":"Martes","Wednesday":"Miyerkules","Thursday":"Huwebes","Friday":"Biyernes","Saturday":"Sabado"},"Months":{"Jan":"Jan","Feb":"Sanggol","Mar":"Mar","Apr":"Apr","May":"Mayo","Jun":"Jun","Jul":"Juul","Aug":"Ug","Sep":"Sep","Oct":"Oct","Nov":"Nov","Dec":"Pagpapasiya","January":"Enero","February":"Pebrero","March":"Marso","April":"Abril","June":"Hunyo","July":"Hulyo","August":"Agosto","September":"Setyembre","October":"Oktubre","November":"Nobyembre","December":"Disyembre"},"Today":"Ngayon"},"tr":{"Weekdays":{"Sun":"Güneş","Mon":"Mon","Tue":"Tue","Wed":"Wed","Thu":"Thu","Fri":"Fri","Sat":"Sat","Sunday":"Pazar","Monday":"Pazartesi","Tuesday":"Salı","Wednesday":"Çarşamba","Thursday":"Perşembe","Friday":"Cuma","Saturday":"Cumartesi"},"Months":{"Jan":"Jan","Feb":"Şubat","Mar":"Mar","Apr":"Apr","May":"Mayıs","Jun":"Jun","Jul":"Temmuz","Aug":"Ağu","Sep":"Eylül","Oct":"Ekim","Nov":"Kasım","Dec":"Aralık","January":"Ocak","February":"Şubat","March":"Mart","April":"Nisan","June":"Haziran","July":"Temmuz","August":"Ağustos","September":"Eylül","October":"Ekim","November":"Kasım","December":"Aralık"},"Today":"Bugün"},"uk":{"Weekdays":{"Sun":"Сонце","Mon":"Навігація","Tue":"Твитнуть","Wed":"Про","Thu":"Чорти","Fri":"П'ятниця","Sat":"Сонце","Sunday":"Неділя","Monday":"Понеділок","Tuesday":"П'ятниця","Wednesday":"Середа","Thursday":"Четвер","Friday":"П'ятниця","Saturday":"Субота"},"Months":{"Jan":"Мар","Feb":"Мар","Mar":"Мар","Apr":"Мар","May":"Травень","Jun":"Мар","Jul":"Мар","Aug":"Мар","Sep":"Мар","Oct":"Мар","Nov":"Мар","Dec":"Мар","January":"Січень","February":"Лютий","March":"Березень","April":"Квітень","June":"Червень","July":"Липень","August":"Серпень","September":"Вересень","October":"Жовтень","November":"Листопад","December":"Грудень"},"Today":"Сьогодні"},"ur":{"Weekdays":{"Sun":"سورج","Mon":"مون","Tue":"ٹو","Wed":"وے","Thu":"چو","Fri":"فری","Sat":"شطرنج","Sunday":"اتوار","Monday":"منگل","Tuesday":"منگل","Wednesday":"بدھ","Thursday":"جمعرات","Friday":"جمعہ","Saturday":"سبت"},"Months":{"Jan":"یان","Feb":"فیب","Mar":"مار","Apr":"پرنٹ","May":"مئی","Jun":"جون","Jul":"یول","Aug":"آغ","Sep":"سیپ","Oct":"پرنٹ","Nov":"ن","Dec":"سوال","January":"جنوری","February":"فروری","March":"مارچ","April":"اپریل","June":"جون","July":"جولائی","August":"اگست","September":"ستمبر","October":"اکتوبر","November":"نومبر","December":"دسمبر"},"Today":"آج"},"zh":{"Weekdays":{"Sun":"太阳","Mon":"月号","Tue":"图","Wed":"结婚","Thu":"图","Fri":"弗里语Name","Sat":"座位","Sunday":"礼拜","Monday":"星期一","Tuesday":"星期二","Wednesday":"星期三","Thursday":"星期四","Friday":"星期五","Saturday":"星期六(上午)"},"Months":{"Jan":"扬","Feb":"二月","Mar":"马来","Apr":"农历四月","May":"5月","Jun":"军","Jul":"朱尔","Aug":"奥格","Sep":"九月","Oct":"十月(简体)","Nov":"页:1","Dec":"12月(中文)","January":"页:1","February":"2月(半天会议)","March":"3月(半天会议)","April":"4月(半天会议)","June":"6月份","July":"7月(半天会议)","August":"8月(半天)","September":"9月(半天会议)","October":"10月(半天会议)","November":"11月(半天会议)","December":"12月(半天)"},"Today":"现在"},"zt":{"Weekdays":{"Sun":"太阳","Mon":"月","Tue":"二等分","Wed":"有婚","Thu":"三月","Fri":"弗里","Sat":"有","Sunday":"星期天","Monday":"星期一","Tuesday":"星期二","Wednesday":"星期三","Thursday":"星期四","Friday":"星期五","Saturday":"星期六"},"Months":{"Jan":"1月","Feb":"二月","Mar":"三月","Apr":"四月","May":"五月","Jun":"三月","Jul":"二月","Aug":"8月","Sep":"九月","Oct":"十月","Nov":"11月","Dec":"二月","January":"1月","February":"二月","March":"三月","April":"4月","June":"6月","July":"7月","August":"8月","September":"9月","October":"10月","November":"11月","December":"12月"},"Today":"今天"}}`, Ta = '{"en":{"Error":"Error","AutoComplete":{"NoResults":"No Results"}},"ar":{"Error":"الرعب","AutoComplete":{"NoResults":"لا نتائج"}},"az":{"Error":"Qeyd","AutoComplete":{"NoResults":"Qeydlər"}},"bg":{"Error":"Грешка","AutoComplete":{"NoResults":"Няма резултати"}},"bn":{"Error":"ত্রুটি","AutoComplete":{"NoResults":"কোনো ফলাফল পাওয়া যায়নি"}},"ca":{"Error":"Error","AutoComplete":{"NoResults":"Sense resultats"}},"cs":{"Error":"Chyba","AutoComplete":{"NoResults":"Žádné výsledky"}},"da":{"Error":"Fejl","AutoComplete":{"NoResults":"Ingen resultater"}},"de":{"Error":"Fehler","AutoComplete":{"NoResults":"Keine Ergebnisse"}},"el":{"Error":"Σφάλμα","AutoComplete":{"NoResults":"Χωρίς αποτελέσματα"}},"eo":{"Error":"Eraro","AutoComplete":{"NoResults":"Neniuj rezultoj"}},"es":{"Error":"Error","AutoComplete":{"NoResults":"No hay resultados"}},"et":{"Error":"Viga","AutoComplete":{"NoResults":"Tulemused puuduvad"}},"eu":{"Error":"Errorea","AutoComplete":{"NoResults":"Emaitzarik ez"}},"fa":{"Error":"خطای","AutoComplete":{"NoResults":"نتایج"}},"fi":{"Error":"Virhe","AutoComplete":{"NoResults":"Ei tuloksia"}},"fr":{"Error":"Erreur","AutoComplete":{"NoResults":"Aucun résultat"}},"ga":{"Error":"Amharc","AutoComplete":{"NoResults":"Gan a bheith ráite"}},"gl":{"Error":"Erro","AutoComplete":{"NoResults":"Sen resultados"}},"he":{"Error":"טעות","AutoComplete":{"NoResults":"לא תוצאות"}},"hi":{"Error":"त्रुटि","AutoComplete":{"NoResults":"परिणाम"}},"hu":{"Error":"Hiba","AutoComplete":{"NoResults":"Nincs eredmény"}},"id":{"Error":"Galat","AutoComplete":{"NoResults":"Tidak ada hasil"}},"it":{"Error":"Errore","AutoComplete":{"NoResults":"Nessun risultato"}},"ja":{"Error":"エラー","AutoComplete":{"NoResults":"結果なし"}},"ko":{"Error":"계정","AutoComplete":{"NoResults":"결과 없음"}},"lt":{"Error":"Klaida","AutoComplete":{"NoResults":"Nr rezultatai"}},"lv":{"Error":"Kļūda","AutoComplete":{"NoResults":"Nav rezultātu"}},"ms":{"Error":"Error","AutoComplete":{"NoResults":"Hasil No"}},"nb":{"Error":"Feil","AutoComplete":{"NoResults":"Ingen resultater"}},"nl":{"Error":"Fout","AutoComplete":{"NoResults":"Geen resultaten"}},"pl":{"Error":"Błąd","AutoComplete":{"NoResults":"Brak wyników"}},"pt":{"Error":"Erro","AutoComplete":{"NoResults":"Sem resultados"}},"ro":{"Error":"Eroare","AutoComplete":{"NoResults":"Niciun rezultat"}},"ru":{"Error":"Ошибка","AutoComplete":{"NoResults":"Нет результатов"}},"sk":{"Error":"Chyba","AutoComplete":{"NoResults":"Žiadne výsledky"}},"sl":{"Error":"Napaka","AutoComplete":{"NoResults":"Brez rezultatov"}},"sq":{"Error":"Gabim","AutoComplete":{"NoResults":"Asnjë rezultat"}},"sv":{"Error":"Fel","AutoComplete":{"NoResults":"Inga resultat"}},"th":{"Error":"ผิดพลาด","AutoComplete":{"NoResults":"ไม่มีผลลัพธ์"}},"tl":{"Error":"Pagkakamali","AutoComplete":{"NoResults":"Walang Resulta"}},"tr":{"Error":"Hata","AutoComplete":{"NoResults":"Sonuçlar yok"}},"uk":{"Error":"Помилка","AutoComplete":{"NoResults":"Немає результатів"}},"ur":{"Error":"خامی","AutoComplete":{"NoResults":"کوئی نتیجہ"}},"zh":{"Error":"错误","AutoComplete":{"NoResults":"无结果"}},"zt":{"Error":"錯誤","AutoComplete":{"NoResults":"沒有結果"}}}', Pa = '{"en":{"Done":"Done"},"ar":{"Done":"تم"},"az":{"Done":" Don"},"bg":{"Done":"Готово"},"bn":{"Done":"সম্পন্ন"},"ca":{"Done":"Fet"},"cs":{"Done":"Hotovo"},"da":{"Done":"Færdig"},"de":{"Done":"Fertig"},"el":{"Done":"Έγινε"},"eo":{"Done":"Done"},"es":{"Done":"Hecho"},"et":{"Done":"Tehtud"},"eu":{"Done":"Eginda"},"fa":{"Done":"انجام"},"fi":{"Done":"Tehty"},"fr":{"Done":"Fait"},"ga":{"Done":"Arna"},"gl":{"Done":"Feito"},"he":{"Done":"נעשה"},"hi":{"Done":"दान"},"hu":{"Done":"Kész"},"id":{"Done":"Selesai"},"it":{"Done":"Fatto"},"ja":{"Done":"ログイン"},"ko":{"Done":"한국어"},"lt":{"Done":"@"},"lv":{"Done":"Pabeigts"},"ms":{"Done":"Selesai"},"nb":{"Done":"Ferdig"},"nl":{"Done":"Klaar"},"pl":{"Done":"Gotowe"},"pt":{"Done":"Feito"},"ro":{"Done":"Gata"},"ru":{"Done":"Сделано"},"sk":{"Done":"Hotovo"},"sl":{"Done":"Končano"},"sq":{"Done":"U"},"sv":{"Done":"Done"},"th":{"Done":"เสร็จแล้ว"},"tl":{"Done":"Tapos"},"tr":{"Done":"Done"},"uk":{"Done":"Сонце"},"ur":{"Done":"بند"},"zh":{"Done":"完成"},"zt":{"Done":"完成"}}', xa = {
  Button: JSON.parse(Na),
  Filter: JSON.parse(Fa),
  Pagination: JSON.parse(wa),
  Date: JSON.parse(Oa),
  Form: JSON.parse(Ta),
  Wizard: JSON.parse(Pa)
}, L = (e, l) => {
  let t = e.split("."), a = xa[t[0]];
  const s = (l == null || l == null ? null : l.value) ?? "en";
  if (a !== void 0) {
    a[s] === void 0 ? a = a.en : a = a[s];
    let r = 1;
    for (; a !== void 0 && r < t.length; )
      a = a[t[r]], r++;
  }
  if (a === void 0)
    throw `unable to locate message ${e}`;
  return a;
}, Ca = /* @__PURE__ */ D({
  __name: "button-add",
  props: {
    disabled: { type: Boolean },
    size: {},
    hide_mobile: { type: Boolean },
    hide_tablet: { type: Boolean },
    hide_desktop: { type: Boolean },
    is_rounded: { type: Boolean }
  },
  emits: ["click"],
  setup(e, { emit: l }) {
    const t = l, a = Q(z), s = k(() => ({
      title: L("Button.Add", a),
      icon: "plus",
      type: X.primary
    }));
    return (r, n) => (o(), I(te, Y(s.value, {
      onClick: n[0] || (n[0] = (d) => t("click"))
    }), null, 16));
  }
}), Tt = /* @__PURE__ */ D({
  __name: "button-cancel",
  props: {
    disabled: { type: Boolean },
    size: {},
    hide_mobile: { type: Boolean },
    hide_tablet: { type: Boolean },
    hide_desktop: { type: Boolean },
    is_rounded: { type: Boolean }
  },
  emits: ["click"],
  setup(e, { emit: l }) {
    const t = l, a = Q(z), s = k(() => ({
      title: L("Button.Cancel", a),
      icon: "window-close",
      type: X.danger
    }));
    return (r, n) => (o(), I(te, Y(s.value, {
      onClick: n[0] || (n[0] = (d) => t("click"))
    }), null, 16));
  }
}), Ba = /* @__PURE__ */ D({
  __name: "button-delete",
  props: {
    disabled: { type: Boolean },
    size: {},
    hide_mobile: { type: Boolean },
    hide_tablet: { type: Boolean },
    hide_desktop: { type: Boolean },
    is_rounded: { type: Boolean }
  },
  emits: ["click"],
  setup(e, { emit: l }) {
    const t = l, a = Q(z), s = k(() => ({
      title: L("Button.Delete", a),
      icon: "trash-alt",
      type: X.danger
    }));
    return (r, n) => (o(), I(te, Y(s.value, {
      onClick: n[0] || (n[0] = (d) => t("click"))
    }), null, 16));
  }
}), Ea = /* @__PURE__ */ D({
  __name: "button-disable",
  props: {
    disabled: { type: Boolean },
    size: {},
    hide_mobile: { type: Boolean },
    hide_tablet: { type: Boolean },
    hide_desktop: { type: Boolean },
    is_rounded: { type: Boolean }
  },
  emits: ["click"],
  setup(e, { emit: l }) {
    const t = l, a = Q(z), s = k(() => ({
      title: L("Button.Disable", a),
      icon: "times-circle",
      type: X.danger
    }));
    return (r, n) => (o(), I(te, Y(s.value, {
      onClick: n[0] || (n[0] = (d) => t("click"))
    }), null, 16));
  }
}), za = /* @__PURE__ */ D({
  __name: "button-download",
  props: {
    disabled: { type: Boolean },
    size: {},
    hide_mobile: { type: Boolean },
    hide_tablet: { type: Boolean },
    hide_desktop: { type: Boolean },
    is_rounded: { type: Boolean }
  },
  emits: ["click"],
  setup(e, { emit: l }) {
    const t = l, a = Q(z), s = k(() => ({
      title: L("Button.Download", a),
      icon: "download",
      type: X.primary
    }));
    return (r, n) => (o(), I(te, Y(s.value, {
      onClick: n[0] || (n[0] = (d) => t("click"))
    }), null, 16));
  }
}), Ia = /* @__PURE__ */ D({
  __name: "button-edit",
  props: {
    disabled: { type: Boolean },
    size: {},
    hide_mobile: { type: Boolean },
    hide_tablet: { type: Boolean },
    hide_desktop: { type: Boolean },
    is_rounded: { type: Boolean }
  },
  emits: ["click"],
  setup(e, { emit: l }) {
    const t = l, a = Q(z), s = k(() => ({
      title: L("Button.Edit", a),
      icon: "edit",
      type: X.primary
    }));
    return (r, n) => (o(), I(te, Y(s.value, {
      onClick: n[0] || (n[0] = (d) => t("click"))
    }), null, 16));
  }
}), Ra = /* @__PURE__ */ D({
  __name: "button-enable",
  props: {
    disabled: { type: Boolean },
    size: {},
    hide_mobile: { type: Boolean },
    hide_tablet: { type: Boolean },
    hide_desktop: { type: Boolean },
    is_rounded: { type: Boolean }
  },
  emits: ["click"],
  setup(e, { emit: l }) {
    const t = l, a = Q(z), s = k(() => ({
      title: L("Button.Enable", a),
      icon: "check",
      type: X.primary
    }));
    return (r, n) => (o(), I(te, Y(s.value, {
      onClick: n[0] || (n[0] = (d) => t("click"))
    }), null, 16));
  }
}), Pt = /* @__PURE__ */ D({
  __name: "button-okay",
  props: {
    disabled: { type: Boolean },
    size: {},
    hide_mobile: { type: Boolean },
    hide_tablet: { type: Boolean },
    hide_desktop: { type: Boolean },
    is_rounded: { type: Boolean }
  },
  emits: ["click"],
  setup(e, { emit: l }) {
    const t = l, a = Q(z), s = k(() => ({
      title: L("Button.Okay", a),
      icon: "check",
      type: X.primary
    }));
    return (r, n) => (o(), I(te, Y(s.value, {
      onClick: n[0] || (n[0] = (d) => t("click"))
    }), null, 16));
  }
}), Wa = /* @__PURE__ */ D({
  __name: "button-print",
  props: {
    disabled: { type: Boolean },
    size: {},
    hide_mobile: { type: Boolean },
    hide_tablet: { type: Boolean },
    hide_desktop: { type: Boolean },
    is_rounded: { type: Boolean }
  },
  emits: ["click"],
  setup(e, { emit: l }) {
    const t = l, a = Q(z), s = k(() => ({
      title: L("Button.Print", a),
      icon: "print",
      type: X.primary
    }));
    return (r, n) => (o(), I(te, Y(s.value, {
      onClick: n[0] || (n[0] = (d) => t("click"))
    }), null, 16));
  }
}), xt = /* @__PURE__ */ D({
  __name: "button-refresh",
  props: {
    disabled: { type: Boolean },
    size: {},
    hide_mobile: { type: Boolean },
    hide_tablet: { type: Boolean },
    hide_desktop: { type: Boolean },
    is_rounded: { type: Boolean }
  },
  emits: ["click"],
  setup(e, { emit: l }) {
    const t = l, a = Q(z), s = k(() => ({
      title: L("Button.Refresh", a),
      icon: "sync",
      type: X.primary
    }));
    return (r, n) => (o(), I(te, Y(s.value, {
      onClick: n[0] || (n[0] = (d) => t("click"))
    }), null, 16));
  }
}), La = /* @__PURE__ */ D({
  __name: "button-save",
  props: {
    disabled: { type: Boolean },
    size: {},
    hide_mobile: { type: Boolean },
    hide_tablet: { type: Boolean },
    hide_desktop: { type: Boolean },
    is_rounded: { type: Boolean }
  },
  emits: ["click"],
  setup(e, { emit: l }) {
    const t = l, a = Q(z), s = k(() => ({
      title: L("Button.Save", a),
      icon: "save",
      type: X.primary
    }));
    return (r, n) => (o(), I(te, Y(s.value, {
      onClick: n[0] || (n[0] = (d) => t("click"))
    }), null, 16));
  }
}), Va = /* @__PURE__ */ D({
  __name: "button-upload",
  props: {
    disabled: { type: Boolean },
    size: {},
    hide_mobile: { type: Boolean },
    hide_tablet: { type: Boolean },
    hide_desktop: { type: Boolean },
    is_rounded: { type: Boolean }
  },
  emits: ["click"],
  setup(e, { emit: l }) {
    const t = l, a = Q(z), s = k(() => ({
      title: L("Button.Upload", a),
      icon: "upload",
      type: X.primary
    }));
    return (r, n) => (o(), I(te, Y(s.value, {
      onClick: n[0] || (n[0] = (d) => t("click"))
    }), null, 16));
  }
}), Ua = /* @__PURE__ */ D({
  __name: "buttons-container",
  props: {
    size: {},
    alignment: {}
  },
  setup(e) {
    const l = e;
    return (t, a) => (o(), i("div", {
      class: F(["buttons", l.size ? `are-${l.size}` : "", l.alignment ? `is-${l.alignment}` : ""])
    }, [
      P(t.$slots, "default")
    ], 2));
  }
}), ja = /* @__PURE__ */ D({
  __name: "check-mark",
  props: {
    checked: { type: Boolean, default: !0 },
    size: { default: re.normal }
  },
  setup(e) {
    const l = e;
    return (t, a) => (o(), I(K, {
      icon: `square-${l.checked ? "check" : "xmark"}`,
      size: l.size
    }, null, 8, ["icon", "size"]));
  }
}), Ga = { class: "dropdown-trigger" }, Ha = ["aria-controls"], Ka = { class: "icon is-small" }, Ya = ["id"], qa = { class: "dropdown-content" }, Za = {
  key: 0,
  class: "dropdown-divider"
}, Qa = { key: 0 }, Xa = /* @__PURE__ */ D({
  __name: "dropdown",
  props: {
    title: {},
    items: {},
    is_hoverable: { type: Boolean },
    is_right_align: { type: Boolean },
    drops_up: { type: Boolean }
  },
  setup(e) {
    const l = ht(), t = e, a = x(!1), s = k(() => {
      let u = ["dropdown"];
      return t.is_hoverable && u.push("is-hoverable"), t.is_right_align && u.push("is-right"), t.drops_up && u.push("is-up"), a.value && u.push("is-active"), u;
    }), r = k(() => {
      let u = oe(t.items);
      return Array.isArray(u) && (u = u.map((p) => Array.isArray(p) ? { children: p } : { children: [p] })), Array.isArray(u) ? u : [u];
    }), n = (u) => {
      let p = ["dropdown-item"];
      return typeof u != "string" && u.active && p.push("is-active"), p;
    }, d = (u) => {
      if (typeof u != "string")
        return u.href;
    }, c = (u) => {
      if (typeof u != "string") {
        a.value = !1;
        let p = u;
        p.onClick && p.onClick();
      }
    };
    return (u, p) => (o(), i("div", {
      class: F(s.value)
    }, [
      M("div", Ga, [
        M("button", {
          class: "button",
          "aria-haspopup": "true",
          "aria-controls": g(l),
          onClick: p[0] || (p[0] = (h) => a.value = !a.value)
        }, [
          M("span", null, T(t.title), 1),
          M("span", Ka, [
            C(K, {
              icon: "angle-down",
              "aria-hidden": "true"
            })
          ])
        ], 8, Ha)
      ]),
      M("div", {
        class: "dropdown-menu",
        id: g(l),
        role: "menu"
      }, [
        (o(!0), i(B, null, W(r.value, (h, _) => (o(), i("div", qa, [
          _ > 0 ? (o(), i("hr", Za)) : A("", !0),
          (o(!0), i(B, null, W(h.children, (m) => (o(), I(pe(typeof m == "string" ? "div" : "a"), {
            class: F(n(m)),
            href: d(m),
            onClick: (y) => c(m)
          }, {
            default: E(() => [
              typeof m == "string" ? (o(), i("p", Qa, T(m), 1)) : A("", !0),
              q(" " + T(typeof m == "string" ? null : m.title), 1)
            ]),
            _: 2
          }, 1032, ["class", "href", "onClick"]))), 256))
        ]))), 256))
      ], 8, Ya)
    ], 2));
  }
}), it = async (e, l, t) => {
  let a = await import(e);
  const s = Object.keys(a);
  return l && s.sort(l), s.filter((r) => t === void 0 || t.value === null || t.value.test(r)).map((r) => a[r]);
}, el = /* @__PURE__ */ D({
  __name: "dynamic-slot",
  props: {
    props: {},
    url: {},
    filter: {},
    sortMethod: { type: Function }
  },
  setup(e) {
    const l = x(null), t = e, a = k(() => t.filter == null || t.filter == null ? null : new RegExp("^" + t.filter.replaceAll(".", "\\.").replaceAll("*", ".+") + "$"));
    return j(() => [t.url, t.filter], async () => {
      l.value = await it(t.url, t.sortMethod, a);
    }), ce(async () => {
      l.value = await it(t.url, t.sortMethod, a);
    }), (s, r) => (o(!0), i(B, null, W(l.value, (n) => (o(), I(pe(n), Y({ ref_for: !0 }, t.props), null, 16))), 256));
  }
}), tl = { class: "field" }, al = { class: "control has-icons-left" }, ll = ["placeholder"], sl = { class: "icon is-small is-left" }, Ct = /* @__PURE__ */ D({
  __name: "filter",
  props: {
    default_value: {}
  },
  emits: ["filter"],
  setup(e, { emit: l }) {
    const t = e, a = l, s = Q(z), r = k(() => L("Filter.Filter", s)), n = x(null);
    j([n], (c) => {
      c[0] === "" && t.default_value && (n.value = t.default_value, a("filter", n.value == "" ? null : n.value));
    });
    const d = (c) => {
      c.keyCode == 13 && a("filter", n.value == "" ? null : n.value);
    };
    return ce(() => {
      t.default_value && (n.value = t.default_value);
    }), (c, u) => (o(), i("div", tl, [
      M("p", al, [
        H(M("input", {
          role: "searchbox",
          type: "text",
          class: "input is-expanded is-rounded",
          placeholder: r.value,
          "onUpdate:modelValue": u[0] || (u[0] = (p) => n.value = p),
          onKeypress: d
        }, null, 40, ll), [
          [De, n.value]
        ]),
        M("span", sl, [
          C(K, {
            icon: "filter",
            size: g(re).small
          }, null, 8, ["size"])
        ])
      ])
    ]));
  }
}), nl = {
  key: 0,
  class: "message-header"
}, rl = { class: "message-body" }, ol = /* @__PURE__ */ D({
  __name: "message",
  props: {
    type: { default: X.primary },
    message: { default: null },
    has_delete: { type: Boolean, default: !1 },
    title: { default: null },
    size: { default: Z.normal }
  },
  emits: ["close"],
  setup(e, { emit: l }) {
    const t = e, a = l, s = k(() => t.size === Z.normal ? null : `is-${t.size}`), r = k(() => `is-${t.type}`);
    return (n, d) => (o(), i("article", {
      class: F(["message", s.value, r.value])
    }, [
      t.title ? (o(), i("div", nl, [
        M("p", null, T(t.title), 1),
        t.has_delete ? (o(), i("button", {
          key: 0,
          class: "delete",
          "aria-label": "delete",
          onClick: d[0] || (d[0] = (c) => a("close"))
        })) : A("", !0)
      ])) : A("", !0),
      M("div", rl, [
        P(n.$slots, "default", {}, () => [
          q(T(t.message), 1)
        ])
      ])
    ], 2));
  }
}), he = /* @__PURE__ */ D({
  __name: "notification",
  props: {
    type: { default: ue.info },
    message: { default: null },
    light: { type: Boolean, default: !1 }
  },
  setup(e) {
    const l = e;
    return (t, a) => (o(), i("div", {
      class: F(["notification", "is-" + l.type, l.light ? "is-light" : ""])
    }, [
      P(t.$slots, "default", {}, () => [
        q(T(l.message), 1)
      ])
    ], 2));
  }
}), ul = {
  key: 0,
  class: "modal-background"
}, il = ["aria-label"], dl = {
  key: 0,
  class: "title"
}, cl = { class: "block" }, pl = /* @__PURE__ */ D({
  __name: "page-notification",
  props: {
    visible: { type: Boolean, default: !1 },
    type: { default: ue.info },
    message: {},
    header: {},
    block_user: { type: Boolean },
    has_close: { type: Boolean },
    is_light: { type: Boolean }
  },
  emits: ["close"],
  setup(e, { emit: l }) {
    const t = e, a = l, s = k(() => {
      switch (t.type) {
        case ue.info:
          return "circle-info";
        case ue.success:
          return "circle-check";
        case ue.danger:
          return "bug";
        case ue.warning:
          return "circle-exclamation";
      }
    }), r = k(() => {
      var n = ["is-page-notification-container", `is-${t.type}`];
      return t.is_light && n.push("is-light-mode"), t.has_close === void 0 || t.has_close === null || t.has_close || n.push("has-no-close"), n;
    });
    return (n, d) => (o(), i("div", {
      class: F({ modal: t.block_user && t.visible, "is-active": t.block_user && t.visible })
    }, [
      t.block_user && t.visible ? (o(), i("div", ul)) : A("", !0),
      C(Ot, {
        incoming: g(we).fadeIn,
        outgoing: g(we).fadeOut,
        speed: g(ge).slower
      }, {
        default: E(() => [
          t.visible ? (o(), i("div", {
            key: 0,
            class: F(r.value),
            role: "dialog",
            "aria-label": t.header ?? "Page Notification"
          }, [
            C(K, {
              icon: s.value,
              size: g(re).xxlarge
            }, null, 8, ["icon", "size"]),
            t.header !== null && t.header !== void 0 ? (o(), i("h1", dl, T(t.header), 1)) : A("", !0),
            M("div", cl, T(t.message), 1),
            t.has_close ? (o(), I(K, {
              key: 1,
              icon: "circle-xmark",
              onClick: d[0] || (d[0] = (c) => a("close")),
              size: g(re).large,
              role: "button",
              "aria-label": "close"
            }, null, 8, ["size"])) : A("", !0)
          ], 10, il)) : A("", !0)
        ]),
        _: 1
      }, 8, ["incoming", "outgoing", "speed"])
    ], 2));
  }
}), ml = ["title", "disabled"], hl = ["title", "disabled"], bl = {
  key: 0,
  class: "pagination-list"
}, vl = {
  key: 0,
  class: "pagination-ellipsis"
}, gl = ["aria-label", "onOnclick"], Bt = /* @__PURE__ */ D({
  __name: "pagination",
  props: {
    use_next: { type: Boolean, default: !0 },
    has_more: { type: Boolean, default: void 0 },
    has_previous: { type: Boolean, default: void 0 },
    size: { default: Z.small },
    rounded: { type: Boolean, default: !1 },
    button_type: {},
    total_pages: {},
    current_page: {},
    zero_page_index: { type: Boolean, default: !0 }
  },
  emits: ["moveForward", "moveBack", "goToPage"],
  setup(e, { emit: l }) {
    const t = e, a = l, s = Q(z), r = k(() => L(t.use_next ? "Pagination.Previous" : "Pagination.Older", s)), n = k(() => L(t.use_next ? "Pagination.Next" : "Pagination.Newer", s)), d = k(() => t.button_type ? `has-background-${t.button_type}` : ""), c = k(() => L("Pagination.GoToPage", s)), u = k(() => t.current_page === void 0 ? 0 : oe(t.current_page) + (t.zero_page_index ? 1 : 0)), p = k(() => (t.has_previous ?? !1) || u.value > 0), h = k(() => (t.has_more ?? !1) || u.value < (t.total_pages === void 0 ? 0 : oe(t.total_pages))), _ = k(() => {
      if (t.total_pages === void 0 || t.current_page === void 0)
        return [];
      if (oe(t.total_pages) > 5) {
        let v = Math.max(t.current_page === void 0 ? Math.floor(oe(t.total_pages) / 2) : u.value, 3);
        return oe(t.total_pages) - u.value === 0 ? v -= 2 : oe(t.total_pages) - u.value === 1 && v--, [
          1,
          -1,
          v - 1,
          v,
          v + 1,
          -1,
          oe(t.total_pages)
        ];
      } else {
        let v = [];
        for (let J = 1; J <= oe(t.total_pages); J++)
          v.push(J);
        return v;
      }
    }), m = function() {
      p && (t.current_page !== void 0 && t.current_page !== null ? a("goToPage", oe(t.current_page) - 1) : a("moveBack"));
    }, y = function() {
      h && (t.current_page !== void 0 && t.current_page !== null ? a("goToPage", oe(t.current_page) + 1) : a("moveForward"));
    }, b = function(v) {
      a("goToPage", t.zero_page_index ? v - 1 : v);
    };
    return (v, J) => H((o(), i("nav", {
      class: F(["pagination", "is-centered", d.value, `is-${t.size}`, t.rounded ? "is-rounded" : ""]),
      role: "navigation",
      "aria-label": "pagination"
    }, [
      M("a", {
        class: F(["pagination-previous", d.value]),
        title: r.value,
        onClick: m,
        disabled: p.value ? null : "disabled"
      }, [
        C(K, {
          icon: "backward",
          class: "mr-1",
          size: g(re).small
        }, null, 8, ["size"]),
        q(" " + T(r.value), 1)
      ], 10, ml),
      M("a", {
        class: F(["pagination-next", d.value]),
        title: n.value,
        onClick: y,
        disabled: h.value ? null : "disabled"
      }, [
        q(T(n.value) + " ", 1),
        C(K, {
          icon: "forward",
          class: "ml-1",
          size: g(re).small
        }, null, 8, ["size"])
      ], 10, hl),
      t.total_pages !== void 0 ? (o(), i("ul", bl, [
        (o(!0), i(B, null, W(_.value, (N) => (o(), i("li", null, [
          N === -1 ? (o(), i("span", vl, "…")) : (o(), i("a", {
            key: 1,
            class: F(["pagination-link", N === u.value ? "is-current" : ""]),
            "aria-label": `${c.value} ${N}`,
            onOnclick: (w) => b(N)
          }, T(N), 43, gl))
        ]))), 256))
      ])) : A("", !0)
    ], 2)), [
      [ne, p.value || h.value]
    ]);
  }
}), be = /* @__PURE__ */ D({
  __name: "Promised",
  props: {
    promise: {}
  },
  setup(e) {
    const l = e, t = x(null), a = Q(z), s = k(() => `${L("Form.Error", a)}: ${t.value.message ?? t.value.toString()}`), r = x(!1), n = x(!1), d = k(() => !r.value && !n.value), c = x(null);
    async function u(p) {
      if (r.value = !1, n.value = !1, t.value = null, p == null)
        c.value = null;
      else {
        let h = g(p);
        Object.prototype.toString.call(h) !== "[object Promise]" && (h = Promise.resolve(h));
        try {
          c.value = await h, n.value = !0;
        } catch (_) {
          t.value = _, r.value = !0;
        }
      }
    }
    return j(
      () => l.promise,
      () => {
        u(l.promise);
      }
    ), ce(() => {
      u(l.promise);
    }), (p, h) => (o(), i(B, null, [
      d.value ? P(p.$slots, "pending", { key: 0 }, () => [
        C(g(_e), {
          size: g(Z).small
        }, null, 8, ["size"])
      ]) : A("", !0),
      r.value ? P(p.$slots, "rejected", me(Y({ key: 1 }, t.value)), () => [
        C(g(he), {
          message: s.value,
          type: g(ue).danger
        }, null, 8, ["message", "type"])
      ]) : A("", !0),
      n.value ? P(p.$slots, "default", {
        key: 2,
        response: c.value
      }) : A("", !0)
    ], 64));
  }
}), yl = ["value", "max"], _e = /* @__PURE__ */ D({
  __name: "progress",
  props: {
    type: { default: X.primary },
    size: { default: Z.normal },
    value: {},
    maximum: {}
  },
  setup(e) {
    const l = e, t = k(() => l.maximum === void 0 ? null : (l.value ?? 0) / l.maximum * 100);
    return (a, s) => (o(), i("progress", {
      class: F(`progress is-${l.size} is-${l.type}`),
      value: l.value,
      max: l.maximum
    }, T(t.value ? `${t.value.toFixed(2)}%` : null), 11, yl));
  }
}), fl = {
  key: 0,
  class: "navbar-link"
}, _l = {
  key: 0,
  class: "icon-text"
}, kl = { class: "icon" }, Sl = { key: 1 }, Ml = {
  key: 0,
  class: "icon-text"
}, Dl = { class: "icon" }, $l = { key: 1 }, Al = {
  key: 2,
  class: "navbar-dropdown"
}, dt = /* @__PURE__ */ D({
  __name: "navbar-item",
  props: {
    title: {},
    active: { type: Boolean, default: !1 },
    icon: {},
    href: {},
    onClick: {},
    childItems: {}
  },
  emits: ["itemClicked"],
  setup(e, { emit: l }) {
    const t = e, a = () => {
      s("itemClicked"), t.onClick !== void 0 && t.onClick();
    }, s = l;
    return (r, n) => {
      const d = mt("navbar-item", !0);
      return o(), I(pe(t.childItems !== void 0 ? "div" : "a"), {
        class: F(["navbar-item", t.active ? "is-active" : "", t.childItems !== void 0 ? "has-dropdown is-hoverable" : ""]),
        href: t.href,
        onClick: a,
        tabIndex: t.href === void 0 || t.href === "" ? 0 : null
      }, {
        default: E(() => [
          t.childItems !== void 0 ? (o(), i("a", fl, [
            t.icon !== void 0 && t.icon !== null ? (o(), i("span", _l, [
              M("span", kl, [
                C(K, {
                  icon: t.icon
                }, null, 8, ["icon"])
              ]),
              M("span", null, T(t.title), 1)
            ])) : (o(), i("span", Sl, T(t.title), 1))
          ])) : (o(), i(B, { key: 1 }, [
            t.icon !== void 0 && t.icon !== null ? (o(), i("span", Ml, [
              M("span", Dl, [
                C(K, {
                  icon: t.icon
                }, null, 8, ["icon"])
              ]),
              M("span", null, T(t.title), 1)
            ])) : (o(), i("span", $l, T(t.title), 1))
          ], 64)),
          t.childItems !== void 0 ? (o(), i("div", Al, [
            (o(!0), i(B, null, W(t.childItems, (c) => (o(), I(d, Y({ ref_for: !0 }, c, {
              onItemClicked: n[0] || (n[0] = (u) => s("itemClicked"))
            }), null, 16))), 256))
          ])) : A("", !0)
        ]),
        _: 1
      }, 8, ["class", "href", "tabIndex"]);
    };
  }
}), Jl = ["aria-label"], Nl = { class: "navbar-brand" }, Fl = ["aria-expanded"], wl = {
  key: 0,
  class: "navbar-start"
}, Ol = { style: { width: "100px" } }, Tl = {
  key: 1,
  class: "navbar-end"
}, Pl = { style: { width: "100px" } }, xl = /* @__PURE__ */ D({
  __name: "navbar",
  props: {
    start_items: {},
    end_items: {},
    fixed_position: { default: null },
    ariaLabel: { default: "navigation" },
    color: {}
  },
  setup(e) {
    const l = e, t = x(!1);
    return ce(() => {
      if (l.fixed_position) {
        let a = "";
        switch (l.fixed_position) {
          case Te.top:
            a = "has-navbar-fixed-top";
            break;
          case Te.bottom:
            a = "has-navbar-fixed-bottom";
            break;
        }
        a !== "" && (document.body.classList.contains(a) || document.body.classList.add(a));
      }
    }), (a, s) => (o(), i("nav", {
      class: F(["navbar", l.fixed_position, l.color !== void 0 && l.color !== null ? `is-${l.color}` : ""]),
      role: "navigation",
      "aria-label": l.ariaLabel
    }, [
      M("div", Nl, [
        P(a.$slots, "brand"),
        M("a", {
          role: "button",
          class: F(["navbar-burger", t.value ? "is-active" : ""]),
          "aria-label": "menu",
          "aria-expanded": t.value ? "true" : "false",
          onClick: s[0] || (s[0] = (r) => t.value = !t.value)
        }, s[3] || (s[3] = [
          M("span", { "aria-hidden": "true" }, null, -1),
          M("span", { "aria-hidden": "true" }, null, -1),
          M("span", { "aria-hidden": "true" }, null, -1)
        ]), 10, Fl)
      ]),
      M("div", {
        class: F(["navbar-menu", t.value ? "is-active" : ""])
      }, [
        l.start_items !== void 0 ? (o(), i("div", wl, [
          C(be, {
            promise: l.start_items
          }, {
            default: E(({ response: r }) => [
              (o(!0), i(B, null, W(r, (n) => (o(), I(dt, Y({ ref_for: !0 }, n, {
                onItemClicked: s[1] || (s[1] = (d) => t.value = !1)
              }), null, 16))), 256))
            ]),
            pending: E(() => [
              M("div", Ol, [
                C(_e, {
                  size: g(Z).small
                }, null, 8, ["size"])
              ])
            ]),
            _: 1
          }, 8, ["promise"])
        ])) : A("", !0),
        l.end_items !== void 0 ? (o(), i("div", Tl, [
          C(be, {
            promise: l.end_items
          }, {
            default: E(({ response: r }) => [
              (o(!0), i(B, null, W(r, (n) => (o(), I(dt, Y({ ref_for: !0 }, n, {
                onItemClicked: s[2] || (s[2] = (d) => t.value = !1)
              }), null, 16))), 256))
            ]),
            pending: E(() => [
              M("div", Pl, [
                C(_e, {
                  size: g(Z).small
                }, null, 8, ["size"])
              ])
            ]),
            _: 1
          }, 8, ["promise"])
        ])) : A("", !0)
      ], 2)
    ], 10, Jl));
  }
}), Cl = /* @__PURE__ */ D({
  __name: "menu",
  props: {
    fixedPosition: {}
  },
  setup(e) {
    const l = e;
    return (t, a) => (o(), i("aside", {
      class: F(["menu", l.fixedPosition !== void 0 ? `is-fixed-menu is-fixed-menu-${l.fixedPosition}` : ""])
    }, [
      P(t.$slots, "default")
    ], 2));
  }
}), Bl = { class: "menu-label" }, El = /* @__PURE__ */ D({
  __name: "menu-label",
  props: {
    message: { default: "" }
  },
  setup(e) {
    const l = e;
    return (t, a) => (o(), i("p", Bl, [
      q(T(l.message) + " ", 1),
      P(t.$slots, "default")
    ]));
  }
}), zl = ["href"], Il = {
  key: 0,
  class: "icon-text"
}, Rl = { class: "icon" }, Wl = { key: 1 }, Et = /* @__PURE__ */ D({
  __name: "menu-entry",
  props: {
    title: {},
    active: { type: Boolean },
    icon: {},
    href: {},
    onClick: { type: Function }
  },
  setup(e) {
    const l = e, t = () => {
      l.onClick !== void 0 && l.onClick();
    };
    return (a, s) => (o(), i("li", null, [
      M("a", {
        href: l.href,
        onClick: s[0] || (s[0] = (r) => t()),
        class: F(l.active ? "is-active" : "")
      }, [
        l.icon !== void 0 && l.icon !== null ? (o(), i("span", Il, [
          M("span", Rl, [
            C(K, {
              icon: l.icon
            }, null, 8, ["icon"])
          ]),
          M("span", null, T(l.title), 1)
        ])) : (o(), i("span", Wl, T(l.title), 1)),
        P(a.$slots, "default")
      ], 10, zl),
      P(a.$slots, "children")
    ]));
  }
}), Ll = { class: "menu-list" }, Vl = /* @__PURE__ */ D({
  __name: "menu-list",
  props: {
    items: {}
  },
  setup(e) {
    const l = e;
    return (t, a) => {
      const s = mt("menu-list", !0);
      return o(), i("ul", Ll, [
        l.items !== null ? (o(), I(be, {
          key: 0,
          promise: l.items
        }, {
          default: E(({ response: r }) => [
            (o(!0), i(B, null, W(r, (n) => (o(), i("li", null, [
              C(Et, Y({ ref_for: !0 }, n), null, 16),
              n.childItems !== void 0 ? (o(), I(s, {
                key: 0,
                items: n.childItems
              }, null, 8, ["items"])) : A("", !0)
            ]))), 256))
          ]),
          pending: E(() => [
            M("li", null, [
              C(_e, {
                size: g(Z).small
              }, null, 8, ["size"])
            ])
          ]),
          _: 1
        }, 8, ["promise"])) : A("", !0),
        P(t.$slots, "default")
      ]);
    };
  }
}), Ul = /* @__PURE__ */ D({
  __name: "badge",
  props: {
    position: { default: Ze.topRight },
    text: {},
    type: {}
  },
  setup(e) {
    const l = e;
    return (t, a) => (o(), i("span", {
      class: F(["badge", `is-${l.position}`, l.type === void 0 ? "" : `is-${l.type}`])
    }, [
      q(T(l.text) + " ", 1),
      P(t.$slots, "default")
    ], 2));
  }
}), zt = /* @__PURE__ */ D({
  __name: "tooltip",
  props: {
    text: {},
    is: {},
    has_arrow: { type: Boolean, default: !1 },
    position: { default: Be.left },
    multiline: { type: Boolean, default: !1 },
    type: {},
    always_active: { type: Boolean, default: !1 },
    text_align: { default: Qe.left }
  },
  setup(e) {
    const l = e;
    return (t, a) => (o(), I(pe(l.is), {
      class: F([
        l.has_arrow ? "has-tooltop-arrow" : "",
        l.position ? `has-tooltip-${l.position}` : "",
        l.multiline ? "has-tooltip-multiline" : "",
        l.type ? `has-tooltip-${l.type}` : "",
        l.text_align ? `has-tooltip-text-${l.text_align}` : "",
        l.always_active ? "has-tooltip-active" : ""
      ]),
      "data-tooltip": t.text
    }, {
      default: E(() => [
        P(t.$slots, "default")
      ]),
      _: 3
    }, 8, ["class", "data-tooltip"]));
  }
}), jl = /* @__PURE__ */ D({
  __name: "tag",
  props: {
    type: { default: X.primary },
    light: { type: Boolean, default: !1 },
    rounded: { type: Boolean, default: !1 },
    size: { default: Z.normal },
    is_delete: { type: Boolean, default: !1 },
    text: {}
  },
  setup(e) {
    const l = e, t = k(() => {
      let a = ["tag", `is-${l.type}`, `is-${l.size}`];
      return l.light && a.push("is-light"), l.rounded && a.push("is-rounded"), l.is_delete && a.push("is-delete"), a;
    });
    return (a, s) => (o(), i("span", {
      class: F(t.value)
    }, [
      P(a.$slots, "default", {}, () => [
        q(T(l.text), 1)
      ])
    ], 2));
  }
}), Gl = /* @__PURE__ */ D({
  __name: "tags",
  props: {
    size: {},
    addons: { type: Boolean }
  },
  setup(e) {
    const l = e;
    return (t, a) => (o(), i("span", {
      class: F(["tags", l.size === null ? "" : "are-" + l.size, l.addons ? "has-addons" : ""])
    }, [
      P(t.$slots, "default")
    ], 2));
  }
}), Hl = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  Animation: Ot,
  Badge: Ul,
  Button: te,
  ButtonAdd: Ca,
  ButtonCancel: Tt,
  ButtonDelete: Ba,
  ButtonDisable: Ea,
  ButtonDownload: za,
  ButtonEdit: Ia,
  ButtonEnable: Ra,
  ButtonOkay: Pt,
  ButtonPrint: Wa,
  ButtonRefresh: xt,
  ButtonSave: La,
  ButtonUpload: Va,
  ButtonsContainer: Ua,
  CheckMark: ja,
  DropDown: Xa,
  DynamicSlot: el,
  Filter: Ct,
  Icon: K,
  Menu: Cl,
  MenuEntry: Et,
  MenuLabel: El,
  MenuList: Vl,
  Message: ol,
  NavBar: xl,
  Notification: he,
  PageNotification: pl,
  Pagination: Bt,
  Progress: _e,
  Promised: be,
  Tag: jl,
  Tags: Gl,
  ToolTip: zt
}, Symbol.toStringTag, { value: "Module" })), Kl = /* @__PURE__ */ D({
  __name: "draggable-item",
  props: {
    copy_data: { default: null },
    disabled: { type: Boolean, default: !1 },
    tag: { default: "div" },
    handle_search: {}
  },
  emits: ["started", "stopped"],
  setup(e, { emit: l }) {
    const t = l, a = e, s = x(!1), r = x(!1), n = x(null), d = k(() => (a.disabled ?? !1) || r.value && a.handle_search !== null), c = k(() => {
      let h = [];
      return d || h.push("has-cursor"), s.value ? h.push("is-move") : h.push("is-grab"), h;
    }), u = (h) => d.value ? (h.preventDefault(), !1) : (h.stopPropagation(), h.dataTransfer.setData("value", JSON.stringify(a.copy_data)), s.value = !0, t("started"), !0), p = () => {
      s.value = !1, r.value = !0, t("stopped");
    };
    return ce(() => {
      if (a.handle_search) {
        let h = n.value.querySelector(a.handle_search);
        h !== null && (r.value = !0, h.addEventListener("mousedown", () => r.value = !1), h.addEventListener("mouseup", () => r.value = !0));
      }
    }), (h, _) => (o(), I(pe(a.tag), {
      ref_key: "handle",
      ref: n,
      draggable: !0,
      onDragstart: u,
      onDragend: p,
      class: F(c.value)
    }, {
      default: E(() => [
        P(h.$slots, "default")
      ]),
      _: 3
    }, 40, ["class"]));
  }
}), Yl = /* @__PURE__ */ D({
  __name: "dropzone",
  props: {
    is_valid_child: { type: Function, default: (e) => !0 },
    tag: { default: "div" }
  },
  emits: ["itemAdded", "itemEntered", "itemExited", "itemMoved"],
  setup(e, { emit: l }) {
    const t = e, a = l, s = x(!1), r = x(null), n = x(null);
    k(() => t.tag ?? "div");
    const d = (_) => {
      const m = n.value.getBoundingClientRect(), y = {
        x: m.x + m.width / 2,
        y: m.y + m.height / 2
      };
      let b = se.center;
      return _.x < y.x ? _.y < y.y ? b = se.topLeft : b = se.bottomLeft : _.y < y.y ? b = se.topRight : b = se.bottomRight, r.value = b, r.value;
    }, c = (_) => {
      _.preventDefault(), s.value = !0, a("itemEntered", d(_));
    }, u = (_) => {
      s.value = !0, a("itemExited", d(_));
    }, p = (_) => {
      _.preventDefault(), a("itemMoved", d(_));
    }, h = (_) => {
      if (t.is_valid_child && !t.is_valid_child(JSON.parse(_.dataTransfer.getData("value"))))
        return !1;
      _.stopPropagation(), _.preventDefault(), a("itemAdded", JSON.parse(_.dataTransfer.getData("value")), r.value), s.value = !1;
    };
    return (_, m) => (o(), I(pe(t.tag), {
      ref_key: "handle",
      ref: n,
      class: F({ "is-bordered": s.value }),
      onDragenter: c,
      onDragleave: u,
      onDrop: h,
      onDragover: p
    }, {
      default: E(() => [
        P(_.$slots, "default")
      ]),
      _: 3
    }, 40, ["class"]));
  }
}), ql = ["onClick"], Zl = {
  key: 0,
  class: "icon"
}, It = /* @__PURE__ */ D({
  __name: "list",
  props: {
    numbered: { type: Boolean },
    items: {},
    type: {},
    compact: { type: Boolean },
    outlined: { type: Boolean },
    highlighted: { type: Boolean }
  },
  setup(e) {
    const l = e, t = ie(), a = k(() => {
      var n = ["block-list", "has-radius", `is-${l.type ?? "primary"}`];
      return l.compact && n.push("is-small"), l.outlined && n.push("is-outlined"), l.highlighted && n.push("is-highlighted"), n;
    }), s = k(() => l.items ? l.items.map((n, d) => ({
      name: n.name ?? `item-${d}`,
      classes: [
        n.type ? `is-${n.type}` : "",
        n.outlined ? "is-outlined" : "",
        n.highlighted ? "is-highlighted" : "",
        n.icon ? "has-icon" : "",
        n.onClick ? "is-clickable" : ""
      ],
      onClick: n.onClick,
      icon: n.icon
    })) : null), r = (n) => {
      n.onClick && n.onClick();
    };
    return (n, d) => (o(), I(pe(n.numbered == null || n.numbered == null || !n.numbered ? "ul" : "ol"), {
      class: F(a.value)
    }, {
      default: E(() => [
        s.value === null ? P(n.$slots, "default", { key: 0 }) : (o(!0), i(B, { key: 1 }, W(s.value, (c) => (o(), i(B, null, [
          g(t)[c.name] !== void 0 || g(t)[c.name] !== null || c.icon !== void 0 ? (o(), i("li", {
            key: 0,
            class: F(c.classes),
            onClick: (u) => r(c)
          }, [
            c.icon ? (o(), i("span", Zl, [
              C(K, {
                icon: c.icon
              }, null, 8, ["icon"])
            ])) : A("", !0),
            P(n.$slots, c.name)
          ], 10, ql)) : A("", !0)
        ], 64))), 256))
      ]),
      _: 3
    }, 8, ["class"]));
  }
}), Ql = ["onDragstart", "onDragover"], Xl = /* @__PURE__ */ D({
  __name: "sortable",
  props: {
    items: {},
    type: { default: X.primary },
    compact: { type: Boolean, default: !1 },
    outlined: { type: Boolean, default: !1 },
    highlighted: { type: Boolean, default: !1 }
  },
  emits: ["sorted"],
  setup(e, { emit: l }) {
    const t = e, a = l, s = x([]), r = x(-1), n = x(-1), d = x(null);
    j(t.items, (_, m) => {
      s.value = [...m];
    }), ce(() => {
      t.items !== null && (s.value = [...t.items]);
    });
    const c = (_) => {
      var m = _.target.getBoundingClientRect(), y = {
        x: m.x + m.width / 2,
        y: m.y + m.height / 2
      };
      let b = se.center;
      return _.y < y.y ? b = se.top : b = se.bottom, b;
    }, u = (_, m) => {
      m.stopPropagation(), r.value = _, m.dataTransfer.setData("value", null);
    }, p = (_, m) => {
      r.value && (m.stopPropagation(), _ != r.value ? (n.value = _, d.value = c(m)) : (n.value = -1, d.value = null));
    }, h = (_) => {
      if (r.value) {
        _.stopPropagation();
        var m = n.value + (d.value == se.top ? 0 : 1), y = s.value.splice(m, 1)[0];
        m >= r.value && m--, s.value.splice(m, 0, y), n.value = -1, d.value = null, r.value = -1, a("sorted", s.value);
      }
    };
    return (_, m) => (o(), I(It, {
      type: _.type,
      compact: _.compact,
      outlined: _.outlined,
      highlighted: _.highlighted,
      onDrop: h
    }, {
      default: E(() => [
        (o(!0), i(B, null, W(s.value, (y, b) => (o(), i(B, null, [
          H(M("li", null, [
            C(he, { light: !0 }, {
              default: E(() => m[1] || (m[1] = [
                q(" ")
              ])),
              _: 1
            })
          ], 512), [
            [ne, n.value === b && r.value !== b && d.value === g(se).top]
          ]),
          M("li", {
            draggable: "true",
            onDragstart: (v) => u(b, v),
            onDragend: m[0] || (m[0] = (v) => r.value = null),
            onDragover: (v) => p(b, v),
            class: F({ "has-cursor": !0, "is-move": n.value == b, "is-grab": n.value != b })
          }, [
            P(_.$slots, "item", {
              item: y,
              index: b
            })
          ], 42, Ql),
          H(M("li", null, [
            C(he, { light: !0 }, {
              default: E(() => m[2] || (m[2] = [
                q(" ")
              ])),
              _: 1
            })
          ], 512), [
            [ne, n.value === b && r.value !== b && d.value === g(se).bottom]
          ])
        ], 64))), 256))
      ]),
      _: 3
    }, 8, ["type", "compact", "outlined", "highlighted"]));
  }
}), es = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  DraggableItem: Kl,
  DropZone: Yl,
  Sortable: Xl
}, Symbol.toStringTag, { value: "Module" })), Ee = "HiddenFields", et = "DisabledFields", ts = (e) => e, de = (e, l) => {
  const t = l("Translate", ts);
  return k(() => e.translate ?? t);
};
function tt(e, l) {
  const t = l(Ee, ye(x([]))), a = l(et, ye(x([]))), s = k(() => t.value.filter((n) => n.indexOf(`${e}.`) === 0).map((n) => n.split(".")[1])), r = k(() => a.value.filter((n) => n.indexOf(`${e}.`) === 0).map((n) => n.split(".")[1]));
  return { hiddenValues: s, disabledValues: r };
}
async function at(e) {
  let l = null, t = e;
  e instanceof Function && (t = e()), t instanceof Promise ? l = t : l = Promise.resolve(t);
  let a = await l, s = [];
  return a.value !== void 0 ? s = a.value : s = a, s;
}
const as = { class: "tags has-addons" }, ls = { class: "tag is-link" }, ss = ["onClick"], ns = { key: 0 }, rs = ["placeholder"], os = { class: "dropdown-menu" }, us = { class: "dropdown-content" }, is = ["onClick"], ds = {
  key: 1,
  class: "dropdown-item"
}, Rt = /* @__PURE__ */ D({
  __name: "autocomplete",
  props: {
    title: {},
    limit: {},
    callbackurl: {},
    values: {},
    fetch: { type: Function },
    name: {},
    disabled: { type: Boolean },
    inputId: {},
    translate: { type: Function }
  },
  emits: ["valueChanged"],
  setup(e, { expose: l, emit: t }) {
    const a = Q(z), s = k(() => L("Form.AutoComplete.NoResults", a)), r = t, n = e, d = de(n, z), c = x([]), u = x(null), p = x(null), h = x(null), _ = x(null);
    j(u, async (f) => {
      if (f != null) {
        if (f.length >= 2)
          if (n.values != null && n.values != null) {
            let G = [];
            for (let S = 0; S < n.values.length && ((n.values[S].name.toUpperCase().indexOf(f.toUpperCase()) >= 0 || n.values[S].id.toUpperCase().indexOf(f.toUpperCase()) >= 0) && G.push(n.values[S]), G.length != 10); S++)
              ;
            p.value = G;
          } else {
            let S = await (await (n.fetch ?? fetch)(`${n.callbackurl}?q=${encodeURIComponent(f)}`)).json();
            S.length > 10 && S.splice(10, S.length - 10), p.value = S;
          }
      } else
        p.value = null, _.value.innerHTML = "";
    });
    const m = () => {
      if (c.value.length == 0)
        return null;
      const f = c.value.slice();
      return n.limit != null && n.limit == 1 ? f.length > 0 ? f[0] : null : f;
    }, y = async (f) => {
      if (f == null)
        c.value.length > 0 && c.value.splice(0, c.value.length), u.value = null;
      else {
        const G = await Promise.all(
          (Array.isArray(f) ? f : [f]).map(async (S) => {
            if (S.id !== void 0 && S.name !== void 0)
              return S;
            if (n.values != null && n.values != null)
              return S.id !== void 0 ? n.values.find((O) => O.id === S.id) : n.values.find((O) => O.name.toUpperCase() === S.toUpperCase() || O.id.toUpperCase() === S);
            {
              let V = await (await (n.fetch ?? fetch)(`${n.callbackurl}?${S.id === void 0 ? "q=" + encodeURIComponent(S) : "id=" + encodeURIComponent(S.id)}`)).json();
              return V.length > 0 ? (n.disabled && (V[0].readonly = !0), V[0]) : null;
            }
          })
        );
        c.value = G.filter((S) => S !== null), n.limit !== void 0 && n.limit !== null && c.value.length > n.limit && c.value.splice(n.limit), r("valueChanged", { name: n.name, value: m() });
      }
    }, b = (f) => {
      f.preventDefault(), u.value = f.clipboardData.getData("text/plain");
    }, v = (f) => {
      switch (f.key) {
        case "Backspace":
          u.value != null && u.value.length > 0 && (u.value = u.value.substring(0, u.value.length - 1));
          break;
        case "Enter":
        case "Shift":
          break;
        default:
          f.key.length == 1 && (u.value = (u.value == null ? "" : u.value) + f.key);
          break;
      }
    }, J = () => {
      u.value = null;
    }, N = () => {
      _.value.focus();
    }, w = (f) => {
      c.value.push(f), J(), r("valueChanged", { name: n.name, value: m() });
    }, U = (f) => {
      c.value.splice(f, 1), N(), r("valueChanged", { name: n.name, value: m() });
    };
    return l({
      /**
       * Gets the current value 
       */
      getValue: m,
      /**
       * Sets the current value
       * 
       * @param value AutoCompleteItem|AutoCompleteItem[]|string[]|null
       * @returns Promise<void>
       */
      setValue: y
    }), (f, G) => (o(), i("div", {
      class: "control autocomplete",
      onBlur: J,
      onClick: N
    }, [
      M("div", {
        class: F(["tagsfield", "field", "input", "is-grouped", "is-grouped-multiline", n.disabled ? "is-disabled" : ""])
      }, [
        (o(!0), i(B, null, W(c.value, (S, O) => (o(), i("div", {
          class: "control",
          key: O
        }, [
          M("div", as, [
            M("a", ls, T(g(d)(S.name)), 1),
            !S.readonly && !n.disabled ? (o(), i("a", {
              key: 0,
              class: "tag is-delete",
              onClick: (V) => U(O)
            }, null, 8, ss)) : A("", !0)
          ])
        ]))), 128)),
        n.disabled ? A("", !0) : (o(), i("div", ns, [
          H(M("span", {
            ref_key: "contentSpan",
            ref: _,
            placeholder: g(d)(n.title ?? ""),
            contenteditable: "",
            class: F(h.value),
            onFocus: G[0] || (G[0] = (S) => {
              h.value = "is-focused";
            }),
            onBlur: G[1] || (G[1] = (S) => {
              h.value = null;
            }),
            onKeydown: v,
            onPaste: b
          }, null, 42, rs), [
            [ne, n.limit === void 0 || n.limit === null || c.value.length < n.limit]
          ])
        ]))
      ], 2),
      n.disabled ? A("", !0) : (o(), i("div", {
        key: 0,
        class: F(["dropdown", { "is-active": p.value != null && u.value != null && u.value != "" }])
      }, [
        M("div", os, [
          M("div", us, [
            p.value != null && p.value.length > 0 ? (o(!0), i(B, { key: 0 }, W(p.value, (S) => (o(), i("a", {
              class: "dropdown-item",
              onClick: (O) => w(S)
            }, T(g(d)(S.name)), 9, is))), 256)) : (o(), i("a", ds, T(s.value), 1))
          ])
        ])
      ], 2))
    ], 32));
  }
}), Le = /* @__PURE__ */ D({
  __name: "button",
  props: {
    label: {},
    sstyle: {},
    icon: {},
    name: {},
    disabled: { type: Boolean },
    inputId: {},
    translate: { type: Function }
  },
  emits: ["buttonClicked"],
  setup(e, { emit: l }) {
    const t = e, a = l, s = de(t, z);
    return (r, n) => (o(), I(te, {
      type: t.sstyle,
      icon: t.icon,
      title: g(s)(t.label ?? ""),
      onClick: n[0] || (n[0] = (d) => a("buttonClicked", t.name)),
      disabled: t.disabled
    }, null, 8, ["type", "icon", "title", "disabled"]));
  }
}), cs = ["for"], ps = ["value", "disabled", "id"], Wt = /* @__PURE__ */ D({
  __name: "checkbox-group",
  props: {
    values: { type: [Array, Promise, Function, null] },
    name: {},
    disabled: { type: Boolean },
    inputId: {},
    translate: { type: Function }
  },
  emits: ["valueChanged"],
  setup(e, { expose: l, emit: t }) {
    const a = e, s = Q(z), r = k(() => L("Form.Error", s)), n = t, d = de(a, z), c = x([]), u = x(!1), p = k(async () => {
      if (a.values === null)
        return [];
      {
        let b = await at(a.values), v = b.filter((J) => J.selected).map((J) => J.value);
        return c.value === null || c.value.length == 0 ? c.value = v.length > 0 ? [...v] : [] : (v = c.value, b = b.map((J) => ({
          label: J.label,
          value: J.value,
          selected: v.some((N) => N === J.value)
        }))), b;
      }
    });
    j(c, (b) => {
      n("valueChanged", { name: a.name, value: h() });
    });
    const h = () => c.value.length == 0 ? null : c.value, _ = (b) => {
      u.value = !0, c.value.splice(0), b !== null && (c.value = [...b]), u.value = !1, n("valueChanged", { name: a.name, value: h() });
    }, { hiddenValues: m, disabledValues: y } = tt(a.name, z);
    return l({
      /**
       * Gets the current value 
       */
      getValue: h,
      /**
       * Sets the current value
       * 
       * @param value any[]|null
       * @returns void
       */
      setValue: _
    }), (b, v) => (o(), i("div", null, [
      C(be, { promise: p.value }, {
        default: E(({ response: J }) => [
          J !== null ? (o(!0), i(B, { key: 0 }, W(J, (N, w) => H((o(), i("label", {
            class: "checkbox is-block",
            for: `${a.inputId}-${w}`
          }, [
            H(M("input", {
              type: "checkbox",
              class: "checkbox",
              value: N.value,
              "onUpdate:modelValue": v[0] || (v[0] = (U) => c.value = U),
              disabled: a.disabled || g(y).some((U) => U === N.value.toString()),
              id: `${a.inputId}-${w}`
            }, null, 8, ps), [
              [je, c.value]
            ]),
            q(" " + T(g(d)(N.label)), 1)
          ], 8, cs)), [
            [ne, !g(m).some((U) => U === N.value.toString())]
          ])), 256)) : A("", !0)
        ]),
        rejected: E(() => [
          C(g(he), {
            type: g(ue).danger,
            message: r.value
          }, null, 8, ["type", "message"])
        ]),
        _: 1
      }, 8, ["promise"])
    ]));
  }
}), ms = ["for"], hs = ["name", "disabled", "id"], bs = {
  key: 0,
  class: "help is-danger"
}, Lt = /* @__PURE__ */ D({
  __name: "checkbox",
  props: {
    label: {},
    required: { type: Boolean, default: !1 },
    name: {},
    disabled: { type: Boolean, default: !1 },
    inputId: {},
    translate: {}
  },
  emits: ["valueChanged"],
  setup(e, { expose: l, emit: t }) {
    const a = e, s = t, r = de(a, z), n = k(() => r.value(a.label)), d = x(!1);
    return j(d, (p) => s("valueChanged", { name: a.name, value: p })), l({
      /**
       * Gets the current value 
       */
      getValue: () => d.value,
      /**
       * Sets the current value
       * 
       * @param value boolean
       * @returns void
       */
      setValue: (p) => {
        d.value = p;
      }
    }), (p, h) => (o(), i("label", {
      class: "checkbox",
      for: a.inputId
    }, [
      H(M("input", {
        type: "checkbox",
        class: "checkbox",
        name: a.name,
        disabled: a.disabled,
        "onUpdate:modelValue": h[0] || (h[0] = (_) => d.value = _),
        id: a.inputId
      }, null, 8, hs), [
        [je, d.value]
      ]),
      q(" " + T(n.value) + " ", 1),
      a.required ? (o(), i("span", bs, "*")) : A("", !0)
    ], 8, ms));
  }
}), We = (e, l) => {
  let t = new Date(e);
  return t.setDate(e.getDate() + l), t;
}, ee = (e, l, t) => {
  let a = e;
  for (; a.length < t; )
    a = l + a;
  return a;
}, Je = (e, l, t) => {
  let a = "";
  switch (e) {
    case "d":
    case "dd":
      a += `${ee(t.getDate().toString(), "0", e.length)}`;
      break;
    case "ddd":
    case "dddd":
      let r = "";
      switch (t.getDay()) {
        case 0:
          r = "Sunday";
          break;
        case 1:
          r = "Monday";
          break;
        case 2:
          r = "Tuesday";
          break;
        case 3:
          r = "Wednesday";
          break;
        case 4:
          r = "Thursday";
          break;
        case 5:
          r = "Friday";
          break;
        case 6:
          r = "Saturday";
          break;
      }
      a += `${L("Date.Weekdays." + (e.length > 3 ? r : r.substring(0, 3)), l)}`;
      break;
    case "f":
    case "ff":
    case "fff":
      a += `${ee(t.getMilliseconds().toString(), "0", e.length)}`;
      break;
    case "F":
    case "FF":
    case "FFF":
      a += `${t.getMilliseconds() == 0 ? "" : ee(t.getMilliseconds().toString(), "0", e.length)}`;
      break;
    case "g":
    case "gg":
      a += "A.D.";
      break;
    case "h":
    case "hh":
      a += `${ee((t.getHours() > 12 ? t.getHours() - 12 : t.getHours() == 0 ? 12 : t.getHours()).toString(), "0", e.length)}`;
      break;
    case "H":
    case "HH":
      a += `${ee(t.getHours().toString(), "0", e.length)}`;
      break;
    case "K":
    case "z":
    case "zz":
    case "zzz":
      let n = t.getTimezoneOffset() * -1, d = parseInt((n / 60).toFixed(0)), c = n - Math.abs(d) * 60;
      switch (e) {
        case "K":
        case "zzz":
          a += `${d < 0 ? "-" : "+"}${ee(Math.abs(d).toString(), "0", 2) + ":" + ee(Math.abs(c).toString(), "0", 2)}`;
          break;
        case "z":
        case "zz":
          a += `${d < 0 ? "-" : "+"}${ee(Math.abs(d).toString(), "0", e.length)}`;
          break;
      }
      break;
    case "m":
    case "mm":
      a += `${ee(t.getMinutes().toString(), "0", e.length)}`;
      break;
    case "M":
    case "MM":
      a += `${ee((t.getMonth() + 1).toString(), "0", e.length)}`;
      break;
    case "MMM":
    case "MMMM":
      let u = "";
      switch (t.getMonth()) {
        case 0:
          u = "January";
          break;
        case 1:
          u = "February";
          break;
        case 2:
          u = "March";
          break;
        case 3:
          u = "April";
          break;
        case 4:
          u = "May";
          break;
        case 5:
          u = "June";
          break;
        case 6:
          u = "July";
          break;
        case 7:
          u = "August";
          break;
        case 8:
          u = "September";
          break;
        case 9:
          u = "October";
          break;
        case 10:
          u = "November";
          break;
        case 11:
          u = "December";
          break;
      }
      a += `${L("Date.Months." + (e.length > 3 ? u : u.substring(0, 3)), l)}`;
      break;
    case "s":
    case "ss":
      a += `${ee(t.getSeconds().toString(), "0", e.length)}`;
      break;
    case "t":
    case "tt":
      t.getHours() >= 12 ? a += `${e.length == 1 ? "P" : "PM"}` : a += `${e.length == 1 ? "A" : "AM"}`;
      break;
    case "y":
    case "yy":
      for (var s = t.getFullYear().toString(); s.length > 2; )
        s = s.substring(1);
      a += `${ee(s.toString(), "0", e.length)}`;
      break;
    case "yyy":
    case "yyyy":
    case "yyyyy":
      a += `${ee(t.getFullYear().toString(), "0", e.length)}`;
      break;
    default:
      a += `[UNKOWN FORMAT ${e}]`;
      break;
  }
  return a;
}, ke = (e, l, t) => {
  t = t ?? "ddd MMM dd yyyy HH:mm:ss G\\MTzz00", l = l ?? k(() => "en");
  let a = "", s = "";
  for (var r = 0; r < t.length; r++)
    switch (t.charAt(r)) {
      case "\\":
        s != "" && (a += Je(s, l, e), s = ""), a += t.charAt(r + 1), r++;
        break;
      case "d":
      case "f":
      case "F":
      case "g":
      case "h":
      case "H":
      case "K":
      case "m":
      case "M":
      case "s":
      case "t":
      case "y":
      case "z":
        s != "" && s.charAt(0) != t.charAt(r) ? (a += Je(s, l, e), s = "") : s += t.charAt(r);
        break;
      default:
        s != "" && (a += Je(s, l, e), s = ""), a += t.charAt(r);
        break;
    }
  return s != "" && (a += Je(s, l, e), s = ""), a;
}, vs = { class: "control" }, gs = ["name", "id", "disabled"], ct = RegExp("^(\\d{2}):(\\d{2}) (AM|PM)$"), lt = /* @__PURE__ */ D({
  __name: "time",
  props: {
    name: {},
    disabled: { type: Boolean },
    inputId: {}
  },
  emits: ["valueChanged"],
  setup(e, { expose: l, emit: t }) {
    const a = e, s = t, r = x(null), n = k(() => {
      if (r.value === null || r.value === "")
        return null;
      var u = Number(r.value.substring(3, 5)), p = Number(r.value.substring(0, 2)) % 12 + u / 60;
      return {
        backgroundImage: `url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='40' height='40'><circle cx='20' cy='20' r='18.5' fill='none' stroke='%23222' stroke-width='3' /><path d='M20,4 20,8 M4,20 8,20 M36,20 32,20 M20,36 20,32' stroke='%23bbb' stroke-width='1' /><circle cx='20' cy='20' r='2' fill='%23222' stroke='%23222' stroke-width='2' /></svg>"), url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='40' height='40'><path d='M18.5,24.5 19.5,4 20.5,4 21.5,24.5 Z' fill='%23222' style='transform:rotate(${360 * u / 60}deg); transform-origin: 50% 50%;' /></svg>"), url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='40' height='40'><path d='M18.5,24.5 19.5,8.5 20.5,8.5 21.5,24.5 Z' style='transform:rotate(${360 * p / 12}deg); transform-origin: 50% 50%;' /></svg>")`
      };
    });
    return j(r, (u) => {
      s("valueChanged", { name: a.name, value: u });
    }), l({
      /**
       * Gets the current value 
       */
      getValue: () => r.value,
      /**
       * Sets the current value
       * 
       * @param value string|null
       * @returns void
       */
      setValue: (u) => {
        if (u === "")
          u = null;
        else if (u !== null && ct.test(u)) {
          var p = ct.exec(u);
          u = `${p[3] === "AM" ? p[1] : (parseInt(p[1]) + 12).toFixed(0)}:${p[2]}:00`;
        }
        r.value = u;
      }
    }), (u, p) => (o(), i("div", vs, [
      H(M("input", {
        class: "input is-time",
        name: a.inputId,
        id: a.name,
        type: "time",
        "onUpdate:modelValue": p[0] || (p[0] = (h) => r.value = h),
        disabled: a.disabled,
        style: Ae(n.value)
      }, null, 12, gs), [
        [De, r.value]
      ])
    ]));
  }
}), ys = { class: "hero-body" }, fs = { class: "title" }, _s = {
  key: 0,
  class: "subtitle"
}, ks = /* @__PURE__ */ D({
  __name: "banner",
  props: {
    type: {},
    title: {},
    subtitle: {}
  },
  setup(e) {
    const l = e;
    return (t, a) => (o(), i("section", {
      class: F(["hero", "is-small", "has-text-centered", t.type == null ? "" : "is-" + l.type])
    }, [
      M("div", ys, [
        M("p", fs, T(l.title), 1),
        l.subtitle ? (o(), i("p", _s, T(l.subtitle), 1)) : A("", !0)
      ])
    ], 2));
  }
}), Ss = { class: "box" }, Vt = /* @__PURE__ */ D({
  __name: "box",
  setup(e) {
    return (l, t) => (o(), i("div", Ss, [
      P(l.$slots, "default")
    ]));
  }
}), Ms = { key: 0 }, Ds = ["onClick"], $s = /* @__PURE__ */ D({
  __name: "breadcrumbs",
  props: {
    breadCrumbs: {},
    alignment: { default: Oe.left },
    size: { default: Z.normal },
    seperator: {}
  },
  setup(e) {
    const l = e, t = k(() => {
      let s = ["breadcrumb"];
      return l.alignment && l.alignment !== Oe.left && s.push(`is-${l.alignment}`), l.size && l.size !== Z.normal && s.push(`is-${l.size}`), l.seperator && s.push(`has-${l.seperator}-seperator`), s;
    }), a = (s) => {
      s !== void 0 && s();
    };
    return (s, r) => (o(), i("nav", {
      class: F(t.value),
      "aria-label": "breadcrumbs"
    }, [
      l.breadCrumbs !== null ? (o(), i("ul", Ms, [
        (o(!0), i(B, null, W(l.breadCrumbs, (n) => (o(), i("li", {
          class: F({ "is-active": n.active })
        }, [
          M("a", {
            onClick: (d) => a(n.onClick)
          }, [
            n.icon ? (o(), i("span", {
              key: 0,
              class: F(["icon", n.onClick ? "is-clickable" : ""])
            }, [
              C(g(K), {
                icon: n.icon
              }, null, 8, ["icon"])
            ], 2)) : A("", !0),
            q(" " + T(n.title), 1)
          ], 8, Ds)
        ], 2))), 256))
      ])) : A("", !0)
    ], 2));
  }
}), As = {
  key: 0,
  class: "card-icon"
}, Js = { class: "card-icon-wrapper" }, Ns = {
  key: 1,
  class: "card-header"
}, Fs = {
  key: 2,
  class: "card-content"
}, ws = {
  key: 3,
  class: "card-footer"
}, Ut = /* @__PURE__ */ D({
  __name: "card",
  props: {
    full_width: { type: Boolean, default: !1 },
    full_height: { type: Boolean, default: !1 },
    icon: {}
  },
  setup(e) {
    const l = ie(), t = e, a = {
      addon_class: "card-footer-item"
    }, s = {
      header_class: "card-header-title has-text-centered",
      addon_class: "card-header-icon"
    };
    return (r, n) => (o(), i("div", {
      class: F(["card", { "is-fullwidth": t.full_width, "is-fullheight": t.full_height }])
    }, [
      t.icon ? (o(), i("div", As, [
        M("div", Js, [
          C(K, {
            icon: t.icon,
            size: g(re).xxlarge
          }, null, 8, ["icon", "size"])
        ])
      ])) : A("", !0),
      g(l).header ? (o(), i("div", Ns, [
        P(r.$slots, "header", me(fe(s)))
      ])) : A("", !0),
      g(l).content ? (o(), i("div", Fs, [
        P(r.$slots, "content")
      ])) : A("", !0),
      g(l).footer ? (o(), i("div", ws, [
        P(r.$slots, "footer", me(fe(a)))
      ])) : A("", !0)
    ], 2));
  }
}), st = /* @__PURE__ */ D({
  __name: "column-container",
  props: {
    modifiers: {},
    columns: {}
  },
  setup(e) {
    const l = ie(), t = e, a = k(() => {
      let r = ["columns"];
      return t.modifiers !== void 0 && t.modifiers !== null && (r = r.concat(t.modifiers.map((n) => `is-${n}`))), r;
    }), s = k(() => t.columns.map((r, n) => {
      let d = [
        "column",
        r.class ?? "",
        r.size ? `is-${r.size}` : "",
        r.offset ? `is-offset-${r.offset}` : ""
      ];
      return r.border && (r.border.some((c) => c === Ye.all) ? d.push("is-bordered") : r.border.forEach((c) => d.push(`is-bordered-${c}`))), {
        name: r.name ?? `col-${n}`,
        class: d
      };
    }));
    return (r, n) => (o(), i("div", {
      class: F(a.value)
    }, [
      (o(!0), i(B, null, W(s.value, (d) => (o(), i(B, null, [
        g(l)[d.name] ? (o(), i("div", {
          key: 0,
          class: F(d.class)
        }, [
          P(r.$slots, d.name)
        ], 2)) : A("", !0)
      ], 64))), 256))
    ], 2));
  }
}), Os = { class: "footer" }, Ts = /* @__PURE__ */ D({
  __name: "footer",
  setup(e) {
    return (l, t) => (o(), i("footer", Os, [
      P(l.$slots, "default")
    ]));
  }
}), Ps = { class: "level" }, xs = {
  key: 0,
  class: "level-left"
}, Cs = {
  key: 0,
  class: "level-item"
}, Bs = {
  key: 0,
  class: "level-item"
}, Es = {
  key: 2,
  class: "level-right"
}, zs = {
  key: 0,
  class: "level-item"
}, Is = /* @__PURE__ */ D({
  __name: "level",
  props: {
    left_slots: {},
    right_slots: {},
    slots: {}
  },
  setup(e) {
    const l = e, t = ie();
    return (a, s) => (o(), i("nav", Ps, [
      l.left_slots ? (o(), i("div", xs, [
        (o(!0), i(B, null, W(l.left_slots, (r) => (o(), i(B, null, [
          g(t)[r] ? (o(), i("div", Cs, [
            P(a.$slots, r)
          ])) : A("", !0)
        ], 64))), 256))
      ])) : A("", !0),
      l.slots ? (o(!0), i(B, { key: 1 }, W(l.slots, (r) => (o(), i(B, null, [
        g(t)[r] ? (o(), i("div", Bs, [
          P(a.$slots, r)
        ])) : A("", !0)
      ], 64))), 256)) : A("", !0),
      l.right_slots ? (o(), i("div", Es, [
        (o(!0), i(B, null, W(l.right_slots, (r) => (o(), i(B, null, [
          g(t)[r] ? (o(), i("div", zs, [
            P(a.$slots, r)
          ])) : A("", !0)
        ], 64))), 256))
      ])) : A("", !0)
    ]));
  }
}), Rs = { class: "media" }, Ws = {
  key: 0,
  class: "media-left"
}, Ls = { class: "media-content" }, Vs = {
  key: 1,
  class: "media-right"
}, Us = /* @__PURE__ */ D({
  __name: "media",
  setup(e) {
    const l = ie();
    return (t, a) => (o(), i("article", Rs, [
      g(l).left_figure ? (o(), i("figure", Ws, [
        P(t.$slots, "left_figure")
      ])) : A("", !0),
      M("div", Ls, [
        P(t.$slots, "content")
      ]),
      g(l).right_section ? (o(), i("div", Vs, [
        P(t.$slots, "right_section")
      ])) : A("", !0)
    ]));
  }
}), js = { class: "modal-content" }, Gs = /* @__PURE__ */ D({
  __name: "modal",
  props: {
    display: { type: Boolean, default: !0 },
    has_close: { type: Boolean, default: !1 },
    z_index: { default: 99 }
  },
  emits: ["close"],
  setup(e, { emit: l }) {
    const t = e, a = l;
    return (s, r) => (o(), i("div", {
      class: F({ modal: !0, "is-active": t.display }),
      style: Ae(`z-index:${t.z_index}`)
    }, [
      r[1] || (r[1] = M("div", { class: "modal-background" }, null, -1)),
      M("div", js, [
        P(s.$slots, "default")
      ]),
      t.has_close ? (o(), i("button", {
        key: 0,
        class: "modal-close is-large",
        "aria-label": "close",
        onClick: r[0] || (r[0] = (n) => a("close"))
      })) : A("", !0)
    ], 6));
  }
}), Hs = {
  key: 0,
  class: "card-icon"
}, Ks = { class: "card-icon-wrapper" }, Ys = {
  key: 1,
  class: "modal-card-head"
}, qs = {
  key: 2,
  class: "modal-card-body"
}, Zs = {
  key: 3,
  class: "modal-card-foot"
}, jt = /* @__PURE__ */ D({
  __name: "modal-card",
  props: {
    show: { type: Boolean },
    has_close: { type: Boolean },
    max_width: { type: Boolean },
    max_height: { type: Boolean },
    full_width: { type: Boolean },
    full_height: { type: Boolean },
    icon: {}
  },
  emits: ["close"],
  setup(e, { emit: l }) {
    const t = ie(), a = e, s = l, r = {
      addon_class: "card-footer-item"
    }, n = {
      header_class: "modal-card-title has-text-centered",
      addon_class: "card-header-icon"
    }, d = k(() => {
      var c = [];
      return a.full_width && c.push("is-fullwidth"), a.full_height && c.push("is-fullheight"), a.max_width && c.push("is-maxwidth"), a.max_height && c.push("is-maxheight"), c;
    });
    return (c, u) => (o(), i("div", {
      class: F(["modal", { "is-active": a.show }])
    }, [
      u[1] || (u[1] = M("div", { class: "modal-background" }, null, -1)),
      M("div", {
        class: F(["modal-card", d.value])
      }, [
        a.icon ? (o(), i("div", Hs, [
          M("div", Ks, [
            C(K, {
              icon: a.icon,
              size: g(re).xxlarge
            }, null, 8, ["icon", "size"])
          ])
        ])) : A("", !0),
        g(t).header ? (o(), i("div", Ys, [
          P(c.$slots, "header", me(fe(n))),
          a.has_close ? (o(), i("button", {
            key: 0,
            class: "delete",
            "aria-label": "close",
            onClick: u[0] || (u[0] = (p) => s("close"))
          })) : A("", !0)
        ])) : A("", !0),
        g(t).content ? (o(), i("div", qs, [
          P(c.$slots, "content")
        ])) : A("", !0),
        g(t).footer ? (o(), i("div", Zs, [
          P(c.$slots, "footer", me(fe(r)))
        ])) : A("", !0)
      ], 2)
    ], 2));
  }
}), Qs = {
  key: 0,
  class: "panel-heading"
}, Xs = {
  key: 1,
  class: "panel-tabs"
}, en = {
  key: 0,
  class: "panel-block"
}, tn = /* @__PURE__ */ D({
  __name: "panel",
  props: {
    type: {},
    block_names: {},
    full_width: { type: Boolean },
    full_height: { type: Boolean },
    hidden_sections: {}
  },
  setup(e) {
    const l = ie(), t = e, a = k(() => t.block_names ?? ["default"]), s = k(() => [
      t.type ? `is-${t.type}` : "",
      t.full_width ? "is-fullwidth" : "",
      t.full_height ? "is-fullheight" : ""
    ]);
    return (r, n) => (o(), i("div", {
      class: F(["panel", s.value])
    }, [
      g(l).header ? H((o(), i("div", Qs, [
        P(r.$slots, "header")
      ], 512)), [
        [ne, !(t.hidden_sections ?? []).includes("header")]
      ]) : A("", !0),
      g(l).tabs ? H((o(), i("div", Xs, [
        P(r.$slots, "tabs")
      ], 512)), [
        [ne, !(t.hidden_sections ?? []).includes("tabs")]
      ]) : A("", !0),
      (o(!0), i(B, null, W(a.value, (d) => (o(), i(B, null, [
        g(l)[d] ? H((o(), i("div", en, [
          P(r.$slots, d)
        ], 512)), [
          [ne, !(t.hidden_sections ?? []).includes(d)]
        ]) : A("", !0)
      ], 64))), 256))
    ], 2));
  }
}), an = /* @__PURE__ */ D({
  __name: "section",
  props: {
    size: {}
  },
  setup(e) {
    const l = e;
    return (t, a) => (o(), i("section", {
      class: F(["section", l.size ? `is-${l.size}` : ""])
    }, [
      P(t.$slots, "default")
    ], 2));
  }
}), ln = { key: 0 }, sn = { key: 1 }, nn = { key: 2 }, nt = /* @__PURE__ */ D({
  __name: "table",
  props: {
    scrollable: { type: Boolean, default: !1 },
    fixed_header: { type: Boolean, default: !1 },
    full_width: { type: Boolean },
    narrow: { type: Boolean }
  },
  setup(e) {
    const l = ie(), t = e, a = k(() => [
      t.scrollable ? "table-container" : "",
      t.fixed_header && !t.scrollable ? "is-fixed" : ""
    ]), s = k(() => [
      "table",
      "is-striped",
      "is-hoverable",
      t.fixed_header && !t.scrollable ? "is-fixed" : "",
      t.full_width ? "is-fullwidth" : "",
      t.narrow ? "is-narrow" : ""
    ]);
    return (r, n) => (o(), i("div", {
      class: F(a.value)
    }, [
      M("table", {
        class: F(s.value)
      }, [
        g(l).thead ? (o(), i("thead", ln, [
          P(r.$slots, "thead")
        ])) : A("", !0),
        g(l).tbody ? (o(), i("tbody", sn, [
          P(r.$slots, "tbody")
        ])) : A("", !0),
        g(l).tfoot ? (o(), i("tfoot", nn, [
          P(r.$slots, "tfoot")
        ])) : A("", !0)
      ], 2)
    ], 2));
  }
}), rn = ["href", "onClick"], on = {
  key: 0,
  class: "icon is-small"
}, un = { style: { width: "100px" } }, dn = /* @__PURE__ */ D({
  __name: "tabs",
  props: {
    tabs: {},
    alignment: { default: qe.left },
    type: {},
    full_width: { type: Boolean }
  },
  setup(e) {
    const l = e, t = k(() => [
      "tabs",
      `is-${l.alignment}`,
      l.type ? `is-${l.type}` : "",
      l.full_width ? "is-fullwidth" : ""
    ]), a = (s, r) => {
      (r.href === null || r.href === void 0) && r.onClick !== void 0 && (s.preventDefault(), r.onClick());
    };
    return (s, r) => (o(), i("div", {
      class: F(t.value)
    }, [
      M("ul", null, [
        C(g(be), {
          promise: l.tabs
        }, {
          default: E(({ response: n }) => [
            (o(!0), i(B, null, W(n, (d) => (o(), i("li", {
              class: F({ "is-active": d.active })
            }, [
              M("a", {
                href: d.href,
                onClick: (c) => a(c, d)
              }, [
                d.icon ? (o(), i("span", on, [
                  C(g(K), {
                    icon: d.icon
                  }, null, 8, ["icon"])
                ])) : A("", !0),
                M("span", null, T(d.title), 1)
              ], 8, rn)
            ], 2))), 256))
          ]),
          pending: E(() => [
            M("li", un, [
              C(g(_e), {
                size: g(Z).small
              }, null, 8, ["size"])
            ])
          ]),
          _: 1
        }, 8, ["promise"])
      ])
    ], 2));
  }
}), cn = { class: "slideout-content" }, pn = {
  key: 1,
  class: "slideout-head"
}, mn = { class: "slideout-body" }, hn = {
  key: 2,
  class: "slideout-foot"
}, bn = /* @__PURE__ */ D({
  __name: "slideout",
  props: {
    show: { type: Boolean },
    has_close: { type: Boolean },
    full_width: { type: Boolean },
    type: {},
    not_animated: { type: Boolean }
  },
  emits: ["close"],
  setup(e, { emit: l }) {
    const t = ie(), a = {
      addon_class: ""
    }, s = {
      header_class: "slideout-title has-text-centered",
      addon_class: ""
    }, r = e, n = l, d = k(() => [
      "slideout",
      r.show ? "is-active" : "",
      r.type !== void 0 && r.type !== null ? `is-${r.type}` : "",
      r.full_width ? "is-fullwidth" : "",
      r.not_animated ? "no-animation" : ""
    ]);
    return (c, u) => (o(), i("div", {
      class: F(d.value)
    }, [
      M("div", {
        class: "slideout-background",
        onClick: u[0] || (u[0] = (p) => n("close"))
      }),
      M("div", cn, [
        r.has_close ? (o(), i("button", {
          key: 0,
          class: "delete",
          "aria-label": "close",
          onClick: u[1] || (u[1] = (p) => n("close"))
        })) : A("", !0),
        g(t).header ? (o(), i("div", pn, [
          P(c.$slots, "header", me(fe(s)))
        ])) : A("", !0),
        M("div", mn, [
          g(t).content ? P(c.$slots, "content", { key: 0 }) : A("", !0),
          P(c.$slots, "default")
        ]),
        g(t).footer ? (o(), i("div", hn, [
          P(c.$slots, "footer", me(fe(a)))
        ])) : A("", !0)
      ])
    ], 2));
  }
}), vn = ["onClick"], gn = { key: 1 }, yn = {
  key: 0,
  class: "step-details"
}, fn = { class: "step-title" }, _n = { key: 0 }, kn = { class: "steps-content" }, Sn = { class: "steps-actions" }, Mn = { class: "steps-action" }, Dn = {
  key: 0,
  class: "steps-action"
}, $n = {
  key: 1,
  class: "steps-action"
}, An = /* @__PURE__ */ D({
  __name: "step-wizard",
  props: {
    steps: {},
    use_previous_next: { type: Boolean, default: !0 },
    size: { default: Z.normal },
    starting_index: {},
    orientation: { default: Pe.default }
  },
  emits: ["done", "changedStep"],
  setup(e, { expose: l, emit: t }) {
    const a = ie(), s = Q(z), r = k(() => L("Pagination.Previous", s)), n = k(() => L("Pagination.Next", s)), d = k(() => L("Wizard.Done", s)), c = e, u = t, p = x(c.starting_index ?? 0);
    return j(p, (h, _) => {
      u("changedStep", h);
    }), l({
      /**
       * Used to move to a given step in the wizard
       * 
       * @param index the step index to move to
       */
      moveToStep: (h) => {
        p.value = h;
      }
    }), (h, _) => (o(), i("div", {
      class: F(["steps-container", c.orientation === g(Pe).default ? "" : `${c.orientation}`])
    }, [
      M("ul", {
        class: F(["steps", c.size === g(Z).normal ? "" : `is-${c.size}`])
      }, [
        (o(!0), i(B, null, W(c.steps, (m, y) => (o(), i("li", {
          class: F(["step-item", y < p.value ? "is-completed" : "", y === p.value ? "is-active" : "", m.type ? `is-${m.type}` : ""])
        }, [
          M("div", {
            class: "step-marker is-clickable",
            onClick: (b) => u("changedStep", y)
          }, [
            m.icon ? (o(), I(K, {
              key: 0,
              icon: m.icon
            }, null, 8, ["icon"])) : (o(), i("span", gn, T(y + 1), 1))
          ], 8, vn),
          m.title !== "" ? (o(), i("div", yn, [
            M("p", fn, T(m.title), 1),
            m.description ? (o(), i("p", _n, T(m.description), 1)) : A("", !0)
          ])) : A("", !0)
        ], 2))), 256))
      ], 2),
      M("div", kn, [
        (o(!0), i(B, null, W(c.steps, (m, y) => (o(), i(B, null, [
          g(a)[m.name] ? (o(), i("div", {
            key: 0,
            class: F(["step-content", y === p.value ? "is-active" : ""])
          }, [
            P(h.$slots, m.name)
          ], 2)) : A("", !0)
        ], 64))), 256))
      ]),
      M("div", Sn, [
        c.use_previous_next ? (o(), i(B, { key: 0 }, [
          M("div", Mn, [
            C(te, {
              title: r.value,
              disabled: p.value === 0,
              onClick: _[0] || (_[0] = () => {
                p.value--;
              })
            }, null, 8, ["title", "disabled"])
          ]),
          p.value + 1 < c.steps.length ? (o(), i("div", Dn, [
            C(te, {
              title: n.value,
              disabled: !(c.steps[p.value].is_valid === void 0 || c.steps[p.value].is_valid),
              onClick: _[1] || (_[1] = () => {
                p.value++;
              })
            }, null, 8, ["title", "disabled"])
          ])) : A("", !0),
          p.value + 1 === c.steps.length ? (o(), i("div", $n, [
            C(te, {
              title: d.value,
              disabled: !(c.steps[p.value].is_valid === void 0 || c.steps[p.value].is_valid),
              onClick: _[2] || (_[2] = () => {
                u("done");
              })
            }, null, 8, ["title", "disabled"])
          ])) : A("", !0)
        ], 64)) : (o(), i(B, { key: 1 }, [
          g(a).actions ? P(h.$slots, "actions", { key: 0 }) : A("", !0),
          (o(!0), i(B, null, W(c.steps, (m, y) => (o(), i(B, null, [
            g(a)[`actions-${m.name}`] && y === p.value ? P(h.$slots, `actions-${m.name}`, { key: 0 }) : A("", !0)
          ], 64))), 256))
        ], 64))
      ])
    ], 2));
  }
}), Jn = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  Banner: ks,
  Box: Vt,
  Breadcrumbs: $s,
  Card: Ut,
  ColumnContainer: st,
  Footer: Ts,
  Level: Is,
  List: It,
  Media: Us,
  Modal: Gs,
  ModalCard: jt,
  Panel: tn,
  Section: an,
  Slideout: bn,
  StepWizard: An,
  Table: nt,
  Tabs: dn
}, Symbol.toStringTag, { value: "Module" })), Nn = { class: "control has-icons-left has-icons-right" }, Fn = ["name", "id", "placeholder", "disabled"], wn = ["onClick"], On = {
  colspan: "100%",
  class: "has-text-centered"
}, $e = RegExp("^(\\d{2})-(\\d{2})-(\\d{4})$"), Ne = RegExp("^(\\d{2})-(\\d{2})-(\\d{4}) (\\d{2}):(\\d{2})$"), Gt = /* @__PURE__ */ D({
  __name: "date",
  props: {
    label: {},
    includeTime: { type: Boolean },
    name: {},
    disabled: { type: Boolean, default: !1 },
    inputId: {}
  },
  emits: ["valueChanged"],
  setup(e, { expose: l, emit: t }) {
    const a = x(), s = e, r = t, n = x(!1), d = x(null), c = x(null), u = ra({
      Month: (/* @__PURE__ */ new Date()).getMonth(),
      Year: (/* @__PURE__ */ new Date()).getFullYear(),
      Today: (/* @__PURE__ */ new Date()).getDate()
    }), p = Q(z), h = ye({
      Sun: k(() => L("Date.Weekdays.Sun", p)),
      Mon: k(() => L("Date.Weekdays.Mon", p)),
      Tue: k(() => L("Date.Weekdays.Tue", p)),
      Wed: k(() => L("Date.Weekdays.Wed", p)),
      Thu: k(() => L("Date.Weekdays.Thu", p)),
      Fri: k(() => L("Date.Weekdays.Fri", p)),
      Sat: k(() => L("Date.Weekdays.Sat", p))
    }), _ = k(() => d.value !== null && (s.includeTime ? Ne : $e).test(d.value)), m = () => {
      if (d.value === null || d.value === "")
        return null;
      {
        if (!Ne.test(d.value) && s.includeTime)
          return null;
        if (!s.includeTime && !$e.test(d.value))
          return null;
        if ($e.test(d.value) && s.includeTime)
          return null;
        let S = s.includeTime ? Ne.exec(d.value) : $e.exec(d.value);
        return new Date(
          parseInt(S[3]),
          parseInt(S[2]) - 1,
          parseInt(S[1]),
          s.includeTime ? parseInt(S[4]) : 0,
          s.includeTime ? parseInt(S[5]) : 0,
          0,
          0
        );
      }
    };
    j(d, (S) => {
      if (S === null)
        r("valueChanged", { name: s.name, value: null }), u.Month = (/* @__PURE__ */ new Date()).getMonth(), u.Year = (/* @__PURE__ */ new Date()).getFullYear();
      else if (!$e.test(S) && !Ne.test(S)) {
        S = S.replaceAll(/[^0-9]/g, "");
        for (var O = [], V = 0; V < S.length; V += 2)
          V == 4 ? (O.push(S.substring(V, Math.min(S.length - V, 4) + V)), V += 2) : O.push(S.substring(V, Math.min(S.length - V, 2) + V));
        O.length > 0 && (/^([0-1]|(0[1-9])|(1[0-2]))$/.test(O[0]) || O.splice(0), O.length > 1 && (/^[0-3]/.test(O[1]) ? /^(01|03|05|07|08|10|12)$/.test(O[0]) ? /^([0-3]|(0[1-9])|([1-2][0-9])|(3[0-1]))$/.test(O[1]) || O.splice(1) : /^(02|04|06|09|11)$/.test(O[0]) ? /^([0-3]|(0[1-9])|([1-2][0-9])|(30))$/.test(O[1]) || O.splice(1) : /^([0-2]|(0[1-9])|([1-2][0-9]))$/.test(O[1]) || O.splice(1) : O.splice(1)), O.length > 3 && (/^([0-2]|([0-1][0-9])|(2[0-3]))$/.test(O[3]) || O.splice(3)), O.length > 4 && (/^[0-5][0-9]?$/.test(O[4]) || O.splice(4))), S = O.join(""), !s.includeTime && S.length > 8 && (S = S.substring(0, 8)), S.length >= 2 && (S = S.substring(0, 2) + "-" + (S.length > 2 ? S.substring(2) : "")), S.length >= 5 && (S = S.substring(0, 5) + "-" + (S.length > 5 ? S.substring(5) : "")), S.length >= 9 && s.includeTime && (S = S.substring(0, 9) + " " + (S.length > 9 ? S.substring(9) : "")), S.length >= 11 && (S = S.substring(0, 11) + ":" + (S.length > 11 ? S.substring(11) : "")), d.value = S;
      } else {
        var ae = m();
        _ && r("valueChanged", { name: s.name, value: ae }), u.Month = (ae == null ? void 0 : ae.getMonth()) ?? (/* @__PURE__ */ new Date()).getMonth(), u.Year = (ae == null ? void 0 : ae.getFullYear()) ?? (/* @__PURE__ */ new Date()).getFullYear();
      }
    });
    const y = k(() => ke(new Date(u.Year, u.Month, 1), p, "MMMM")), b = k(() => {
      var S = [], O = new Date(u.Year, u.Month, 1);
      O = We(O, O.getDay() * -1);
      for (var V = m(), ae = We(new Date(u.Year, u.Month, 1), 32).getMonth(); O.getMonth() != ae; ) {
        for (var ze = [], rt = 0; rt < 7; rt++)
          ze.push({
            Number: O.getDate(),
            Disabled: O.getMonth() != u.Month,
            isToday: ke(O, p, "yyyy-MM-dd") == ke(/* @__PURE__ */ new Date(), p, "yyyy-MM-dd"),
            isSelected: V != null && ke(O, p, "yyyy-MM-dd") == ke(V, p, "yyyy-MM-dd")
          }), O = We(O, 1);
        S.push(ze);
      }
      return S;
    });
    l({
      /**
       * Gets the current value 
       */
      getValue: m,
      /**
       * Sets the current value
       * 
       * @param value Date|null
       * @returns void
       */
      setValue: function(S) {
        S === null ? d.value = null : d.value = ke(S, p, `dd-MM-yyyy${s.includeTime ? " HH:mm" : ""}`);
      }
    });
    const J = (S) => {
      S.value == null ? d.value != null && (d.value = d.value.split(" ")[0]) : d.value != null ? d.value = d.value.split(" ")[0] + " " + S.value : d.value = `${ee((u.Month == (/* @__PURE__ */ new Date()).getMonth() ? (/* @__PURE__ */ new Date()).getDate() : 1).toString(), "0", 2)}-${ee((u.Month + 1).toString(), "0", 2)}-${u.Year} ${S.value}`;
    }, N = (S) => {
      var V;
      if (!S.Disabled && !S.isSelected)
        if (d.value === null)
          d.value = `${ee(S.Number.toString(), "0", 2)}-${ee((u.Month + 1).toString(), "0", 2)}-${u.Year}` + (s.includeTime ? ((V = a.value) == null ? void 0 : V.getValue()) == null ? "" : " " + a.value.getValue() : "");
        else {
          var O = d.value.split(" ");
          O[0] = `${ee(S.Number.toString(), "0", 2)}-${ee((u.Month + 1).toString(), "0", 2)}-${u.Year}`, d.value = `${O[0]}${O.length > 1 ? " " + O[1] : ""}`;
        }
    }, w = () => {
      d.value = c.value, n.value = !1;
    }, U = () => {
      s.disabled || (c.value = d.value, n.value = !0);
    }, f = () => {
      s.disabled || (d.value = null);
    }, G = (S) => {
      u.Month + S == -1 ? (u.Year = u.Year - 1, u.Month = 11) : u.Month + S == 12 ? (u.Year = u.Year + 1, u.Month = 0) : u.Month += S;
    };
    return (S, O) => (o(), i("div", null, [
      M("div", Nn, [
        H(M("input", {
          class: "input is-expanded",
          name: s.name,
          id: s.inputId,
          type: "text",
          "onUpdate:modelValue": O[0] || (O[0] = (V) => d.value = V),
          placeholder: "DD-MM-YYYY" + (s.includeTime ? " HH:mm" : ""),
          disabled: s.disabled
        }, null, 8, Fn), [
          [De, d.value]
        ]),
        M("span", {
          class: "icon is-small is-left is-clickable",
          onClick: U
        }, [
          C(g(K), {
            icon: "calendar-alt",
            size: g(re).xlarge
          }, null, 8, ["size"])
        ]),
        M("span", {
          class: "icon is-small is-right is-clickable",
          onClick: f
        }, [
          C(g(K), {
            icon: "window-close",
            size: g(re).xlarge
          }, null, 8, ["size"])
        ])
      ]),
      C(g(jt), {
        show: n.value,
        icon: "calendar-alt"
      }, {
        header: E(() => [
          C(g(st), {
            class: "card-header-title",
            columns: [{ name: "left" }, { name: "title", class: "has-text-centered" }, { name: "right", class: "has-text-right" }]
          }, {
            left: E(() => [
              C(g(K), {
                class: "is-clickable",
                icon: "arrow-circle-left",
                onClick: O[1] || (O[1] = (V) => G(-1))
              })
            ]),
            title: E(() => [
              q(T(y.value) + " " + T(u.Year), 1)
            ]),
            right: E(() => [
              C(g(K), {
                class: "is-clickable",
                icon: "arrow-circle-right",
                onClick: O[2] || (O[2] = (V) => G(1))
              })
            ]),
            _: 1
          })
        ]),
        content: E(() => [
          C(g(nt), { full_width: !0 }, xe({
            thead: E(() => [
              M("tr", null, [
                M("th", null, T(g(h).Sun), 1),
                M("th", null, T(g(h).Mon), 1),
                M("th", null, T(g(h).Tue), 1),
                M("th", null, T(g(h).Wed), 1),
                M("th", null, T(g(h).Thu), 1),
                M("th", null, T(g(h).Fri), 1),
                M("th", null, T(g(h).Sat), 1)
              ])
            ]),
            tbody: E(() => [
              (o(!0), i(B, null, W(b.value, (V) => (o(), i("tr", null, [
                (o(!0), i(B, null, W(V, (ae) => (o(), i("td", {
                  class: F(["is-unselectable has-text-centered", ae.Disabled ? "has-text-primary-dark has-background-primary-light" : "is-clickable", ae.isToday ? "has-background-primary-dark has-text-primary-light" : "", ae.isSelected ? "has-background-success-dark has-text-success-light" : ""]),
                  onClick: (ze) => N(ae)
                }, T(ae.Number), 11, wn))), 256))
              ]))), 256))
            ]),
            _: 2
          }, [
            s.includeTime ? {
              name: "tfoot",
              fn: E(() => [
                M("tr", null, [
                  M("td", On, [
                    C(lt, {
                      ref: a.value,
                      name: `${s.name}-time`,
                      disabled: s.disabled,
                      onValueChanged: J
                    }, null, 8, ["name", "disabled"])
                  ])
                ])
              ]),
              key: "0"
            } : void 0
          ]), 1024)
        ]),
        footer: E(({ addon_class: V }) => [
          C(g(Pt), {
            class: F(V),
            disabled: !_.value,
            onClick: O[3] || (O[3] = (ae) => n.value = !1)
          }, null, 8, ["class", "disabled"]),
          C(g(Tt), {
            class: F(V),
            onClick: w
          }, null, 8, ["class"])
        ]),
        _: 1
      }, 8, ["show"])
    ]));
  }
}), Ht = /* @__PURE__ */ D({
  __name: "full-editor",
  props: {
    name: {},
    disabled: { type: Boolean },
    inputId: {}
  },
  emits: ["valueChanged"],
  async setup(e, { expose: l, emit: t }) {
    let a, s;
    const r = va(z);
    Ce([`${r}summernote-lite.min.css`]), [a, s] = oa(() => import(`${r}summernote`)), await a, s();
    const n = x(null), d = e, c = t;
    return j(() => d.disabled, (h) => {
      n.value != null && $(n.value).summernote(h ? "disable" : "enable");
    }), l({
      /**
       * Gets the current value 
       */
      getValue: () => $(n.value).summernote("code"),
      /**
       * Sets the current value
       * 
       * @param value string|null
       * @returns void
       */
      setValue: (h) => {
        $(n.value).summernote("code", h);
      }
    }), ce(() => {
      $(n.value).summernote({
        height: 400,
        callbacks: {
          onChange: function(h) {
            c("valueChanged", { name: d.name, value: h });
          }
        }
      }), (d.disabled ?? !1) && $(n.value).summernote("disable");
    }), ua(() => {
      $(n.value).summernote("destroy");
    }), (h, _) => (o(), i("div", {
      class: "summernote",
      ref_key: "snote",
      ref: n
    }, null, 512));
  }
}), Ve = /* @__PURE__ */ D({
  __name: "header",
  props: {
    label: {},
    subtype: { default: "h1" },
    translate: {},
    inputId: {}
  },
  setup(e) {
    const l = e, t = de(l, z);
    return (a, s) => (o(), I(pe(l.subtype), null, {
      default: E(() => [
        q(T(g(t)(l.label ?? "")), 1)
      ]),
      _: 1
    }));
  }
}), Tn = ["name"], Kt = /* @__PURE__ */ D({
  __name: "hidden",
  props: {
    name: {}
  },
  emits: ["valueChanged"],
  setup(e, { expose: l, emit: t }) {
    const a = e, s = t, r = x(null);
    return j(r, (c) => s("valueChanged", { name: a.name, value: c })), l({
      /**
       * Gets the current value 
       */
      getValue: () => r.value,
      /**
       * Sets the current value
       * 
       * @param value string|null
       * @returns void
       */
      setValue: (c) => {
        r.value = c;
      }
    }), (c, u) => H((o(), i("input", {
      type: "hidden",
      name: a.name,
      "onUpdate:modelValue": u[0] || (u[0] = (p) => r.value = p)
    }, null, 8, Tn)), [
      [De, r.value]
    ]);
  }
}), Pn = ["id", "name", "disabled", "min", "max", "step"], Yt = /* @__PURE__ */ D({
  __name: "number",
  props: {
    min: {},
    max: {},
    step: {},
    name: {},
    disabled: { type: Boolean, default: !1 },
    inputId: {}
  },
  emits: ["valueChanged"],
  setup(e, { expose: l, emit: t }) {
    const a = e, s = t, r = x(null), n = () => {
      if (r.value === "" || r.value === null)
        return null;
      let c = parseInt(r.value);
      return a.min !== void 0 && c < a.min * 1 || a.max !== void 0 && c > a.max * 1 ? null : c;
    }, d = (c) => {
      r.value = c === null ? "" : c.toString();
    };
    return j([r], (c) => s("valueChanged", { name: a.name, value: n() })), l({
      /**
       * Gets the current value 
       */
      getValue: n,
      /**
       * Sets the current value
       * 
       * @param value number|string|null
       * @returns void
       */
      setValue: d
    }), (c, u) => H((o(), i("input", {
      type: "number",
      class: "input",
      id: a.inputId,
      name: a.name,
      "onUpdate:modelValue": u[0] || (u[0] = (p) => r.value = p),
      disabled: a.disabled,
      min: a.min,
      max: a.max,
      step: a.step
    }, null, 8, Pn)), [
      [De, r.value]
    ]);
  }
}), xn = ["id"], Ue = /* @__PURE__ */ D({
  __name: "paragraph",
  props: {
    label: {},
    name: {},
    translate: { type: Function },
    inputId: {}
  },
  setup(e) {
    const l = e, t = de(l, z);
    return (a, s) => (o(), i("p", {
      id: l.inputId
    }, T(g(t)(l.label ?? "")), 9, xn));
  }
}), Cn = ["for"], Bn = ["name", "value", "disabled", "id"], qt = /* @__PURE__ */ D({
  __name: "radio-group",
  props: {
    values: { type: [Array, Promise, Function, null] },
    name: {},
    disabled: { type: Boolean },
    inputId: {},
    translate: { type: Function }
  },
  emits: ["valueChanged"],
  setup(e, { expose: l, emit: t }) {
    const a = e, s = Q(z), r = k(() => L("Form.Error", s)), n = t, d = de(a, z), c = x(null), u = () => c.value;
    j(c, (y) => {
      n("valueChanged", { name: a.name, value: u() });
    });
    const p = k(async () => {
      var y;
      if (a.values == null)
        return [];
      {
        let b = await at(a.values);
        return c.value === null && b.some((v) => v.selected) && (c.value = (y = b.find((v) => v.selected)) == null ? void 0 : y.value), b.map((v) => ({
          label: v.label,
          value: v.value,
          selected: c.value === v.value
        }));
      }
    }), h = (y) => {
      c.value = y;
    }, { hiddenValues: _, disabledValues: m } = tt(a.name, z);
    return l({
      /**
       * Gets the current value 
       */
      getValue: u,
      /**
       * Sets the current value
       * 
       * @param value any|null
       * @returns void
       */
      setValue: h
    }), (y, b) => (o(), i("div", null, [
      C(be, { promise: p.value }, {
        default: E(({ response: v }) => [
          y.values != null ? (o(!0), i(B, { key: 0 }, W(v, (J, N) => H((o(), i("label", {
            class: "radio is-block",
            for: `${a.inputId}-${N}`
          }, [
            M("input", {
              type: "radio",
              name: a.name,
              value: J.value,
              class: "radio",
              disabled: a.disabled || g(m).some((w) => w === J.value.toString()),
              id: `${a.inputId}-${N}`
            }, null, 8, Bn),
            q(" " + T(g(d)(J.label)), 1)
          ], 8, Cn)), [
            [ne, !g(_).some((w) => w === J.value.toString())]
          ])), 256)) : A("", !0)
        ]),
        rejected: E(() => [
          C(g(he), {
            type: g(ue).danger,
            message: r.value
          }, null, 8, ["type", "message"])
        ]),
        _: 1
      }, 8, ["promise"])
    ]));
  }
}), En = { class: "select" }, zn = ["id", "name", "multiple", "disabled"], In = ["value", "selected", "disabled"], Rn = ["label", "disabled"], Wn = ["value", "selected", "disabled"], Zt = (e, l, t) => {
  let a = {
    label: e === null ? l.label : `${e}->${l.label}`,
    values: [],
    value: l.value
  }, s = t.length;
  return t.push(a), l.values.forEach((r) => {
    r.values === void 0 ? a.values.push(r) : t = Zt(a.label, r, t);
  }), t[s].values.length == 0 && t.splice(s, 1), t;
}, Qt = /* @__PURE__ */ D({
  __name: "select",
  props: {
    values: {},
    multiple: { type: Boolean, default: !1 },
    name: {},
    disabled: { type: Boolean },
    inputId: {},
    translate: {}
  },
  emits: ["valueChanged"],
  setup(e, { expose: l, emit: t }) {
    const a = e, s = Q(z), r = k(() => L("Form.Error", s)), n = t, d = de(a, z), c = x(null), u = x(!1), p = k(async () => {
      var b;
      if (a.values == null)
        return [];
      {
        let v = await at(a.values), J = v.filter((w) => w.selected).map((w) => w.value);
        v.some((w) => w.values !== void 0) && v.filter((w) => w.values !== void 0).forEach((w) => {
          var U;
          J = J.concat(
            (U = w.values) == null ? void 0 : U.filter((f) => f.selected).map((f) => f.value)
          );
        }), c.value === null || c.value.length === 0 ? c.value = null : (v = v.map((w) => {
          let U = w;
          return U.values !== void 0 && (U.values = U.values.map((f) => {
            var G;
            return f.selected = (G = c.value) == null ? void 0 : G.some((S) => S === f.value), f;
          })), U;
        }), (b = c.value) == null || b.forEach((w) => {
          v.some((U) => U.value !== void 0 && U.value === w || U.values !== void 0 && U.values.some((f) => f.value === w)) || v.push({
            label: w,
            value: w
          });
        }));
        let N = [];
        return v.forEach((w) => {
          w.values === void 0 ? N.push(w) : N = Zt(null, w, N);
        }), N;
      }
    }), h = () => c.value == null || c.value.length == 0 ? null : a.multiple ? c.value.slice() : Array.isArray(c.value) ? c.value[0] : c.value;
    j(c, () => {
      u.value || n("valueChanged", { name: a.name, value: h() });
    }), j(u, (b) => {
      b || n("valueChanged", { name: a.name, value: h() });
    });
    const _ = (b) => {
      u.value = !0, b != null ? c.value = Array.isArray(b) ? b : [b] : a.multiple ? c.value = [] : c.value = null, u.value = !1;
    }, { hiddenValues: m, disabledValues: y } = tt(a.name, z);
    return l({
      /**
       * Gets the current value 
       */
      getValue: h,
      /**
       * Sets the current value
       * 
       * @param value any|any[]|null
       * @returns void
       */
      setValue: _
    }), (b, v) => (o(), i("div", En, [
      p.value != null ? (o(), I(be, {
        key: 0,
        promise: p.value
      }, {
        default: E(({ response: J }) => [
          H(M("select", {
            id: a.inputId,
            name: a.name,
            multiple: a.multiple,
            class: F(a.multiple ? "is-multiple" : ""),
            "onUpdate:modelValue": v[0] || (v[0] = (N) => c.value = N),
            disabled: a.disabled
          }, [
            J != null ? (o(!0), i(B, { key: 0 }, W(J, (N) => (o(), i(B, null, [
              N.values === void 0 ? H((o(), i("option", {
                key: 0,
                value: N.value,
                selected: N.selected,
                disabled: g(y).some((w) => w === N.value.toString())
              }, T(g(d)(N.label)), 9, In)), [
                [ne, !g(m).some((w) => w === N.value.toString())]
              ]) : A("", !0),
              N.values !== void 0 ? H((o(), i("optgroup", {
                key: 1,
                label: g(d)(N.label),
                disabled: g(y).some((w) => w === N.value.toString())
              }, [
                (o(!0), i(B, null, W(N.values, (w) => H((o(), i("option", {
                  value: w.value,
                  selected: w.selected,
                  disabled: g(y).some((U) => U === w.value.toString())
                }, T(g(d)(w.label)), 9, Wn)), [
                  [ne, !g(m).some((U) => U === w.value.toString())]
                ])), 256))
              ], 8, Rn)), [
                [ne, !g(m).some((w) => w === N.value.toString())]
              ]) : A("", !0)
            ], 64))), 256)) : A("", !0)
          ], 10, zn), [
            [ia, c.value]
          ])
        ]),
        rejected: E(() => [
          C(g(he), {
            type: g(ue).danger,
            message: r.value
          }, null, 8, ["type", "message"])
        ]),
        _: 1
      }, 8, ["promise"])) : A("", !0)
    ]));
  }
}), Ln = { class: "field" }, Vn = ["id", "name", "disabled"], Un = ["for"], jn = {
  key: 0,
  class: "help is-danger"
}, Xt = /* @__PURE__ */ D({
  __name: "switch",
  props: {
    label: {},
    required: { type: Boolean },
    name: {},
    disabled: { type: Boolean },
    inputId: {},
    translate: { type: Function }
  },
  emits: ["valueChanged"],
  setup(e, { expose: l, emit: t }) {
    const a = e, s = t, r = de(a, z), n = x(!1);
    return j(n, (u) => s("valueChanged", { name: a.name, value: u })), l({
      /**
       * Gets the current value 
       */
      getValue: () => n.value,
      /**
       * Sets the current value
       * 
       * @param value boolean
       * @returns void
       */
      setValue: (u) => {
        n.value = u;
      }
    }), (u, p) => (o(), i("div", Ln, [
      H(M("input", {
        type: "checkbox",
        class: "switch is-rounded",
        id: a.inputId,
        name: a.name,
        "onUpdate:modelValue": p[0] || (p[0] = (h) => n.value = h),
        disabled: a.disabled
      }, null, 8, Vn), [
        [je, n.value]
      ]),
      M("label", {
        for: u.$props.inputId
      }, [
        q(T(g(r)(a.label)) + " ", 1),
        a.required ? (o(), i("span", jn, "*")) : A("", !0)
      ], 8, Un)
    ]));
  }
}), Gn = ["id", "type", "name", "disabled", "maxlength"], ea = /* @__PURE__ */ D({
  __name: "text",
  props: {
    subtype: { default: "text" },
    maxlength: {},
    name: {},
    disabled: { type: Boolean },
    inputId: {}
  },
  emits: ["valueChanged"],
  setup(e, { expose: l, emit: t }) {
    const a = e, s = t, r = x(null);
    return j(r, (c) => s("valueChanged", { name: a.name, value: c })), l({
      /**
       * Gets the current value 
       */
      getValue: () => r.value,
      /**
       * Sets the current value
       * 
       * @param value any|null
       * @returns void
       */
      setValue: (c) => {
        r.value = c;
      }
    }), (c, u) => H((o(), i("input", {
      id: a.inputId,
      type: c.subtype,
      class: "input",
      name: c.name,
      disabled: c.disabled,
      maxlength: a.maxlength,
      "onUpdate:modelValue": u[0] || (u[0] = (p) => r.value = p)
    }, null, 8, Gn)), [
      [da, r.value]
    ]);
  }
}), Hn = ["id", "name", "rows", "cols", "maxlength", "disabled"], ta = 9, Se = String.fromCharCode(ta), Fe = `
`, aa = /* @__PURE__ */ D({
  __name: "textarea",
  props: {
    maxlength: {},
    rows: {},
    cols: {},
    supportsTab: { type: Boolean },
    name: {},
    disabled: { type: Boolean },
    inputId: {}
  },
  emits: ["valueChanged"],
  setup(e, { expose: l, emit: t }) {
    const a = e, s = t, r = x(null);
    j(r, (u) => {
      s("valueChanged", { name: a.name, value: u });
    });
    const n = () => r.value, d = (u) => {
      r.value = u;
    };
    l({
      /**
       * Gets the current value 
       */
      getValue: n,
      /**
       * Sets the current value
       * 
       * @param value string|null
       * @returns void
       */
      setValue: d
    });
    const c = (u) => {
      if (a.supportsTab) {
        let p = n();
        if (p !== null)
          switch (u.keyCode) {
            case ta:
              let h = u.selectionStart ?? u.target.selectionStart, _ = u.selectionEnd ?? u.target.selectionEnd, m = p.substring(0, h), y = p.length > _ ? p.substring(_) : "", b = h === _ ? "" : p.substring(h, _);
              if (b.indexOf(`
`) < 0)
                u.shiftKey ? b.startsWith(Se) ? (b = b.substring(1), h--) : m.endsWith(Se) && (m = m.substring(0, m.length - 1), h--) : b = Se + b;
              else {
                let v = !1;
                b.endsWith(Fe) && (v = !0, b = b.substring(0, b.length - 1));
                let J = b.split(Fe);
                b = "", u.shiftKey && m.endsWith(Se) && (m = m.substring(0, m.length - 1), h--), J.forEach((N, w) => {
                  u.shiftKey && N.startsWith(Se) ? N = N.substring(1) : u.shiftKey || (N = Se + N), b += N + (w === J.length - 1 ? "" : Fe);
                }), v && (b += Fe);
              }
              return p = m + b + y, h += b.length == 1 ? 1 : 0, _ = h + (b.length == 1 ? 0 : b.length), d(p), u.target.selectionStart = h, u.target.selectionEnd = _, u.target.focus(), u.preventDefault != null && u.preventDefault(), !1;
            default:
              return !0;
          }
      }
      return !0;
    };
    return (u, p) => H((o(), i("textarea", {
      class: "textarea",
      id: a.inputId,
      name: a.name,
      rows: a.rows,
      cols: a.cols,
      maxlength: a.maxlength,
      disabled: a.disabled,
      onKeydown: c,
      "onUpdate:modelValue": p[0] || (p[0] = (h) => r.value = h)
    }, null, 40, Hn)), [
      [De, r.value]
    ]);
  }
}), Kn = (e) => {
  let l = le.twelve;
  if (e !== void 0)
    switch (e) {
      case 1:
        l = le.one;
        break;
      case 2:
        l = le.two;
        break;
      case 3:
        l = le.three;
        break;
      case 4:
        l = le.four;
        break;
      case 5:
        l = le.five;
        break;
      case 6:
        l = le.six;
        break;
      case 7:
        l = le.seven;
        break;
      case 8:
        l = le.eight;
        break;
      case 9:
        l = le.nine;
        break;
      case 10:
        l = le.ten;
        break;
      case 11:
        l = le.eleven;
        break;
      default:
        l = le.twelve;
        break;
    }
  return l;
}, la = /* @__PURE__ */ D({
  __name: "inputs-collection",
  props: {
    fields: {},
    disabled: { type: Boolean }
  },
  emits: ["valueChanged", "buttonClicked"],
  setup(e, { expose: l, emit: t }) {
    const a = (m) => ({
      size: Kn(m.form_columns),
      class: "field"
    }), s = e, r = t;
    let n = [];
    const d = k(() => {
      let m = [], y = [], b = 0;
      return n = s.fields.map((v, J) => x(null)), s.fields.forEach((v, J) => {
        let N = v.form_columns ?? 12;
        b + N > 12 && (m.push(y), y = [], b = 0), y.push({ ...v, refIndex: J }), b += N, b === 12 && (m.push(y), y = [], b = 0);
      }), y.length > 0 && m.push(y), m;
    }), c = z(Ee), u = z(et);
    return l({
      /**
       * Called to set the value for a component in the row
       * 
       * @param value any
       */
      setValue: (m) => {
        n.forEach((y, b) => {
          switch (s.fields[b].type) {
            case "subform":
              y.value.setValue(m);
              break;
            default:
              y.value.setValue !== void 0 && (m === null ? y.value.setValue(null) : Object.keys(m).some((v) => v === y.value.fieldName) ? y.value.setValue(m[y.value.fieldName]) : Object.keys(m).some((v) => v === y.value.altFieldName) && y.value.setValue(m[y.value.altFieldName]));
              break;
          }
        });
      },
      /**
       * Called to get the value of the components in this row.
       * Returns an object where the propertyName are the names of the fields in the subform.
       */
      getValue: () => {
        var m = {};
        return n.forEach((y) => {
          if (y.value.getValue != null)
            switch (y.value.type) {
              case "subform":
                m = Object.assign(m, y.value.getValue());
                break;
              default:
                m[y.value.fieldName] = y.value.getValue();
                break;
            }
        }), m;
      },
      /**
       * Called to see if all the copmonents in this row are valid.
       */
      isValid: () => !n.some((m) => !(m.value.isValid === void 0 || m.value.isValid()))
    }), (m, y) => (o(), i("section", null, [
      (o(!0), i(B, null, W(d.value, (b) => (o(), I(st, {
        modifiers: [g(Ke).gapless],
        columns: b.map((v) => a(v))
      }, xe({ _: 2 }, [
        W(b.map((v, J) => ({ input: v, index: J })).filter((v) => !g(c).some((J) => J === v.input.name)), (v) => ({
          name: `col-${v.index}`,
          fn: E(() => [
            C(sa, {
              ref_for: !0,
              ref: (J) => g(n)[v.input.refIndex].value = J,
              input: v.input,
              onValueChanged: y[0] || (y[0] = (J) => r("valueChanged", J)),
              onButtonClicked: y[1] || (y[1] = (J) => r("buttonClicked", J)),
              disabled: (s.disabled ?? !1) || g(u).some((J) => J === v.input.name)
            }, null, 8, ["input", "disabled"])
          ])
        }))
      ]), 1032, ["modifiers", "columns"]))), 256))
    ]));
  }
}), Yn = /* @__PURE__ */ D({
  __name: "subform",
  props: {
    fields: {},
    name: {},
    disabled: { type: Boolean, default: !1 },
    inputId: {}
  },
  emits: ["valueChanged", "buttonClicked"],
  setup(e, { expose: l, emit: t }) {
    const a = e, s = t, r = x(null), n = z(Ee, ye(x([]))), d = k(() => n ? n.value.some((h) => h === a.name) : !1);
    return l({
      /**
       * Called to set the value of 1 or more copmonents inside this sub form
       * 
       * @param value any
       */
      setValue: (h) => {
        r.value !== null && r.value.setValue(h);
      },
      /**
       * Called to get the value of this of all the components inside this subform.  
       * Returns an object where each propertyName is the name of the field and it's value is the value.
       */
      getValue: () => r.value === null ? null : r.value.getValue(),
      /**
       * Called to see if this sub form is valid.  It returns the result of true if all the components return true from their isValid calls
       */
      isValid: () => r.value === null ? !1 : r.value.isValid()
    }), (h, _) => H((o(), I(Vt, {
      id: a.name,
      name: a.name
    }, {
      default: E(() => [
        C(la, {
          fields: a.fields,
          ref_key: "inputs",
          ref: r,
          disabled: a.disabled,
          onValueChanged: _[0] || (_[0] = (m) => s("valueChanged", m)),
          onButtonClicked: _[1] || (_[1] = (m) => s("buttonClicked", m))
        }, null, 8, ["fields", "disabled"])
      ]),
      _: 1
    }, 8, ["id", "name"])), [
      [ne, !d.value]
    ]);
  }
});
var R = /* @__PURE__ */ ((e) => (e.autocomplete = "autocomplete", e.button = "button", e.checkbox_group = "checkbox-group", e.checkbox = "checkbox", e.date = "date", e.full_editor = "full-editor", e.header = "header", e.hidden = "hidden", e.number = "number", e.paragraph = "paragraph", e.radio_group = "radio-group", e.select = "select", e.subform = "subform", e.switch = "switch", e.text = "text", e.textarea = "textarea", e.time = "time", e))(R || {});
const qn = ["for"], Zn = {
  key: 0,
  class: "is-required-marker"
}, Qn = { class: "control" }, Xn = [R.autocomplete, R.checkbox_group, R.date, R.number, R.radio_group, R.select, R.text, R.textarea, R.time, R.subform], er = [R.subform, R.switch, R.select, R.radio_group, R.paragraph, R.header, R.checkbox_group, R.checkbox, R.button, R.autocomplete], sa = /* @__PURE__ */ D({
  __name: "form-component",
  props: {
    input: {},
    disabled: { type: Boolean, default: !1 },
    translate: {},
    inputId: {}
  },
  emits: ["valueChanged", "buttonClicked"],
  setup(e, { expose: l, emit: t }) {
    const a = x(null), s = ca(), r = t, n = e, d = de(n, z), c = ye(x(n.input.type)), u = k(() => {
      let f = null;
      switch (n.input.type) {
        case R.autocomplete:
          f = Rt;
          break;
        case R.button:
          f = Le;
          break;
        case R.checkbox_group:
          f = Wt;
          break;
        case R.checkbox:
          f = Lt;
          break;
        case R.date:
          f = Gt;
          break;
        case R.full_editor:
          f = Ht;
          break;
        case R.header:
          f = Ve;
          break;
        case R.hidden:
          f = Kt;
          break;
        case R.number:
          f = Yt;
          break;
        case R.paragraph:
          f = Ue;
          break;
        case R.radio_group:
          f = qt;
          break;
        case R.select:
          f = Qt;
          break;
        case R.switch:
          f = Xt;
          break;
        case R.text:
          f = ea;
          break;
        case R.textarea:
          f = aa;
          break;
        case R.time:
          f = lt;
          break;
        case R.subform:
          f = Yn;
          break;
      }
      return f;
    }), p = function(f) {
      a.value !== null && a.value.setValue !== void 0 && a.value.setValue(f);
    };
    ce(() => {
      a.value !== null && n.input.value !== void 0 && n.input.value !== null && p(n.input.value);
    });
    const h = k(() => n.input.disabled ?? n.disabled ?? !1), _ = k(() => n.input.name), m = k(() => n.input.name), y = k(() => Xn.some((f) => f === n.input.type) && n.input.label !== void 0 && n.input.label !== null), b = k(() => {
      let f = Object.assign({}, n.input ?? {});
      if (delete f.type, y.value && delete f.label, f.className != null && delete f.className, f.form_columns != null && delete f.form_columns, er.some((G) => G === n.input.type) && (f.translate = n.translate), f.disabled = n.disabled, f.additional !== void 0) {
        for (const G in f.additional)
          f[G] = f.additional[G];
        delete f.additional;
      }
      return f.inputId = s, f;
    }), v = (f) => {
      if (f.value !== void 0 && f.value !== null && Array.isArray(f.value)) {
        let G = [...f.value];
        f.value = G;
      }
      r("valueChanged", f);
    }, J = (f) => {
      r("buttonClicked", f);
    }, N = () => {
      if (a.value != null && a.value.getValue != null) {
        let f = a.value.getValue();
        return f != null && Array.isArray(f) ? [...f] : f;
      }
      return null;
    };
    return l({
      /**
       * Called to set the value for this given form component
       * 
       * @param value any
       */
      setValue: p,
      /**
       * Property that returns the name of this given component
       */
      fieldName: _,
      /**
       * Property that returns the type of form component this is
       */
      type: c,
      /**
       * Property that returns the alternative field name for this component
       */
      altFieldName: m,
      /**
       * Called to get the value of this component.
       * If this is a basic component, it returns that value.
       * If this is a subform it will return an object where the propertyName are the names of the fields in the subform.
       */
      getValue: N,
      /**
       * Called to see if this component is valid.
       * If this is a basic component, it ensures it has a value if required.
       * If this is a subform it returns the result from the subform isValid call.
       */
      isValid: () => {
        if (n.input.type === "subform" && a.value !== null)
          return a.value.isValid();
        if (n.input.required ?? !1) {
          let f = N();
          return f != null && (Array.isArray(f) ? f.length > 0 : !0) && f.toString() !== "";
        }
        return !0;
      },
      /**
       * Called to set the values of a subform component, this will throw an error if this component is not a subform.
       * 
       * @param values any|null
       */
      setValues: (f) => {
        if (n.input.type === "subform" && a.value !== null)
          a.value.setValues(f);
        else
          throw "unable to call set values on any form element except a subform";
      }
    }), (f, G) => n.input.type === g(R).header ? (o(), I(Ve, {
      key: 0,
      subtype: n.input.subtype,
      label: n.input.label,
      ref_key: "inp",
      ref: a
    }, null, 8, ["subtype", "label"])) : n.input.type === g(R).paragraph ? (o(), I(Ue, {
      key: 1,
      name: n.input.name,
      label: n.input.label,
      ref_key: "inp",
      ref: a
    }, null, 8, ["name", "label"])) : n.input.type === g(R).button ? (o(), I(Le, Y({ key: 2 }, b.value, {
      disabled: h.value,
      onButtonClicked: J,
      ref_key: "inp",
      ref: a
    }), null, 16, ["disabled"])) : (o(), i(B, { key: 3 }, [
      y.value ? (o(), i("label", {
        key: 0,
        class: "label",
        for: g(s)
      }, [
        q(T(g(d)(n.input.label ?? "")) + " ", 1),
        n.input.required ? (o(), i("span", Zn, "*")) : A("", !0)
      ], 8, qn)) : A("", !0),
      M("div", Qn, [
        (o(), I(pe(u.value), Y(b.value, {
          onValueChanged: v,
          ref_key: "inp",
          ref: a
        }), null, 16))
      ])
    ], 64));
  }
}), tr = {
  onsubmit: "return false;",
  class: "container is-fullhd"
}, ar = /* @__PURE__ */ D({
  __name: "component-form",
  props: {
    elements: {},
    disabled: { type: Boolean, default: !1 },
    translate: {},
    inputId: {}
  },
  emits: ["valueChanged", "buttonClicked"],
  setup(e, { expose: l, emit: t }) {
    const a = e, s = t, r = de(a, z);
    Ie("Translate", (v) => r.value(v));
    const n = x(null), d = () => n.value !== null ? n.value.getValue() : null, c = (v) => {
      n.value !== null && n.value.setValue(v);
    }, u = () => n.value !== null ? n.value.isValid() : !1, p = x([]);
    Ie(Ee, ye(p));
    const h = (v) => {
      Array.isArray(v) ? p.value = [...p.value, ...v] : p.value.push(v);
    }, _ = (v) => {
      Array.isArray(v) ? p.value = p.value.filter((J) => v.indexOf(J) >= 0) : p.value = p.value.filter((J) => J !== v);
    }, m = x([]);
    return Ie(et, ye(m)), l({
      /**
       * Returns the values of the given form elements as an object where the property name is the name of the form element and the property value is 
       * that elements value
       */
      getValues: d,
      /**
       * Called to set the values on the form elements using an object where the property name is the name of the form element
       * 
       * @param values any
       */
      setValues: c,
      /**
       * Called to see if the form is valid.  Returns a boolean value that is true if all required fields have a value.
       */
      isValid: u,
      /**
       * Called to hide 1 or more fields in the form
       * 
       * @param name string|string[]
       */
      hideField: h,
      /**
       * Called to show 1 or more hidden fields in the form
       * 
       * @param name string|string[]
       */
      showField: _,
      /**
       * Called to disable 1 or more fields in the form
       * 
       * @param name string|string[]
       */
      disableField: (v) => {
        Array.isArray(v) ? m.value = [...m.value, ...v] : m.value.push(v);
      },
      /**
       * Called to enable 1 or more disabled fields in the form
       * 
       * @param name string|string[]
       */
      enableField: (v) => {
        Array.isArray(v) ? m.value = m.value.filter((J) => v.indexOf(J) >= 0) : m.value = m.value.filter((J) => J !== v);
      }
    }), (v, J) => (o(), i("form", tr, [
      C(la, {
        fields: a.elements,
        ref_key: "inputs",
        ref: n,
        disabled: a.disabled,
        onValueChanged: J[0] || (J[0] = (N) => s("valueChanged", N)),
        onButtonClicked: J[1] || (J[1] = (N) => s("buttonClicked", N))
      }, null, 8, ["fields", "disabled"])
    ]));
  }
}), lr = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  AutoComplete: Rt,
  Button: Le,
  Checkbox: Lt,
  CheckboxGroup: Wt,
  ComponentForm: ar,
  DateField: Gt,
  FormComponent: sa,
  FullEditor: Ht,
  Header: Ve,
  Hidden: Kt,
  NumberField: Yt,
  Paragraph: Ue,
  RadioGroup: qt,
  Select: Qt,
  Switch: Xt,
  Text: ea,
  TextArea: aa,
  Time: lt
}, Symbol.toStringTag, { value: "Module" })), pt = document.currentScript === null || document.currentScript === void 0 ? import.meta.url : document.currentScript.src;
Ce(`${pt.substring(0, pt.lastIndexOf("/"))}/vibrantvue.min.css`);
const sr = Object.values(Xe).filter((e, l, t) => t.indexOf(e) === l), nr = (e) => {
  document.getElementsByTagName("html")[0].setAttribute("data-theme", `${e || ""}`);
}, rr = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  AVAIABLE_SKINS: sr,
  setSkin: nr
}, Symbol.toStringTag, { value: "Module" })), or = /* @__PURE__ */ D({
  __name: "chart",
  props: {
    labels: {},
    datasets: {},
    type: {},
    title: {},
    show_refresh: { type: Boolean },
    width: {},
    height: {},
    legend_position: { default: He.right },
    scales: {},
    tooltips: {}
  },
  emits: ["legendItemClick"],
  setup(e, { emit: l }) {
    const t = `${fa(z)}chart.umd.min.js`, a = x(null), s = e, r = l;
    let n = null;
    const d = () => {
      n != null && n.update();
    }, c = k(() => {
      var u = "";
      return s.width && (u = `width:${s.width}px;`), s.height && (u += `height:${s.height}px;`), u;
    });
    return j(() => s.type, (u) => {
      n != null && (n.type = u ?? "line");
    }), j(
      () => s.labels,
      (u) => {
        n != null && (n.data.labels = u, (s.show_refresh == null || !s.show_refresh) && d());
      },
      { deep: !0 }
    ), j(
      () => s.datasets,
      (u) => {
        n != null && (n.data.datasets = u, (s.show_refresh == null || !s.show_refresh) && d());
      },
      { deep: !0 }
    ), ce(async () => {
      let u = {
        responsive: !0,
        animation: {
          duration: 100
        },
        plugins: {
          legend: {
            position: `${s.legend_position}`,
            labels: {
              filter: (h, _) => h.text != null
            },
            onClick: function(h, _) {
              r("legendItemClick", n, _);
            }
          }
        }
      };
      s.scales != null && s.scales != null && (u.scales = s.scales), s.tooltips != null && s.tooltips != null && (u.tooltips = s.tooltips);
      const { Chart: p } = await Ge(t, ["Chart"]);
      n = new p(a.value.getContext("2d"), {
        type: s.type == null ? "line" : s.type,
        data: {
          datasets: s.datasets,
          labels: s.labels
        },
        options: u
      }), n.update();
    }), (u, p) => (o(), I(Ut, null, xe({
      content: E(() => [
        M("canvas", {
          ref_key: "canvas",
          ref: a,
          style: Ae(c.value)
        }, null, 4)
      ]),
      _: 2
    }, [
      s.title ? {
        name: "header",
        fn: E((h) => [
          M("h3", {
            class: F(h.header_class)
          }, T(s.title), 3)
        ]),
        key: "0"
      } : void 0,
      s.show_refresh != null && s.show_refresh != null && s.show_refresh ? {
        name: "footer",
        fn: E((h) => [
          C(xt, {
            class: F(h.addon_class),
            onClick: d
          }, null, 8, ["class"])
        ]),
        key: "1"
      } : void 0
    ]), 1024));
  }
}), ur = /* @__PURE__ */ D({
  __name: "code-writer",
  props: {
    language: {},
    autocompletes: {},
    readonly: { type: Boolean, default: !1 },
    value: { default: "" }
  },
  emits: ["valueChanged"],
  setup(e, { expose: l, emit: t }) {
    const a = `${_a(z)}src-noconflict/ace.js`, s = e, r = t, n = x(null), d = x(null), c = function() {
      return d.value.getValue() == "" ? null : d.value.getValue();
    }, u = function(h) {
      d.value.setValue(h ?? "");
    };
    j(() => s.readonly, (h) => {
      d.value.setReadOnly(h == null || h == null ? !1 : h);
    }), j(() => s.value, (h) => {
      u(h);
    }), j(() => s.language, (h) => {
      d.value.getSession().setMode(h);
    });
    const p = k(() => {
      let h = Number.MAX_SAFE_INTEGER;
      if (s.autocompletes != null && s.autocompletes != null) {
        for (let _ = 0; _ < s.autocompletes.length; _++)
          s.autocompletes[_].method.indexOf(".") >= 0 ? h = Math.min(h, s.autocompletes[_].method.indexOf(".")) : h = Math.min(h, s.autocompletes[_].method.length);
        if (h > 3 && s.autocompletes.length > 0) {
          let _ = !0, m = s.autocompletes[0].method.substring(0, 3);
          for (let y = 0; y < s.autocompletes.length; y++)
            if (s.autocompletes[y].method.substring(0, 3) != m) {
              _ = !1;
              break;
            }
          _ && (h = 3);
        }
      }
      return h;
    });
    return l({
      /**
       * Gets the current value 
       */
      getValue: c,
      /**
       * Sets the current value
       * 
       * @param value string|null
       */
      setValue: u
    }), ce(async () => {
      const { ace: h } = await Ge(a, ["ace"]);
      d.value = pa(h.edit(n.value.$el, {
        mode: s.language,
        selectionStyle: "text",
        minLines: 20,
        maxLines: 50,
        enableBasicAutocompletion: !0
      })), d.value.setReadOnly(s.readonly === void 0 || s.readonly === null ? !1 : s.readonly), s.value !== null && s.value !== void 0 && d.value.setValue(s.value), d.value.on("change", () => r("valueChanged", c())), s.autocompletes !== null && s.autocompletes !== void 0 && (d.value.setOptions({
        enableBasicAutocompletion: !0,
        enableLiveAutocompletion: !0
      }), d.value.completers = [{
        identifierRegexps: [/[a-zA-Z0-9_\.]+/],
        getCompletions: function(_, m, y, b, v) {
          var J = [];
          if (b = b.toUpperCase(), b.length >= p && (J = s.autocompletes.filter((N) => N.method.toUpperCase().startsWith(b) && N.method.length > b.legend).map((N) => ({
            caption: N.method + (N.description === null || N.description === void 0 ? "" : "->" + N.description),
            value: N.method,
            meta: "autos"
          }))), J.length === 0) {
            v(null, []);
            return;
          }
          v(null, J.map(function(N) {
            return N;
          }));
        }
      }]);
    }), (h, _) => (o(), i("div", {
      class: "editor",
      ref_key: "container",
      ref: n
    }, null, 512));
  }
}), ir = { key: 0 }, dr = { colspan: "100%" }, cr = ["colspan", "rowspan"], pr = ["onClick"], mr = { class: "icon" }, hr = { key: 0 }, br = { colspan: "100%" }, vr = ["colspan", "rowspan", "onClick"], gr = { key: 1 }, yr = { colspan: "100%" }, fr = /* @__PURE__ */ D({
  __name: "grid",
  props: {
    columns: {},
    data: {},
    empty_message: {},
    column_rows: {},
    has_filter: { type: Boolean },
    current_sort: {},
    is_loading: {},
    getRowColor: {},
    scrollable: { type: Boolean },
    fixed_header: { type: Boolean },
    full_width: { type: Boolean },
    narrow: { type: Boolean },
    use_next: { type: Boolean, default: !0 },
    has_more: { type: Boolean, default: void 0 },
    has_previous: { type: Boolean, default: void 0 },
    size: { default: Z.small },
    rounded: { type: Boolean, default: !1 },
    button_type: {},
    total_pages: {},
    current_page: {},
    zero_page_index: { type: Boolean }
  },
  emits: ["moveForward", "moveBack", "goToPage", "cellClicked", "sort", "filter"],
  setup(e, { emit: l }) {
    const t = ie(), a = e, s = l, r = {
      scrollable: a.scrollable,
      fixed_header: a.fixed_header,
      full_width: a.full_width,
      narrow: a.narrow
    }, n = {
      use_next: a.use_next,
      has_more: a.has_more,
      has_previous: a.has_previous,
      size: a.size,
      rounded: a.rounded,
      button_type: a.button_type,
      total_pages: a.total_pages,
      current_page: a.current_page
    }, d = k(() => !!(a.has_previous || a.has_more || a.current_page !== void 0 && a.total_pages !== void 0 && oe(a.total_pages) > 1)), c = k(() => a.column_rows === void 0 || a.column_rows.length === 0 ? a.columns : a.column_rows.map((m) => m.map((y) => a.columns.filter((b) => b.some((v) => v.id === y))[0].find((b) => b.id === y)))), u = k(
      () => c.value.filter((m) => m.some((y) => !(y.headerOnly ?? !1)))
    ), p = (m) => {
      a.current_sort !== void 0 && a.current_sort !== null && a.current_sort.column === m ? s("sort", {
        column: m,
        ascending: !a.current_sort.ascending
      }) : s("sort", {
        column: m,
        ascending: !0
      });
    }, h = (m, y) => {
      if (a.getRowColor) {
        let b = a.getRowColor(m, y);
        if (b)
          return `is-${b}`;
      }
      return null;
    }, _ = (m, y, b, v) => {
      let J = [];
      if ((y.cellClass || y.getCellColor) && (y.cellClass && J.push(`${y.cellClass}`), y.getCellColor)) {
        let N = y.getCellColor(m, b, v);
        N && J.push(`is-${N}`);
      }
      return J;
    };
    return (m, y) => (o(), I(nt, me(fe(r)), xe({
      thead: E(() => [
        a.has_filter ?? !1 ? (o(), i("tr", ir, [
          M("th", dr, [
            C(Ct, {
              onFilter: y[0] || (y[0] = (b) => s("filter", b))
            })
          ])
        ])) : A("", !0),
        (o(!0), i(B, null, W(a.columns, (b) => (o(), i("tr", null, [
          (o(!0), i(B, null, W(b, (v) => (o(), i("th", {
            colspan: v.headerColspan,
            rowspan: v.headerRowspan,
            class: F(v.headerClass)
          }, [
            P(m.$slots, `head-${v.id}`, {}, () => [
              a.current_sort !== void 0 && a.current_sort !== null && (v.canSort ?? !1) && v.id === a.current_sort.column ? (o(), i("span", {
                key: 0,
                class: "icon-text is-clickable",
                onClick: (J) => p(v.id)
              }, [
                M("span", mr, [
                  C(K, {
                    icon: a.current_sort.ascending ? "arrow-up" : "arrow-down"
                  }, null, 8, ["icon"])
                ]),
                M("span", null, T(v.title), 1)
              ], 8, pr)) : (o(), i(B, { key: 1 }, [
                q(T(v.title), 1)
              ], 64))
            ])
          ], 10, cr))), 256))
        ]))), 256))
      ]),
      tbody: E(() => [
        a.data === null || a.is_loading || a.data.length === 0 ? (o(), i("tr", hr, [
          M("td", br, [
            a.data === null || a.is_loading ? (o(), I(_e, { key: 0 })) : (o(), I(he, {
              key: 1,
              message: a.empty_message ?? "No data available"
            }, null, 8, ["message"]))
          ])
        ])) : (o(!0), i(B, { key: 1 }, W(a.data, (b, v) => (o(), i(B, null, [
          (o(!0), i(B, null, W(u.value, (J, N) => (o(), i("tr", {
            key: `row-${v}-${N}`,
            class: F(h(v, b))
          }, [
            (o(!0), i(B, null, W(J.filter((w) => !(w.headerOnly ?? !1)), (w) => (o(), i("td", {
              key: `data-${v}-${N}`,
              colspan: w.dataColspan,
              rowspan: w.dataRowspan,
              class: F(_(v, w, b, w.propertyName ? b[w.propertyName] : void 0)),
              onClick: (U) => s("cellClicked", { rowIndex: v, data: w.propertyName ? b[w.propertyName] : null, row: b })
            }, [
              P(m.$slots, `body-${w.id}`, Y({ ref_for: !0 }, { rowIndex: v, data: w.propertyName ? b[w.propertyName] : null, row: b }), () => [
                q(T(w.propertyName ? b[w.propertyName] : null), 1)
              ])
            ], 10, vr))), 128))
          ], 2))), 128))
        ], 64))), 256))
      ]),
      _: 2
    }, [
      d.value || g(t).tfoot_head || g(t).tfoot_bottom ? {
        name: "tfoot",
        fn: E(() => [
          g(t).tfoot_head ? P(m.$slots, "tfoot_head", { key: 0 }) : A("", !0),
          d.value ? (o(), i("tr", gr, [
            M("td", yr, [
              C(Bt, Y(n, {
                onMoveForward: y[1] || (y[1] = (b) => s("moveForward")),
                onMoveBack: y[2] || (y[2] = (b) => s("moveBack")),
                onGoToPage: y[3] || (y[3] = (b) => s("goToPage", b))
              }), null, 16)
            ])
          ])) : A("", !0),
          g(t).tfoot_bottom ? P(m.$slots, "tfoot_bottom", { key: 2 }) : A("", !0)
        ]),
        key: "0"
      } : void 0
    ]), 1040));
  }
}), _r = { class: "progress-group" }, kr = /* @__PURE__ */ D({
  __name: "progress-group",
  props: {
    size: {},
    values: {},
    max: {}
  },
  setup(e) {
    const l = e, t = k(() => {
      let r = 0;
      for (let n = 0; n < l.values.length; n++)
        r += l.values[n].value;
      return r;
    }), a = k(() => l.values.map((r) => ({
      size: l.size ?? Z.normal,
      type: r.type,
      percentage: r.value / (l.max ?? t.value) * 100,
      caption: r.caption ?? `${r.value}`,
      onClick: r.onClick
    }))), s = k(() => l.max !== void 0 ? {
      size: l.size ?? Z.normal,
      type: null,
      percentage: (l.max - t.value) / l.max * 100,
      caption: null
    } : null);
    return (r, n) => (o(), i("div", _r, [
      (o(!0), i(B, null, W(a.value, (d, c) => (o(), I(g(zt), {
        is: "progress",
        class: F(`progress is-${d.size} is-${d.type} ${d.onClick !== void 0 ? "is-clickable" : ""}`),
        key: c,
        text: d.caption ?? "",
        position: g(Be).bottom,
        style: Ae({ width: `${d.percentage}%` }),
        value: "100",
        max: "100",
        onClick: () => {
          d.onClick !== void 0 && d.onClick();
        }
      }, {
        default: E(() => [
          q(T(`${d.percentage}%`), 1)
        ]),
        _: 2
      }, 1032, ["class", "text", "position", "style", "onClick"]))), 128)),
      s.value != null ? (o(), i("progress", {
        key: 0,
        class: F(`progress is-${s.value.size} is-${s.value.type}`),
        style: Ae({ width: `${s.value.percentage}%` }),
        value: "100",
        max: "100"
      }, T(`${s.value.percentage}%`), 7)) : A("", !0)
    ]));
  }
}), Sr = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  Chart: or,
  CodeWriter: ur,
  Grid: fr,
  ProgressGroup: kr
}, Symbol.toStringTag, { value: "Module" })), {
  Animation: Or,
  Button: Tr,
  ButtonsContainer: Pr,
  ButtonAdd: xr,
  ButtonCancel: Cr,
  ButtonDelete: Br,
  ButtonDisable: Er,
  ButtonDownload: zr,
  ButtonEdit: Ir,
  ButtonEnable: Rr,
  ButtonOkay: Wr,
  ButtonPrint: Lr,
  ButtonRefresh: Vr,
  ButtonSave: Ur,
  ButtonUpload: jr,
  CheckMark: Gr,
  DropDown: Hr,
  DynamicSlot: Kr,
  Filter: Yr,
  Icon: qr,
  Message: Zr,
  Notification: Qr,
  PageNotification: Xr,
  Pagination: eo,
  Promised: to,
  Progress: ao,
  NavBar: lo,
  Menu: so,
  MenuLabel: no,
  MenuList: ro,
  MenuEntry: oo,
  ToolTip: uo,
  Badge: io,
  Tag: co,
  Tags: po
} = Hl, { DraggableItem: mo, DropZone: ho, Sortable: bo } = es, {
  AutoComplete: vo,
  CheckboxGroup: go,
  Checkbox: yo,
  DateField: fo,
  ComponentForm: _o,
  FullEditor: ko,
  Header: So,
  Hidden: Mo,
  NumberField: Do,
  Paragraph: $o,
  RadioGroup: Ao,
  Select: Jo,
  Switch: No,
  Text: Fo,
  TextArea: wo,
  Time: Oo,
  FormComponent: To
} = lr, {
  Banner: Po,
  Box: xo,
  Breadcrumbs: Co,
  Card: Bo,
  ColumnContainer: Eo,
  Footer: zo,
  Level: Io,
  List: Ro,
  Media: Wo,
  Modal: Lo,
  ModalCard: Vo,
  Panel: Uo,
  Section: jo,
  Table: Go,
  Tabs: Ho,
  Slideout: Ko,
  StepWizard: Yo
} = Jn, { AVAIABLE_SKINS: qo, setSkin: Zo } = rr, {
  ColorTypes: Qo,
  NoticeTypes: Xo,
  Sizes: eu,
  AnimationSpeeds: tu,
  AnimationTypes: au,
  IconSizes: lu,
  ChartLegendPositions: su,
  ChartTypes: nu,
  DropZoneQuadrants: ru,
  BreadCrumbAlignments: ou,
  BreadCrumbSeperators: uu,
  ColumnContainerModifiers: iu,
  ColumnSizes: du,
  ColumnOffsetSizes: cu,
  BorderTypes: pu,
  TabAlignments: mu,
  TabStyles: hu,
  TileSizes: bu,
  TileTypes: vu,
  FixedNavBarPositions: gu,
  FixedMenuPositions: yu,
  BadgePositions: fu,
  ToolTipPositions: _u,
  ToolTipTextAlignments: ku,
  ButtonAlignments: Su,
  SectionSizes: Mu
} = ha, { loadNonEs6Module: Du } = ma, { Chart: $u, CodeWriter: Au, Grid: Ju, ProgressGroup: Nu } = Sr;
export {
  qo as AVAIABLE_SKINS,
  Or as Animation,
  tu as AnimationSpeeds,
  au as AnimationTypes,
  vo as AutoComplete,
  io as Badge,
  fu as BadgePositions,
  Po as Banner,
  pu as BorderTypes,
  xo as Box,
  ou as BreadCrumbAlignments,
  uu as BreadCrumbSeperators,
  Co as Breadcrumbs,
  Tr as Button,
  xr as ButtonAdd,
  Su as ButtonAlignments,
  Cr as ButtonCancel,
  Br as ButtonDelete,
  Er as ButtonDisable,
  zr as ButtonDownload,
  Ir as ButtonEdit,
  Rr as ButtonEnable,
  Wr as ButtonOkay,
  Lr as ButtonPrint,
  Vr as ButtonRefresh,
  Ur as ButtonSave,
  jr as ButtonUpload,
  Pr as ButtonsContainer,
  Bo as Card,
  $u as Chart,
  su as ChartLegendPositions,
  nu as ChartTypes,
  Gr as CheckMark,
  yo as Checkbox,
  go as CheckboxGroup,
  Au as CodeWriter,
  Qo as ColorTypes,
  Eo as ColumnContainer,
  iu as ColumnContainerModifiers,
  cu as ColumnOffsetSizes,
  du as ColumnSizes,
  _o as ComponentForm,
  fo as DateField,
  mo as DraggableItem,
  Hr as DropDown,
  ho as DropZone,
  ru as DropZoneQuadrants,
  Kr as DynamicSlot,
  Yr as Filter,
  yu as FixedMenuPositions,
  gu as FixedNavBarPositions,
  zo as Footer,
  To as FormComponent,
  ko as FullEditor,
  Ju as Grid,
  So as Header,
  Mo as Hidden,
  qr as Icon,
  lu as IconSizes,
  Io as Level,
  Ro as List,
  Wo as Media,
  so as Menu,
  oo as MenuEntry,
  no as MenuLabel,
  ro as MenuList,
  Zr as Message,
  Lo as Modal,
  Vo as ModalCard,
  lo as NavBar,
  Xo as NoticeTypes,
  Qr as Notification,
  Do as NumberField,
  Xr as PageNotification,
  eo as Pagination,
  Uo as Panel,
  $o as Paragraph,
  ao as Progress,
  Nu as ProgressGroup,
  to as Promised,
  Ao as RadioGroup,
  jo as Section,
  Mu as SectionSizes,
  Jo as Select,
  eu as Sizes,
  Ko as Slideout,
  bo as Sortable,
  Yo as StepWizard,
  No as Switch,
  mu as TabAlignments,
  hu as TabStyles,
  Go as Table,
  Ho as Tabs,
  co as Tag,
  po as Tags,
  Fo as Text,
  wo as TextArea,
  bu as TileSizes,
  vu as TileTypes,
  Oo as Time,
  uo as ToolTip,
  _u as ToolTipPositions,
  ku as ToolTipTextAlignments,
  Du as loadNonEs6Module,
  wr as provideAceJS,
  Nr as provideAnimation,
  Fr as provideChatJS,
  Jr as provideFontAwesome,
  $r as provideIconSet,
  Dr as provideLanguage,
  Ar as provideSummerNote,
  Zo as setSkin,
  Q as useLanguage
};
//# sourceMappingURL=vibrantvue.esm.js.map
